# From Orbits to Routes

A plain-paper, two-dimensional satellite-network laboratory, with a small Python API for students. The page follows the typography and restraint of a tutorial journal: white background, black/grey diagrams, a map, essential controls, and inspectable results. This is the compact-UI revision; the Python model/API remains v0.2.0.

**Start here:** [What runs where?](docs/ARCHITECTURE.md) · [中文说明](docs/README_zh.md) · [Python API](docs/API.md) · [Model and equations](docs/MODEL.md) · [Teaching guide](docs/TEACHING_GUIDE.md) · [Test report](docs/TEST_REPORT.md).

## Open the example

Open `outputs/orbits_to_routes.html` in a modern browser. This is a self-contained file: no Python process, remote map tiles, external fonts, API keys or internet connection are required for its interactions. The source map credit is an optional external link, not a dependency.

The default scene has 72 synthetic satellites on six circular inclined orbital planes, four ground stations, and 121 topology samples over 30 minutes. These are selected teaching parameters, not a deployed constellation.

The UI has English and Chinese labels. The main page keeps the map, time controls, setup and current result. The inspector is collapsed initially; click a map node/link or expand it to inspect or disable satellites. Charts, hop tables, exercises and the notebook have been removed. Python API and model notes open only when their navigation buttons are clicked. CSV, JSON, SVG and Python downloads are under the small Export menu.

## Run with Python

Use Python **3.10 or later**. The application and model require **only the standard library**. Run from this project directory:

```bash
python app.py
```

The app precomputes the scene in Python **once at startup** and opens a local page at `http://127.0.0.1:8765`. On Windows, `start_windows.bat` is a convenience launcher. Stop with Ctrl+C. A different port can be selected with `python app.py --port 8766`. This is a local development server, not a public deployment service.

Export instead of serving:

```bash
python app.py --export
python app.py --export --language zh --output outputs/lab_zh.html
```

## Create your own network

Save this as `my_network.py` in the project root, next to `satlab/`, then run `python my_network.py`.

```python
from satlab import Network

net = Network("My constellation")
net.add_constellation(
    planes=6, sats_per_plane=12,
    altitude_km=1000, inclination_deg=53,
)
net.add_ground_station("Vancouver", lat=49.28, lon=-123.12)
net.add_ground_station("Tokyo", lat=35.68, lon=139.69)
net.set_link_policy(max_isl_km=4000, min_elevation_deg=10)

route = net.at(0).route("Vancouver", "Tokyo", metric="delay")
if route.reachable:
    print(route.path, route.propagation_ms)
else:
    print(route.reason)

net.export_html("my_network.html", duration_s=1800, step_s=15)
```

Names must be unique. North/east coordinates are positive; south/west are negative. Time is in seconds, distance in kilometres, angles in degrees, and reported propagation delay in milliseconds. `at(t)` does not advance a hidden clock or change the network.

Examples progress from helpers to your own models:

```bash
python -m examples.first_network
python -m examples.custom_orbits
python -m examples.custom_links
python -m examples.compare_routes
```

The package can also be installed into an existing environment using `python -m pip install -e .` from this directory. This is a local project, not an instruction to install an unrelated package called `satlab` from PyPI. The model itself has no third-party runtime dependencies; editable installation may need setuptools through your packaging environment.

## What runs where?

This is **Python-generated data plus a browser viewer**, not a live browser-to-Python simulation API. `python app.py` also uses precomputation: its local HTTP handler only serves the resulting HTML. It does not recompute a constellation after each browser click.

**Python:** circular orbit propagation, Earth rotation, three-dimensional geometry, Earth occlusion, ground-station elevation checks, link filtering, topology sampling, and the full queryable routing API.

**Browser:** plotting the Python-generated snapshots, shortest-path search for interactive endpoint/failure changes, state inspection and file exports. Its delay/hop search was checked against the Python implementation. The browser does not independently propagate a second orbital model. Arbitrary orbit or physical-link parameter changes require regenerating the file in Python.

`set_isl_filter()` is evaluated in Python before export, so its resulting topology works in the browser. Arbitrary **routing-cost callbacks** are Python-only; the browser exposes delay and hops. A callback cannot be restored from a name in JSON; save its original Python script. The UI explicitly disables JSON-derived Python reconstruction when an ISL callback is present, rather than silently dropping it.

## Publish on UDTJ or a personal site

Upload the exported HTML to any site that serves static HTML, and link to it as a laboratory page. No Python backend is needed. It is not automatically published anywhere by this project.

Embedding is also possible if your site permits an iframe; adjust the height for the article layout:

```html
<iframe src="/labs/orbits_to_routes.html"
        title="Satellite network laboratory"
        style="width:100%;height:1100px;border:1px solid #ccc;">
</iframe>
```

The exported lab is a compact workspace rather than a full article. The inspector and mobile layout can still increase its height, so test the iframe size on your own site. The UDTJ heading follows the supplied visual direction; this project does not publish or connect to the UDTJ website.

## Scope

This is a geometric snapshot-graph simulator, not an ns-3 replacement, packet simulator, real-constellation performance predictor, radio-link budget, routing-protocol implementation or learned model. The map is two-dimensional; the geometry is three-dimensional. No traffic, queueing, transmission time, congestion, antenna/degree limits, handover cost, protocol convergence, atmospheric refraction or perturbations are modeled. Read `docs/MODEL.md` before interpreting the metrics.

Run the standard-library model tests:

```bash
python -m unittest discover -s tests -v
```

`tests/browser_qa.py` is optional developer tooling, requiring Playwright and Chromium. Neither is needed by students to run the app.

## Project layout

```text
app.py                         Default scene and launcher
satlab/model.py                Model objects, geometry, routing
satlab/export.py               HTML exporter and local-only server
satlab/assets/lab.html         Compact workspace and on-demand dialogs
satlab/assets/lab.css          Monochrome journal styling
satlab/assets/lab.js           Viewer, graph routing, interactions
satlab/assets/coastlines.json  Bundled Natural Earth-derived outlines
examples/                     Four runnable teaching examples
docs/                         API, methods, activity guide, test report
tests/                        Model and optional browser tests
outputs/orbits_to_routes.html Ready-to-open example
```
