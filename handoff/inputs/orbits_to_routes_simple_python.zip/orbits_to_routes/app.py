"""Run: python app.py          Export: python app.py --export"""
from argparse import ArgumentParser
from satlab import Network


def make_network() -> Network:
    net = Network("Inclined LEO constellation")
    net.add_constellation(planes=6, sats_per_plane=12, altitude_km=1000,
                          inclination_deg=53, phasing=1)
    net.add_ground_station("Vancouver", lat=49.28, lon=-123.12)
    net.add_ground_station("Tokyo", lat=35.68, lon=139.69)
    net.add_ground_station("London", lat=51.51, lon=-0.13)
    net.add_ground_station("Singapore", lat=1.35, lon=103.82)
    net.set_link_policy(max_isl_km=4000, min_elevation_deg=10)
    return net


if __name__ == "__main__":
    parser = ArgumentParser(description="Orbits to Routes — a local, plain-paper satellite network lab")
    parser.add_argument("--export", action="store_true", help="Write a single offline HTML instead of starting a server")
    parser.add_argument("--output", default="outputs/orbits_to_routes.html")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--language", choices=("en", "zh"), default="en")
    args = parser.parse_args()
    net = make_network()
    options = dict(source="Vancouver", target="Tokyo", duration_s=1800,
                   step_s=15, language=args.language)
    if args.export:
        print(net.export_html(args.output, **options))
    else:
        net.serve(port=args.port, open_browser=not args.no_browser, **options)
