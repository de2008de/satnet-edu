# What runs where? / Python 和网页分别做什么？

## Current implementation

This revision simplifies the UI only. The model and Python API are unchanged.

```text
A Python script defines Network(...)
    ↓
Python samples net.at(t): positions, visibility, physical links, distances
    ↓
Python packages snapshots + map + CSS + JavaScript in one HTML file
    ↓
A browser reads the file, draws the map and handles interaction
    ↓
JavaScript searches the exported graphs when endpoints / faults / objectives change
```

`net.at(120).route("A", "B")` runs entirely in Python. It does not require a browser or an exported timeline. Use this API for your own experiments, custom link predicates and non-negative routing-cost callbacks.

`net.export_html(...)` runs Python while generating the file. The exported file carries a finite sequence of topology snapshots. Once generated, it does not need a running Python process. The browser uses JavaScript for the map, controls, local graph search and file downloads. It is not running CPython, Pyodide, or Python source code, and Python is not automatically translated into JavaScript.

`python app.py` / `net.serve(...)` first build exactly the same kind of page and then serve it over loopback HTTP. The request handler in `satlab/export.py` serves that page only. There is no live `/simulate` or route-computation endpoint, no Python interpreter in the browser, and no remote service. Playing the timeline advances through exported samples; it is not an animation of measured packet transit.

To change satellite altitude, plane count, a physical link rule, or the time window, edit the Python script and generate a new HTML file. The browser cannot invent positions or links outside the exported data. Browser faults remove nodes/links from those snapshots; they do not alter the orbital motion.

The same package therefore supports two useful workflows: use Python directly for computation, or publish its outputs as an interactive static page. A live Python backend could be added in a future version, but it is **not implemented** here.

## 中文说明

**当前架构是“Python 预计算 + 浏览器交互”，不是每次点击都调用 Python。**

Python 的 `Network` API 负责定义网络、计算轨道位置、判断可见性与链路、独立查询路由。导出时，Python 把指定时间窗口内的一组拓扑采样写进 HTML。

HTML 不只有文字，还包含样式、JavaScript 程序和这些拓扑数据。浏览器通过 JavaScript 绘制地图、处理播放/点击/切换，并在已有拓扑上重新选路。所以打开导出的网页，不必安装 Python，也不必一直开启 Python 程序。

运行 `python app.py` 也不是另一套实时后端。它先计算整份页面，再用本地 HTTP 服务把页面提供给浏览器；后续交互不请求 Python 重新算轨道。更改星座规模、高度、轨道面、链路规则或时间窗口，仍需要修改 Python 并重新导出。

`net.at(120).route("A", "B")` 则是独立的 Python 计算，不依赖网页；研究或编程练习可以完全不打开浏览器。

## Files to inspect

- `satlab/model.py`: model, geometry and Python routing.
- `satlab/export.py`: `build_data`, `render_html`, `export_html`, and the local-only `serve` handler.
- `satlab/assets/lab.js`: browser rendering, controls and graph search.
- `satlab/assets/lab.html` / `lab.css`: presentation, separate from the Python model.
