# Compact UI — test report

Tested in the supplied Linux environment using Python 3.13.5, system Chromium and Playwright. These are implementation/regression checks, not validation against a real satellite service or evidence of educational effectiveness.

## Python model and API

`python -m unittest discover -s tests -v`: **37 tests passed**. The underlying `satlab/model.py` and orbital/routing equations were unchanged in this UI revision. Tests cover geometry, link constraints, routing objectives, failure snapshots, input validation, serialization, HTML generation and script escaping. The current test output is in `unit_tests.txt`.

## Compact browser UI

`python tests/browser_qa.py`: **17 check groups passed**. Removed page sections are absent from the DOM, not merely invisible. Checks covered the preserved map and controls; a collapsed inspector that opens on map selection; step/slider/play/pause/reset; satellite failures and same-time baseline; disconnected metrics; CSV/JSON/SVG/Python exports; an executable reproduction script that produces the compact UI; direct link inspection; routing-objective contrast; reference dialogs, Escape and focus return; the export menu; bilingual labels; 1440 px desktop and 390 px mobile width; and a separately built custom constellation with callback guardrails.

**726 Python/browser route comparisons** covered 121 samples, two routing objectives, and three endpoint/failure configurations. Reachability, hops, distances and propagation costs matched. Delay tolerance: 1e-8 ms. Distance tolerance: 1e-5 km. Node-sequence differences: zero.

The primary test loaded the exact HTML bytes with all network requests blocked. No network requests or uncaught JavaScript exceptions occurred during the tested interactions. Direct `file://` navigation was also attempted, but this environment's Chromium returned `ERR_BLOCKED_BY_ADMINISTRATOR`; it is therefore **not an observed double-click test**. This restriction did not affect the exact-HTML offline interaction checks. `browser_qa_results.json` records the results.

`node --check satlab/assets/lab.js` completed successfully.

## Local Python entry point

`python app.py --no-browser --port 8879` served the compact page with HTTP 200; an unrelated path returned HTTP 404. This server provides a precomputed page, not a dynamic simulation API. The test results are in `server_qa_results.json`.

## Limits

Firefox, Safari, the Windows launcher, screen readers, external website embedding policies and large-constellation performance were not independently tested in this revision. The low-resolution mobile map still benefits from the inspector's node dropdown. A full accessibility audit was not performed. There was no TLE/SGP4 comparison, packet-level validation, traffic study, or learning-outcome evaluation.

The optional browser test needs Playwright and Chromium; the student-facing application and model still require no third-party runtime packages.
