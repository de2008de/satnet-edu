# Model, equations and assumptions

Model version: **0.2.0**. This document specifies the synthetic model, not a real satellite service.

## Geometry and time

The Earth is a sphere with radius R = 6371 km, gravitational parameter mu = 398600.4418 km³/s² and uniform rotation omega = 7.2921150e-5 rad/s. All link propagation uses c = 299792.458 km/s. These are fixed model constants. Their presence does not make the simplified model an operational orbit predictor.

For altitude h, circular radius r = R+h, inclination i, right ascension of ascending node Ω and phase u0:

```
n = sqrt(mu / r³)
u(t) = u0 + n t
T = 2π / n

x_inertial = r (cos Ω cos u − sin Ω sin u cos i)
y_inertial = r (sin Ω cos u + cos Ω sin u cos i)
z_inertial = r sin u sin i
```

The Earth-fixed frame rotates by −omega*t about the z axis. At t=0 the inertial and Earth-fixed reference x axes coincide by construction. There is no date, sidereal-angle calculation from UTC, TLE, SGP4, drag, J2 perturbation or eccentricity. Negative Python snapshot times are allowed under the same analytic model.

A shell with P planes and S satellites per plane uses zero-based p and j:

```
Ω[p]    = raan_offset + 360° p / P
u0[p,j] = phase_offset + 360° j / S + 360° F p / (P S)
```

F is the phasing integer. RAAN spans 360°, giving a Walker-delta-style construction. This is not a Walker-star construction or a claim to reproduce a particular constellation.

Ground stations are fixed spherical-surface positions. Latitude/longitude are spherical, not ellipsoidal geodetic coordinates.

## Eligible links

For satellite positions a and b, let q=b−a. The closest point on their finite segment to the origin is a+αq, with α=clamp(−a·q/(q·q),0,1). The segment must not enter the Earth and its length must not exceed `max_isl_km`. Coincident satellite positions are not linked. An optional user predicate can then remove the pair.

For a ground position g and satellite position s:

```
elevation = asin( ((s−g) · g) / (|s−g| |g|) )
```

Ground access requires elevation at least `min_elevation_deg`. The supported mask is 0–90°. Radio propagation, atmospheric refraction, ground-station altitude, terrain and horizon obstructions are omitted.

All eligible links are undirected and simultaneously available. There is no antenna/laser-terminal count, degree constraint, link budget, capacity, scheduling or acquisition time. Eligibility should not be confused with a feasible hardware deployment. The Python ISL filter can explore a subset of this geometric graph, but arbitrary antenna scheduling is not built in.

Edge lengths are rounded to 10⁻⁶ km (1 mm) before routing and export so the Python and browser graphs use exactly the same stored edge weights. This storage precision is not a claim of physical accuracy. Displayed coordinates are rounded for readability.

## Routing

Dijkstra search is evaluated independently at each snapshot. For a path P:

```
propagation_ms(P,t) = 1000 * Σ_e distance_km(e,t) / c
```

The two browser objectives minimize propagation delay or hop count. Propagation ties are broken by hops; hop ties by propagation delay. Ground stations can only be endpoints. Other ground stations are not free terrestrial relay shortcuts.

There are no packets, queues, bandwidth limits, transmission/serialization delay, jitter model, packet loss, routing control traffic, hysteresis, route computation overhead, handover penalties or convergence. Routes are computed with instantaneous global topology knowledge. Changing routes in the display is not a protocol simulation.

A disconnected sample has no numerical path delay; it is not zero or a large made-up sentinel. CSV fields are blank in that case. The current-result panel displays an em dash for unreachable metrics. The compact UI has no time-series chart.

## Map and samples

The UI displays satellite subpoints in a flat equirectangular-style longitude/latitude projection. Network distance is never calculated from pixels. Straight three-dimensional links are projected as curves by radial projection onto the spherical Earth, then onto the map; visible curvature does not mean a bent radio beam. The anti-meridian/map seam is split to avoid drawing an incorrect line across the entire map. Recentring has no effect on simulation data.

Python generates a finite time sequence. The browser does not propagate a separate orbit model. It reruns graph search on exported edges to support endpoint/objective/failure changes offline. The time slider selects those discrete samples; intermediate physical states are not inferred. A smaller time step may reveal outages or route changes missed by a larger one. The last interval may be shorter than the nominal step to include the requested end time.

Healthy and failed routes are compared on the same frame, same endpoints and same objective. Changing the objective compares the same graph. This avoids confounding time evolution with the chosen treatment.

## Data provenance and references

* Natural Earth terms of use: https://www.naturalearthdata.com/about/terms-of-use/ — the map data are public domain.
* The bundled coastline coordinates were derived by dissolving the Natural Earth low-resolution country polygons in the local `pyogrio/tests/fixtures/naturalearth_lowres` dataset, dropping political boundaries and rounding coordinates to three decimals. They are land outlines for display, not a current authoritative boundary dataset. No country attributes are shipped. pyogrio/geospatial libraries were used only to prepare the bundled resource and are not runtime dependencies.
* NASA Earth Fact Sheet: https://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html — background reference for Earth dimensions and orbital/rotation quantities. The exact simplified constants used here are stated above and in the source code.
* Python `http.server` documentation: https://docs.python.org/3/library/http.server.html — the standard-library HTTP server is not recommended for production. This package binds only to loopback and serves just the generated page. Publish the static export instead.

No student learning-effectiveness study or real-constellation validation has been performed. Numerical/software checks are listed in `TEST_REPORT.md`.
