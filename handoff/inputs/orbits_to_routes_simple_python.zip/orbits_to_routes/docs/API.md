# Python API reference

All examples assume `from satlab import Network` and are run from the project root, or after a local editable install.

## Network builder

```python
net = Network("Experiment name")
net.add_constellation(
    planes=6, sats_per_plane=12,
    altitude_km=1000, inclination_deg=53,
    phasing=1, raan_offset_deg=0, phase_offset_deg=0,
    prefix="S",
)
net.add_ground_station("A", lat=49.28, lon=-123.12)
net.add_ground_station("B", lat=35.68, lon=139.69)
net.set_link_policy(max_isl_km=4000, min_elevation_deg=10)
```

Builder methods return the network, so chaining is optional. Every satellite and ground station shares one unique-name namespace. Automatic satellite IDs are `S01-01`, `S01-02`, etc. Planes and slots are numbered from one in the names.

`phasing=None` (the default) selects one for multi-plane shells and zero for a single-plane shell. An explicit phasing integer must satisfy `0 <= phasing < planes`. RAAN spans 360 degrees. See the model notes for the exact phase equation rather than assuming an operational satellite network's phasing.

To create multiple shells, use distinct prefixes:

```python
net.add_constellation(planes=3, sats_per_plane=8,
                      altitude_km=1500, inclination_deg=70, prefix="H")
```

To define individual circular orbits:

```python
net.add_satellite("Test-1", altitude_km=1000,
                  inclination_deg=53, raan_deg=30,
                  phase_deg=15, plane="experimental-plane")
```

The `plane` label is metadata, useful for your own connection rule. It does not change the specified RAAN/inclination. The model does not load TLEs or arbitrary ephemerides.

## Snapshots and routes

```python
snapshot = net.at(120)
print(snapshot.nodes["A"].position_km)  # Earth-fixed x, y, z in km
print(snapshot.nodes["S01-01"].lat)
print(snapshot.neighbors("A"))
print(snapshot.links[0].distance_km)

fast = snapshot.route("A", "B", metric="delay")
few = snapshot.route("A", "B", metric="hops")
```

A `Route` has `source`, `target`, `path`, `links`, `reachable`, `hops`, `distance_km`, `propagation_ms`, `cost`, `metric`, and `reason`. Path and links are tuples. `.cost` is the optimized primary metric; it is not necessarily a delay. A zero-hop self-route is permitted in Python. The UI requires distinct ground endpoints.

Disconnected results have an empty path and `None` for numerical metrics. Always check `route.reachable`, or simply `if route:`. Unknown names and invalid metrics are input errors, not disconnected results.

Ground stations can be endpoints but cannot be used as intermediate relays. The graph is undirected; no direct ground–ground links exist. `delay` ties are broken by hops, and `hops` ties by delay. Exact equal-cost paths may depend on deterministic name/iteration ordering; compare optimized cost when studying equivalence.

## Failures without changing the healthy network

```python
healthy = net.at(120)
failed = net.at(120, disabled=["S01-01", "S02-03"])
print(healthy.route("A", "B").propagation_ms)
print(failed.route("A", "B").propagation_ms)
```

Both snapshots use the same time. Failed nodes retain their positions for inspection, but their links are removed. The original builder is not modified. Python permits a disabled ground endpoint too; the browser's failure controls target satellites.

## Your own connectivity rule

```python
def same_plane(a, b):
    return a.plane == b.plane

net.set_isl_filter(same_plane)
```

The callback receives two `NodeState` objects after range and Earth-occlusion checks succeed. Write a symmetric, deterministic predicate. It only removes otherwise eligible ISLs; it does not override physical constraints or affect ground-access links. `net.set_isl_filter(None)` resets it. For more elaborate routing experiments, inspect/export `snapshot.nodes` and `snapshot.links` or extend the readable model module.

## Your own non-negative path cost (Python only)

```python
route = net.at(120).route(
    "A", "B",
    metric=lambda edge: edge.propagation_ms + 0.5,
)
```

The example adds a **synthetic cost** per hop, not a measured processing delay. Callbacks must return finite, non-negative numeric values, because Dijkstra is used. The pure propagation metric remains available separately. Arbitrary cost callbacks are not exposed by the browser UI; it supports only delay and hops.

## Export or view

```python
net.export_html(
    "outputs/my_lab.html",
    source="A", target="B",
    start_s=0, duration_s=1800, step_s=15,
    language="en",                 # or "zh"
    metric="delay",                # or "hops"
    initial_time_s=120,             # nearest sampled time, within the window
    default_disabled=["S01-01"],
)

# Or start a local-only server. Ctrl+C stops it.
net.serve(source="A", target="B", duration_s=900, step_s=15)
```

The exporter requires two ground stations and at least one satellite. It keeps a healthy topology baseline so initially disabled satellites can be restored. It includes the end of the requested time window, even when not divisible by the step. Final interval length can therefore differ from the nominal step.

The viewer is intended for small teaching networks. Its exporter has guardrails of 600 satellites and about 10,001 regular samples; reaching these guardrails is not a performance promise. Python geometry uses an all-pairs ISL check (quadratic in satellite count), and export size grows with the number of sampled edges. Start with 12–100 satellites and a modest time window.

## Configuration

`net.to_dict()` produces a JSON-compatible model description, including version and callback-presence metadata. `Network.from_dict(data)` restores standard configurations. Callback-bearing configurations are rejected on restoration instead of silently losing the rule. Use the original Python script to rebuild those experiments.

The browser's experiment JSON wraps the model under `network` and view/query settings under `experiment`:

```python
import json
from pathlib import Path
saved = json.loads(Path("satellite_experiment.json").read_text())
net = Network.from_dict(saved["network"])
e = saved["experiment"]
r = net.at(e["selected_time_s"], disabled=e["disabled"]).route(
    e["source"], e["target"], metric=e["metric"]
)
```

The downloadable Python reproduction script does this automatically. Model version, parameters, time window, step, endpoints, objective and failures are recorded. The map centre changes only the display, not the network.
