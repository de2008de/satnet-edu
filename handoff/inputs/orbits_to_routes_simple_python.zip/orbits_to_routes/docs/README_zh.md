# 从轨道到路由：使用说明

这是一个白纸黑字的卫星网络教学实验室，不是产品宣传页。页面用二维经纬度地图显示卫星和通信路径，用三维几何计算距离、遮挡和地面可见性。Python API 与网页界面分离，学生不需要修改 JavaScript。

## 最快打开

直接用浏览器打开 `outputs/orbits_to_routes.html`。界面右上角可以切换英文和中文。所有必要的程序、地图轮廓和采样拓扑都已在这个文件里，不需要在线地图服务、账户或外部字体。

这一版只保留主地图、时间控制、实验配置和当前结果。可以播放或单步推进，切换端点和路由目标。对象检查器默认收起，点击地图节点或链路即可展开；也可手动展开后用下拉框选择。导出功能收在“导出”菜单里，Python API 和模型说明通过顶部入口按需打开。下方时延曲线、逐跳表格、探究题、笔记和长文已移除，Python API 没有删减。这里显示的是**单向传播时延**，不是完整网络延迟。

## Python 运行

使用 Python 3.10 或更新版本，不需要安装第三方运行依赖。解压后，在项目目录打开终端：

```bash
python app.py
```

这里 Python 在启动时计算一次拓扑，然后把完整网页交给浏览器；并没有一个在每次点击后重新仿真的 Python 后端。网页加载完成后，交互与选路在浏览器中执行。详见 `ARCHITECTURE.md`。

Windows 也可以双击 `start_windows.bat`。程序会尝试自动打开浏览器，地址会打印在终端。按 Ctrl+C 停止。

只生成静态网页：

```bash
python app.py --export
```

不要把这个基于标准库的本地服务器直接暴露到公网。发布到 UDTJ 或个人网页时，上传导出的 HTML 即可。

## 让学生创建自己的网络

最简单的例子在 `examples/first_network.py`，从项目根目录运行：

```bash
python -m examples.first_network
```

主要方法：

| 想做的事情 | Python 方法 |
|---|---|
| 创建星座 | `net.add_constellation(...)` |
| 逐颗定义卫星 | `net.add_satellite(...)` |
| 添加地面站 | `net.add_ground_station(...)` |
| 设置距离和仰角限制 | `net.set_link_policy(...)` |
| 自定义星间连接规则 | `net.set_isl_filter(rule)` |
| 检查特定时刻 | `snapshot = net.at(120)` |
| 模拟故障 | `net.at(120, disabled=["S03-04"])` |
| 查询路由 | `snapshot.route("Vancouver", "Tokyo")` |
| 导出交互页面 | `net.export_html("my_lab.html")` |

参数名携带单位：`altitude_km` 是公里，`inclination_deg` 是角度，`time_s` 是秒。纬度北正南负，经度东正西负。没有路径不是程序异常：返回对象的 `reachable` 为 False，各项数值为 None，并提供 `reason`。

从易到难还有三个例子：`custom_orbits.py` 手动定义卫星，`custom_links.py` 只允许同轨道面连接，`compare_routes.py` 用同一组拓扑比较优化目标并导出 CSV。

## 做实验，不必把全部教材放在界面里

播放默认场景，暂停或单步，检查路径和右侧传播时延。点击地图上的粗线路径，可查看链路状态；点击节点可查看经纬度和邻居数。

在同一时刻切换“最少跳数”与“最小传播时延”，或者停用路径上的卫星。两种目标不一定得到不同路径，这是合理结果；同一时刻的无故障对照用于区分故障与轨道运动的影响。

通过“导出”菜单保存 CSV、地图 SVG、实验 JSON 或复现用的 Python 脚本。更多课堂问题保留在独立的 `TEACHING_GUIDE.md` 中，不再显示在主界面。

## 必须明确的限制

这是合成圆轨道上的几何拓扑模型，不是实际星座或真实日期的预测。没有 TLE/SGP4、流量、队列、容量、天线数量、切换代价或协议收敛。所有符合几何条件的链路默认同时可用。

静态网页包含 Python 算好的拓扑，浏览器在这些图上计算最短路径以支持离线交互。Python 中也可以独立完成同样的选路实验。网页只暴露最小时延和最少跳数，Python 支持额外的非负边代价回调。

自定义 ISL 回调的计算结果会写入 HTML，但 JSON 不能保存任意 Python 函数。使用回调时请保留原始脚本，界面不会把该规则悄悄丢弃后伪装成“可复现”。

更多内容见 `API.md`、`MODEL.md`、`TEACHING_GUIDE.md` 和 `TEST_REPORT.md`。
