> Instructor reference only. This guide is not embedded in the compact viewer.

# A 15–20 minute teaching activity

## Learning goal

Explain how physical motion changes link geometry, how link geometry constrains a graph, and how a chosen graph objective determines the selected route. Students should distinguish propagation delay from total network delay and a sampled geometric model from a routing-protocol simulation.

This is a proposed activity, not evidence that the tool improves learning.

## 1. Predict before playing

With Vancouver → Tokyo and the minimum-delay objective, ask: “The ground stations stay still. Will delay stay constant, change smoothly, change abruptly, or show both kinds of change?” Record a prediction. Do not present animation speed as packet speed.

Play briefly, then use the time slider and the single-step control. Ask students to inspect a changed route and separate two explanations: the old route lost a link; or the old route stayed feasible but another one became better. A route can retain its node sequence while its length changes.

## 2. Hold the graph fixed and change the objective

The two objectives need not disagree. In the default Vancouver → Tokyo trace they agree at the exported samples. That is a legitimate result, not a broken comparison.

The compact UI has no contrast-search button. Choose Tokyo → London and move the time slider to 75 s to try a contrast in the bundled scene. At t=90 s, which is also included, minimum delay uses five hops with about 41.91 ms of propagation, whereas minimum hops uses four hops with about 42.59 ms. These values are outputs of this synthetic model, not service measurements.

Ask: “Which route is better?” Require the student to name the objective. Then ask whether this proves anything about application response time when queues, capacity and switching cost are absent from the model.

A modified constellation may yield no contrasting pair in the exported time window. Inspect the numbers or use the Python API to search rather than assuming a trade-off must exist.

## 3. Compare a failure at the same time

Select a route satellite with the inspector and disable it. The alternate dashed path is the **healthy network at the same time**, with the same endpoints and objective. It is not a historical route from before the fault. Try removing another currently usable access satellite until the source becomes disconnected. Then restore all satellites.

Ask the student to explain why a single failure might cause a longer route or no visible change rather than total disconnection. In this model failures are ideal node removal, not radio interference or protocol timeouts.

## 4. Transfer to a Python experiment

Change one parameter in `examples/first_network.py`, export a new page, and compare. Examples: fewer satellites, a larger elevation mask, or a shorter ISL range. Hold other parameters and the time interval fixed.

Use `examples/compare_routes.py` to generate tabular data directly from Python. Reachable-sample fractions are sample statistics, not guaranteed continuous-time availability. Refine the step before making claims about brief outages.

## Short response prompt

“Give one prediction, one observed result at a specific time, and an explanation naming the affected links or route objective. State one model limitation that prevents extending your conclusion directly to a real network.”

The compact page has no observation notebook or submission form. Use a separate worksheet for student responses; the lab itself does not collect or transmit student data. No assessment submission or analytics is built in. Any subsequent human-participant evaluation requires its own institutional review and study design as applicable; this project does not provide an ethics determination.
