# Compact UI revision

The model/API remains v0.2.0. No orbital or routing equations were changed.

Retained: journal masthead, title, map, time controls, endpoints, routing objectives, results, failures, bilingual labels, and exports.

Removed from the main page: delay chart, per-hop table, investigation questions, observation notebook, long Python tutorial, and long model article.

On demand: object inspector (collapsed initially), Python API dialog, model-assumptions dialog, and a small Export menu. API and model documentation remain in the Python project. Clicking a node or route link opens the inspector.

The HTML template and viewer source were changed as well as the bundled export, so generating a new network produces the same compact UI. Runtime documentation explicitly distinguishes Python precomputation from browser-local interaction.
