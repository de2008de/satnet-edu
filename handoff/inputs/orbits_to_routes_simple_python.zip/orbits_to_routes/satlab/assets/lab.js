(() => {
'use strict';
const D = JSON.parse(document.getElementById('sim-data').textContent);
const $ = id => document.getElementById(id);
const N = D.nodes, F = D.frames, C = D.constants.light_speed_km_s;
const groundIndices = N.map((n,i)=>n.kind==='ground'?i:-1).filter(i=>i>=0);
const en = {};
document.querySelectorAll('[data-i18n]').forEach(e=>en[e.dataset.i18n]=e.textContent);
Object.assign(en, {
  modelVersion:"model",kind:"Type",distance:"Distance (km)",delay:"Delay (ms)",
  findContrast:'Find a contrasting case →', noContrast:'These two objectives agree for all ground-station pairs at the sampled times. Try another constellation or link rule.', contrastFound:'A contrasting sample was selected. Compare the path and the two objectives.',
  minDelayShort:'Minimum delay',minHopsShort:'Minimum hops',healthyShort:'Healthy baseline',
  pause:'Ⅱ Pause', replay:'↻ Replay', connected:'Connected',disconnected:'No path',
  constellation:'Constellation',satellites:'satellites',planes:'planes',altitude:'Altitude',
  inclination:'Inclination',elevation:'Min. elevation',range:'Max. ISL range',customRule:'Custom ISL filter',
  yes:'Yes',mixed:'Mixed',enabled:'Enabled',disabled:'Disabled',latitude:'Latitude',longitude:'Longitude',
  neighbours:'Active neighbours',period:'Orbital period',nodeState:'State',restoreNode:'Restore this satellite',
  groundInfo:'A fixed surface endpoint. Other ground stations cannot relay this route.',
  linkAvailable:'Present in this topology snapshot.',linkMissing:'Not present in this topology snapshot.',
  inspectLink:'Selected link',access:'Ground access',isl:'Inter-satellite',
  accessRule:'Access links must satisfy the elevation mask. No antenna or capacity limit is modeled.',
  islRule:'This pair clears the Earth and meets the range limit and any Python ISL filter.',
  noPath:'No route under the current visibility, range and failure rules.',
  sameTime:'Both networks are compared at the same simulation time.',
  initial:'Initial sample. Advance time to inspect a path change.',
  lost:'Connectivity lost since the previous sample.',restored:'Connectivity restored since the previous sample.',
  oldLost:'The previous path has lost at least one link.',
  newBetter:'The previous path is still feasible; another route now has lower cost or wins a tie.',
  unchanged:'Same node sequence as the previous sample; its link lengths can still change.',
  idle:'No connection in this sample or the previous one.',
  noFailures:'No failed satellites. Select a route satellite to test a failure.',
  failures:'Disabled satellites',sampled:'sampled topologies',sampleEvery:'nominal step',
  noInterpolation:'No simulated packets or queues',
  csvSaved:'CSV includes every sampled time; disconnected metrics are blank, not zero.',
  saved:'File prepared.',copied:'Code copied.',copyFallback:'Copy is unavailable in this browser; select the code text manually.',
  notesEmpty:'Write an observation before saving notes.',
  callbackRequired:'This network uses a Python callback. Keep its original Python script; JSON alone cannot restore the rule.',
  pythonNote:'Uses the satlab package included in this project. The saved script restores this experiment, including selected failures.',
  chartExplanation:'Click the chart to select a time. Gaps and bottom tick marks denote disconnected samples; joining lines are visual guides.',
  minutes:'Time (min)',noSeries:'No connected samples in this interval',seconds:'s',
  healthyRoute:'Healthy path at this time',currentRoute:'Current selected path',
});
const zh = {
 findContrast:'寻找一个不同的结果 →',noContrast:'这些采样中，所有地面站对的两种目标都一致。试着改变星座或连线规则。',contrastFound:'已选中一个不同结果的采样，请比较路径和两个优化目标。',
 edition:'实验性教学资源',navLab:'交互实验室',navApi:'Python API',navModel:'模型与假设',
 eyebrow:'计算机网络 / 实验 01',title:'从轨道到路由',
 dek:'两个地面站都没有移动，为什么通信路径仍然改变？',
 byline:'一个可以检查卫星运动、连接关系和传播时延的教学模型。',
 play:'▶ 播放',pause:'Ⅱ 暂停',replay:'↻ 重播',step:'单步',reset:'重置',time:'时间',speed:'速度',
 mapTitle:'地图上的网络',pacific:'太平洋居中',greenwich:'本初子午线居中',satellite:'卫星',ground:'地面站',
 route:'当前路径',healthy:'无故障对照',otherLinks:'其他链路',labels:'节点编号',
 figOne:'图 1.',mapCaption:'二维经纬度地图上的卫星星下点。点击节点可检查其状态；链路长度由三维几何计算，不是地图上的线段长度。',
 chartTitle:'传播时延随时间的变化',exportCsv:'导出 CSV ↓',chartUnit:'单向 · 毫秒',figTwo:'图 2.',
 pathTitle:'检查当前路径',hop:'跳',link:'链路',kind:'类型',distance:'距离 (km)',delay:'时延 (ms)',
 hopHint:'点击一行可检查该链路。总距离和时延由整条路径上的链路累加得到。',
 setup:'实验配置',source:'源地面站',target:'目的地面站',objective:'路由目标',
 minDelay:'最小传播时延',minHops:'最少跳数',minDelayShort:'最小时延',minHopsShort:'最少跳数',healthyShort:'无故障对照',
 editHint:'在 Python 中修改轨道和连线参数，然后重新导出。',result:'当前结果',
 propagation:'传播时延',totalDistance:'路径总长度',hops:'链路跳数',
 inspect:'对象检查器',selectNode:'选择节点',disable:'停用这颗卫星',restore:'恢复全部卫星',restoreNode:'恢复这颗卫星',
 questionTitle:'值得研究的问题',question:'找到一次路径变化：是原来的链路消失了，还是另一条路径变得更短了？',
 questionHint:'通过单步推进和逐跳距离，为你的解释提供证据。',
 exportSvg:'保存地图 SVG ↓',exportConfig:'保存实验 JSON ↓',
 modelBanner:'模型边界：理想圆轨道、即时建立的无向链路、仅计算传播时延。不模拟流量、排队、带宽限制或路由协议收敛。',
 investigationKicker:'一个简短的探究实验',investigationTitle:'预测，观察，再解释。',
 ex1Title:'让卫星运动起来',ex1:'预测时延会平滑变化、突然变化，还是两者都有。沿时间轴单步推进，找到造成变化的具体链路。',
 ex2Title:'改变优化目标',ex2:'在同一时刻比较最少跳数与最小时延。何时会选出不同路径？利用链路距离解释结果。',
 ex3Title:'移除路径上的卫星',ex3:'选中当前路径上的一颗卫星并停用。与完全相同时刻的无故障网络对照，而不是与前一帧对照。',
 notebook:'我的观察笔记——仅保留在本页面内',notesLabel:'写下你的预测、观察结果和解释。',
 notesHint:'没有追踪、账户或提交。关闭或刷新页面后，未保存的笔记会消失。',saveNotes:'保存笔记 ↓',
 apiKicker:'创建你自己的网络',apiTitle:'一个简单的 Python API。',
 apiIntro:'定义星座，放置地面站，查询路径。不需要编写网页代码。',copy:'复制代码',
 apiMethods:'从这几个方法开始',method1:'用轨道面数量、高度和倾角建立一个星座层。',method2:'逐颗定义卫星轨道，而不必使用预设星座。',
 method3:'尝试你自己的星间连接规则。',method4:'检查特定时刻的拓扑并计算路径，没有隐藏的内部时钟。',
 method5:'把 Python 生成的网络拓扑发布为独立交互实验。',exportPython:'保存本实验的 Python 脚本 ↓',
 modelKicker:'方法与限制',modelTitle:'这个模型能说明什么，又不能说明什么？',
 geometryTitle:'从几何关系到网络图',
 geometryText:'Python 在自转的球形地球上推进有倾角的圆轨道。只有直线不穿过地球、且长度不超过星间距离上限时，卫星之间才可能连接。地面接入还必须满足最低仰角。',
 equationText:'目标是沿路径累加各链路的传播时延。最少跳数的路径若并列，则以时延较小者优先。地面站只能作为端点，不能充当中继。',
 notPredictionTitle:'教学模型，不是实际服务的性能预测',
 notPrediction:'星座是合成的，时钟起点是任意参考时刻而非真实 UTC 时间。不包含 TLE、天线预算、容量限制、切换开销或数据包动态。每个快照可以立即换路，但这不代表路由协议收敛。',
 staticText:'这个独立页面包含 Python 计算的拓扑快照。浏览器在快照上执行最短路径搜索，因此离线时仍可切换端点和模拟故障。Python API 提供相同的路由目标。',
 samplingText:'曲线中连接采样点的线只是视觉引导。两个采样点之间的短暂断连和换路可能被遗漏；需要时在 Python 中缩短时间步长。',
 mapCredit:'海岸线：Natural Earth 公有领域低分辨率陆地轮廓；不显示国界。',sourceLink:'数据来源 ↗',
 footerLab:'卫星网络实验室',footerStatus:'原型 · 模型 v0.2 · 尚未发表',
 connected:'已连接',disconnected:'无可用路径',constellation:'星座规模',satellites:'颗卫星',planes:'个轨道面',
 altitude:'轨道高度',inclination:'轨道倾角',elevation:'最低仰角',range:'最大星间距离',customRule:'自定义星间规则',
 yes:'有',mixed:'混合',enabled:'运行中',disabled:'已停用',latitude:'纬度',longitude:'经度',neighbours:'当前邻居数',period:'轨道周期',nodeState:'状态',
 groundInfo:'一个固定的地面端点。其他地面站不能中继这条路径。',
 linkAvailable:'该链路存在于当前拓扑快照。',linkMissing:'该链路不存在于当前拓扑快照。',inspectLink:'选中的链路',
 access:'地面接入',isl:'星间链路',accessRule:'接入链路必须满足最低仰角。这里没有天线数量和容量限制。',
 islRule:'该卫星对未被地球遮挡，满足距离上限及 Python 星间连接规则。',
 noPath:'当前可见性、距离和故障规则下，没有可用路径。',sameTime:'两个网络使用完全相同的仿真时刻进行对照。',
 initial:'初始采样。推进时间，检查路径如何变化。',lost:'与前一采样点相比，连接已中断。',restored:'与前一采样点相比，连接已恢复。',
 oldLost:'原路径上的至少一条链路已消失。',newBetter:'原路径仍然可用；另一条路径的代价更小，或在并列时胜出。',
 unchanged:'与前一采样点的节点序列相同；各链路的长度仍可能改变。',idle:'当前和前一采样点都没有可用路径。',
 noFailures:'目前没有故障。选中路径上的一颗卫星，试着停用它。',failures:'已停用卫星',
 sampled:'个拓扑采样',sampleEvery:'标称步长',noInterpolation:'不模拟数据包或排队',
 csvSaved:'CSV 包含全部采样时刻；断连指标留空，而不是记为零。',saved:'文件已准备好。',copied:'代码已复制。',
 copyFallback:'浏览器不支持复制，请直接选择代码文本。',notesEmpty:'请先写下一条观察。',
 callbackRequired:'这个网络使用 Python 回调。请保留原始 Python 脚本，单独的 JSON 无法恢复该规则。',
 pythonNote:'需要本项目自带的 satlab 包。保存的脚本可恢复当前实验，包括选中的故障。',
 chartExplanation:'点击曲线图选择时刻。曲线缺口和底部短标记表示断连采样；采样点之间的连线仅作视觉引导。',
 minutes:'时间（分钟）',noSeries:'这个时间窗口中没有连通的采样',seconds:'秒',healthyRoute:'同一时刻的无故障路径',currentRoute:'当前选中的路径'
};
Object.assign(zh, {
 modelVersion:'模型',exportMenu:'导出 ↓', exportCsv:'指标 CSV', exportSvg:'地图 SVG',
 exportConfig:'实验 JSON', exportPython:'复现实验的 Python 脚本', close:'关闭 ×',
 footerScope:'圆轨道模型 · 仅计算传播时延',
 apiBrief:'在 Python 中定义网络，再导出这个界面。请在项目目录中运行示例，与 satlab 文件夹放在一起。',
 apiDocs:'完整 API 和示例位于 Python 项目的 docs/API.md 与 examples/ 中。',
 geometryText:'Python 在自转的球形地球上计算有倾角的圆轨道。星间链路须避开地球遮挡并满足距离上限，地面接入还须满足最低仰角。二维地图用于显示位置，不用于测量链路长度。',
 modelBanner:'模型边界：即时建立的无向链路，仅计算传播时延。不模拟流量、排队、带宽限制、切换代价或路由协议收敛。',
 staticText:'Python 预先计算拓扑快照。浏览器显示这些快照，并在端点或故障改变时本地搜索最短路径。打开这个 HTML 不会启动 Python，也不需要请求仿真服务器。',
 samplingText:'时间轴选择已采样的拓扑。采样点之间的事件可能被遗漏；修改轨道参数或时间步长后，需要在 Python 中重新导出。',
});
let lang=D.language;
const tr = k => (lang==='zh' ? zh[k] : en[k]) ?? en[k] ?? k;
const esc = v => String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = (v, digits=2) => v===null || !Number.isFinite(v) ? '—' : v.toLocaleString(lang==='zh'?'zh-CN':'en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits});
function clock(t){const sign=t<0?'−':'';t=Math.abs(t);let m=Math.floor(t/60),s=Math.floor(t%60);return sign+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');}
const initialSat = N.findIndex(n=>n.kind==='satellite');
const state={index:D.initial_index||0,source:D.source,target:D.target,metric:D.metric||'delay',off:new Set(D.default_disabled),
 centre:180,links:true,labels:false,inspection:{type:'node',index:initialSat},playing:false,speed:120};
let routes=[], comparisons=[], raf=0, lastPlayWall=0, lastPlayTime=0, toastTimer;

// The graph and distances are generated in Python. Only graph search runs here.
// Identical objectives and tie-breaking weights are available in Snapshot.route().
function route(frame, source, target, metric='delay', off=new Set()){
 const empty={reachable:false,path:[],edges:[],hops:null,distance:null,ms:null,cost:null};
 if(off.has(source)||off.has(target))return empty;
 if(source===target)return {reachable:true,path:[source],edges:[],hops:0,distance:0,ms:0,cost:0};
 const n=N.length, adj=Array.from({length:n},()=>[]);
 frame.e.forEach((e,i)=>{
  const [a,b,d]=e;
  if(off.has(a)||off.has(b))return;
  if((N[a].kind==='ground'&&a!==source&&a!==target)||(N[b].kind==='ground'&&b!==source&&b!==target))return;
  adj[a].push([b,i,d]);adj[b].push([a,i,d]);
 });
 const first=Array(n).fill(Infinity),second=Array(n).fill(Infinity),done=Array(n).fill(false),parent=Array(n).fill(null);
 first[source]=0;second[source]=0;
 const better=(a,b)=> first[a]<first[b]||(first[a]===first[b]&&(second[a]<second[b]||(second[a]===second[b]&&N[a].id<N[b].id)));
 for(let k=0;k<n;k++){
  let u=-1;
  for(let i=0;i<n;i++)if(!done[i]&&Number.isFinite(first[i])&&(u<0||better(i,u)))u=i;
  if(u<0)break;if(u===target)break;done[u]=true;
  for(const [v,ei,d] of adj[u]){
   if(done[v])continue;
   const ms=d/C*1000,p=first[u]+(metric==='delay'?ms:1),q=second[u]+(metric==='delay'?1:ms);
   if(p<first[v]||(p===first[v]&&q<second[v])){first[v]=p;second[v]=q;parent[v]=[u,ei];}
  }
 }
 if(!Number.isFinite(first[target]))return empty;
 const path=[target],edges=[];let cur=target;
 while(cur!==source){if(!parent[cur])return empty;const [prev,ei]=parent[cur];path.push(prev);edges.push(ei);cur=prev;}
 path.reverse();edges.reverse();
 const distance=edges.reduce((s,i)=>s+frame.e[i][2],0),ms=edges.reduce((s,i)=>s+frame.e[i][2]/C*1000,0);
 return {reachable:true,path,edges,hops:edges.length,distance,ms,cost:first[target]};
}
function recalculate(){
 routes=F.map(f=>route(f,state.source,state.target,state.metric,state.off));
 const metric=state.off.size?state.metric:(state.metric==='delay'?'hops':'delay');
 comparisons=F.map(f=>route(f,state.source,state.target,metric,new Set()));
}
function populate(){
 for(const id of ['source','target'])$(id).innerHTML=groundIndices.map(i=>`<option value="${i}">${esc(N[i].id)}</option>`).join('');
 $('node-select').innerHTML=N.map((n,i)=>`<option value="${i}">${esc(n.id)}</option>`).join('');
 $('source').value=state.source;$('target').value=state.target;$('metric').value=state.metric;
 $('timeline').max=F.length-1;$('timeline').value=state.index;
 $('scenario-name').textContent=D.network.name;
}
function translate(){
 document.documentElement.lang=lang;
 document.title=lang==='zh'?'从轨道到路由 · UDTJ 实验室':'From Orbits to Routes · UDTJ Laboratory';
 document.querySelectorAll('[data-i18n]').forEach(el=>el.textContent=tr(el.dataset.i18n));
 $('language').textContent=lang==='en'?'中文':'English';
 $('language').setAttribute('aria-label',lang==='en'?'Switch to Chinese':'切换为英文');
 $('source').setAttribute('aria-label',tr('source'));$('target').setAttribute('aria-label',tr('target'));
 $('node-select').setAttribute('aria-label',tr('selectNode'));$('metric').setAttribute('aria-label',tr('objective'));
 $('timeline').setAttribute('aria-label',tr('time'));
 $('sample-info').textContent=`${F.length} ${tr('sampled')} · ${tr('sampleEvery')} ${D.step_s} s · ${tr('modelVersion')} ${D.network.model_version}`;
 $('callback-note').textContent=tr(D.network.requires_python_callback?'callbackRequired':'pythonNote');
 $('export-python').disabled=D.network.requires_python_callback;
 const sats=N.filter(n=>n.kind==='satellite'), planes=new Set(sats.map(n=>n.plane||n.id));
 const unique=k=>[...new Set(sats.map(n=>n[k]))];
 const alt=unique('altitude'),inc=unique('inclination');
 const params=[['constellation',`${sats.length} / ${planes.size} ${tr('planes')}`],['altitude',alt.length===1?`${fmt(alt[0],0)} km`:tr('mixed')],
  ['inclination',inc.length===1?`${fmt(inc[0],0)}°`:tr('mixed')],['elevation',`${fmt(D.network.policy.min_elevation_deg,0)}°`],['range',`${fmt(D.network.policy.max_isl_km,0)} km`]];
 if(D.network.requires_python_callback)params.push(['customRule',D.network.isl_filter_name||tr('yes')]);
 $('parameters').innerHTML=params.map(([k,v])=>`<div><dt>${esc(tr(k))}</dt><dd>${esc(v)}</dd></div>`).join('');
 render();
}
const B={x:43,y:17,w:942,h:444};
const wrap=(v,m)=>((v%m)+m)%m;
function xy(lon,lat){return [B.x+wrap(lon-state.centre+180,360)/360*B.w,B.y+(90-lat)/180*B.h];}
function pathWrapped(points){
 if(!points.length)return '';
 let prev=xy(...points[0]),s=`M${prev[0].toFixed(2)},${prev[1].toFixed(2)}`;
 for(let i=1;i<points.length;i++){
  const p=xy(...points[i]);let dx=p[0]-prev[0];
  if(Math.abs(dx)>B.w/2){
   const adjusted=p[0]+(dx>0?-B.w:B.w),edge=dx>0?B.x:B.x+B.w;
   const ratio=(edge-prev[0])/(adjusted-prev[0]);const y=prev[1]+ratio*(p[1]-prev[1]);
   s+=`L${edge.toFixed(2)},${y.toFixed(2)}M${(dx>0?B.x+B.w:B.x).toFixed(2)},${y.toFixed(2)}L${p[0].toFixed(2)},${p[1].toFixed(2)}`;
  }else s+=`L${p[0].toFixed(2)},${p[1].toFixed(2)}`;
  prev=p;
 }
 return s;
}
// Project a straight 3D link onto the Earth/map; do not measure map pixels.
function linkPoints(frame,a,b){
 const cart=i=>{const [lon,lat]=frame.p[i].map(v=>v*Math.PI/180),r=D.constants.earth_radius_km+N[i].altitude;return [r*Math.cos(lat)*Math.cos(lon),r*Math.cos(lat)*Math.sin(lon),r*Math.sin(lat)];};
 const A=cart(a),Z=cart(b),points=[];
 for(let j=0;j<=14;j++){const u=j/14,p=A.map((v,k)=>v*(1-u)+Z[k]*u);points.push([Math.atan2(p[1],p[0])*180/Math.PI,Math.atan2(p[2],Math.hypot(p[0],p[1]))*180/Math.PI]);}
 return points;
}
const pathForEdge=(f,e)=>pathWrapped(linkPoints(f,e[0],e[1]));
function drawMap(){
 const f=F[state.index],r=routes[state.index],base=comparisons[state.index];
 let s=`<title>${esc(tr('mapTitle'))}: t = ${esc(clock(f.t))}</title><desc>${esc(tr('mapCaption'))}</desc><defs><clipPath id="map-clip"><rect x="${B.x}" y="${B.y}" width="${B.w}" height="${B.h}"/></clipPath></defs><rect width="1000" height="500" fill="white"/>`;
 // Graticule and a stable global extent; time never changes the viewport.
 for(let lat=-60;lat<=60;lat+=30){const y=xy(0,lat)[1];s+=`<line x1="${B.x}" y1="${y}" x2="${B.x+B.w}" y2="${y}" stroke="${lat===0?'#d5d5d5':'#e7e7e7'}" stroke-width="0.7"/><text x="${B.x-9}" y="${y+4}" text-anchor="end" fill="#727272" font-family="Arial,sans-serif" font-size="11">${lat===0?'0°':Math.abs(lat)+'°'+(lat>0?'N':'S')}</text>`;}
 for(let j=0;j<=6;j++){const x=B.x+B.w*j/6,lon=state.centre-180+j*60,normal=wrap(lon+180,360)-180;
  const label=Math.abs(normal)===180?'180°':normal===0?'0°':Math.abs(normal)+'°'+(normal>0?'E':'W');
  s+=`<line x1="${x}" y1="${B.y}" x2="${x}" y2="${B.y+B.h}" stroke="#e7e7e7" stroke-width="0.7"/><text x="${x}" y="${B.y+B.h+20}" text-anchor="middle" fill="#727272" font-family="Arial,sans-serif" font-size="11">${label}</text>`;
 }
 s+=`<g clip-path="url(#map-clip)"><path d="${D.coastlines.map(pathWrapped).join('')}" fill="none" stroke="#909090" stroke-width="0.75" stroke-linejoin="round"/>`;
 for(const [lon,lat,label] of [[-153,-17,'PACIFIC OCEAN'],[-30,-28,'ATLANTIC OCEAN'],[78,-32,'INDIAN OCEAN']]){const [x,y]=xy(lon,lat);s+=`<text x="${x}" y="${y}" text-anchor="middle" fill="#a3a3a3" font-family="Georgia,serif" font-style="italic" font-size="11" letter-spacing="1.7">${label}</text>`;}
 const edgePaths=f.e.map(e=>pathForEdge(f,e));
 if(state.links){
  f.e.forEach((e,i)=>{if(state.off.has(e[0])||state.off.has(e[1]))return;s+=`<path d="${edgePaths[i]}" fill="none" stroke="#bcbcbc" stroke-width="0.65"/>`;});
  f.e.forEach((e,i)=>{if(state.off.has(e[0])||state.off.has(e[1]))return;s+=`<path d="${edgePaths[i]}" data-edge="${i}" class="clickable" fill="none" stroke="transparent" stroke-width="7"><title>${esc(N[e[0]].id+' ↔ '+N[e[1]].id)} · ${fmt(e[2],1)} km</title></path>`;});
 }
 if(state.off.size&&base.reachable){for(const ei of base.edges)s+=`<path d="${edgePaths[ei]}" fill="none" stroke="white" stroke-width="4"/><path d="${edgePaths[ei]}" fill="none" stroke="#777" stroke-width="1.7" stroke-dasharray="7 5"/>`;}
 if(r.reachable){for(const ei of r.edges){s+=`<path d="${edgePaths[ei]}" fill="none" stroke="white" stroke-width="5.5"/><path data-edge="${ei}" class="clickable" d="${edgePaths[ei]}" fill="none" stroke="#111" stroke-width="2.3"><title>${esc(tr('currentRoute'))}</title></path>`;}}
 if(state.inspection.type==='link'){
  const [a,b]=state.inspection.pair,ei=f.e.findIndex(e=>(e[0]===a&&e[1]===b)||(e[0]===b&&e[1]===a));
  if(ei>=0&&!state.off.has(a)&&!state.off.has(b))s+=`<path d="${edgePaths[ei]}" fill="none" stroke="#111" stroke-width="3.4" stroke-dasharray="2 3"/>`;
 }
 const routeSet=new Set(r.path);
 N.forEach((n,i)=>{
  const [x,y]=xy(...f.p[i]),off=state.off.has(i),isGround=n.kind==='ground',onRoute=routeSet.has(i),selected=state.inspection.type==='node'&&state.inspection.index===i;
  if(selected)s+=`<circle cx="${x}" cy="${y}" r="10" fill="none" stroke="#333" stroke-width=".8" stroke-dasharray="2 2"/>`;
  let marker=isGround?`<rect x="${x-4}" y="${y-4}" width="8" height="8" fill="${onRoute?'#111':'white'}" stroke="#111" stroke-width="1.3"/>`:
     off?`<circle cx="${x}" cy="${y}" r="4.5" fill="white" stroke="#333" stroke-width=".8"/><path d="M${x-3},${y-3}l6,6M${x+3},${y-3}l-6,6" stroke="#111" stroke-width="1.3"/>`:
     `<circle cx="${x}" cy="${y}" r="${onRoute?4.1:2.5}" fill="${onRoute?'white':'#333'}" stroke="#111" stroke-width="${onRoute?1.5:.6}"/>`;
  s+=`<g data-node="${i}" class="clickable" role="button" tabindex="${onRoute||isGround||selected?'0':'-1'}" aria-label="${esc(n.id+', '+(isGround?tr('ground'):tr('satellite')))}"><circle cx="${x}" cy="${y}" r="9" fill="transparent"/>${marker}<title>${esc(n.id)} · ${fmt(f.p[i][1],2)}°, ${fmt(f.p[i][0],2)}°</title></g>`;
  if(isGround||state.labels||onRoute||selected||off){
   let tx=x+8,ty=y-9,anchor='start';if(x>B.x+B.w-78){tx=x-8;anchor='end';}
   // Alternate selected route labels away from the links where possible.
   if(onRoute&&!isGround&&r.path.indexOf(i)%2===0)ty=y+17;
   if(isGround&&i!==state.source&&i!==state.target)ty=y+17;
   // Keep a satellite label on the side away from a nearby ground label.
   if(!isGround){
    let nearest=null,dist=70;
    for(const gi of groundIndices){const g=xy(...f.p[gi]),d=Math.hypot(g[0]-x,g[1]-y);if(d<dist){nearest=g;dist=d;}}
    if(nearest){tx=x+(nearest[0]>=x?-9:9);anchor=nearest[0]>=x?'end':'start';ty=y-11;}
   }
   s+=`<text x="${tx}" y="${ty}" text-anchor="${anchor}" font-family="${isGround?'Georgia,serif':'Consolas,monospace'}" font-size="${isGround?14:11}" fill="#222" stroke="white" stroke-width="3.2" paint-order="stroke" pointer-events="none">${esc(n.id)}</text>`;
  }
 });
 s+=`</g><rect x="${B.x}" y="${B.y}" width="${B.w}" height="${B.h}" fill="none" stroke="#999" stroke-width="0.8"/>`;
 $('network-map').innerHTML=s;
 $('baseline-legend').hidden=!state.off.size;
}
function changeNote(){
 if(state.off.size)return tr('sameTime');
 if(state.index===0)return tr('initial');
 const a=routes[state.index-1],b=routes[state.index],f=F[state.index];
 if(a.reachable&&!b.reachable)return tr('lost');if(!a.reachable&&b.reachable)return tr('restored');
 if(!a.reachable&&!b.reachable)return tr('idle');
 if(a.path.join(',')===b.path.join(','))return tr('unchanged');
 const exists=(a,b)=>f.e.some(e=>((e[0]===a&&e[1]===b)||(e[0]===b&&e[1]===a))&&!state.off.has(a)&&!state.off.has(b));
 const missing=a.path.slice(1).some((n,i)=>!exists(a.path[i],n));
 return tr(missing?'oldLost':'newBetter');
}
function drawResults(){
 const r=routes[state.index],f=F[state.index];
 $('connectivity').textContent=tr(r.reachable?'connected':'disconnected');
 $('delay-value').textContent=fmt(r.ms,2);$('distance-value').textContent=fmt(r.distance,0);$('hops-value').textContent=r.hops??'—';
 $('change-note').textContent=changeNote();

}
function drawInspector(){
 const f=F[state.index],what=state.inspection;
 const rows=items=>`<dl class="inspection-list">${items.map(([k,v])=>`<div><dt>${esc(tr(k))}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>`;
 if(what.type==='node'){
  const i=what.index,n=N[i],p=f.p[i],off=state.off.has(i);
  $('node-select').value=i;
  const degree=f.e.filter(e=>(e[0]===i||e[1]===i)&&!state.off.has(e[0])&&!state.off.has(e[1])).length;
  const data=[['latitude',`${fmt(p[1],2)}°`],['longitude',`${fmt(p[0],2)}°`],['altitude',`${fmt(n.altitude,0)} km`],['neighbours',String(degree)]];
  if(n.kind==='satellite')data.push(['period',`${fmt(n.period/60,1)} min`],['nodeState',tr(off?'disabled':'enabled')]);
  $('inspection-data').innerHTML=rows(data)+(n.kind==='ground'?`<p class="hint">${esc(tr('groundInfo'))}</p>`:'');
  $('disable').disabled=n.kind!=='satellite';$('disable').textContent=tr(off?'restoreNode':'disable');
 }else{
  const [a,b]=what.pair,e=f.e.find(e=>(e[0]===a&&e[1]===b)||(e[0]===b&&e[1]===a)),active=!!e&&!state.off.has(a)&&!state.off.has(b);
  const type=N[a].kind==='ground'||N[b].kind==='ground'?'access':'isl';
  $('inspection-data').innerHTML=`<p class="inspection-title">${esc(N[a].id)} ↔ ${esc(N[b].id)}</p>`+
   rows([['kind',tr(type)],['distance',e?fmt(e[2],1):'—'],['delay',e?fmt(e[2]/C*1000,3):'—']])+
   `<p class="hint">${esc(tr(active?'linkAvailable':'linkMissing'))}${active?' '+esc(tr(type==='access'?'accessRule':'islRule')):''}</p>`;
  $('disable').disabled=true;$('disable').textContent=tr('disable');
 }
 $('restore').hidden=!state.off.size;
 $('failure-note').textContent=state.off.size?`${tr('failures')}: ${[...state.off].map(i=>N[i].id).join(', ')}`:tr('noFailures');
}
function render(){
 $('clock').textContent=clock(F[state.index].t);$('timeline').value=state.index;
 $('timeline').setAttribute('aria-valuetext',F[state.index].t+' seconds');
 $('play').textContent=tr(state.playing?'pause':state.index===F.length-1?'replay':'play');
 const delta=state.index<F.length-1?F[state.index+1].t-F[state.index].t:D.step_s;
 $('step').textContent=(lang==='zh'?'单步':'Step')+' +'+Number(delta.toFixed(4))+' s';
 $('step').disabled=state.index===F.length-1;
 drawMap();drawResults();drawInspector();
}
function pause(){state.playing=false;cancelAnimationFrame(raf);$('play').textContent=tr(state.index===F.length-1?'replay':'play');}
function play(){
 if(state.playing){pause();return;}
 if(state.index===F.length-1)state.index=0;
 state.playing=true;lastPlayWall=performance.now();lastPlayTime=F[state.index].t;
 $('play').textContent=tr('pause');
 function tick(now){
  if(!state.playing)return;
  const target=lastPlayTime+(now-lastPlayWall)/1000*state.speed;
  let i=state.index;while(i+1<F.length&&F[i+1].t<=target)i++;
  if(i!==state.index){state.index=i;render();}
  if(i===F.length-1){pause();return;}
  raf=requestAnimationFrame(tick);
 }
 raf=requestAnimationFrame(tick);
}
function changeConfig(){pause();recalculate();render();}
$('play').addEventListener('click',play);
$('step').addEventListener('click',()=>{pause();state.index=Math.min(F.length-1,state.index+1);render();});
$('timeline').addEventListener('input',e=>{pause();state.index=Number(e.target.value);render();});
$('speed').addEventListener('change',e=>{const running=state.playing;pause();state.speed=Number(e.target.value);if(running)play();});
$('reset').addEventListener('click',()=>{
 pause();$('inspector-panel').open=false;state.index=0;state.off=new Set();state.source=D.source;state.target=D.target;state.metric='delay';
 state.inspection={type:'node',index:initialSat};populate();recalculate();state.inspection.index=routes[0].path.find(i=>N[i].kind==='satellite')??initialSat;render();
});
$('source').addEventListener('change',e=>{const old=state.source;state.source=Number(e.target.value);if(state.source===state.target)state.target=old;$('target').value=state.target;changeConfig();});
$('target').addEventListener('change',e=>{const old=state.target;state.target=Number(e.target.value);if(state.source===state.target)state.source=old;$('source').value=state.source;changeConfig();});
$('metric').addEventListener('change',e=>{state.metric=e.target.value;changeConfig();});
$('centre').addEventListener('change',e=>{state.centre=Number(e.target.value);drawMap();});
$('show-links').addEventListener('change',e=>{state.links=e.target.checked;drawMap();});
$('show-labels').addEventListener('change',e=>{state.labels=e.target.checked;drawMap();});
$('language').addEventListener('click',()=>{lang=lang==='en'?'zh':'en';translate();});
$('node-select').addEventListener('change',e=>{$('inspector-panel').open=true;state.inspection={type:'node',index:Number(e.target.value)};drawMap();drawInspector();});
$('disable').addEventListener('click',()=>{
 if(state.inspection.type!=='node')return;const i=state.inspection.index;if(N[i].kind!=='satellite')return;
 state.off.has(i)?state.off.delete(i):state.off.add(i);changeConfig();
});
$('restore').addEventListener('click',()=>{state.off.clear();changeConfig();});
function mapSelect(e){
 if(e.type==='keydown'&&!['Enter',' '].includes(e.key))return;
 const node=e.target.closest('[data-node]'),edge=e.target.closest('[data-edge]');
 if(!node&&!edge)return;if(e.type==='keydown')e.preventDefault();
 $('inspector-panel').open=true;
 if(node)state.inspection={type:'node',index:Number(node.dataset.node)};
 else{const ed=F[state.index].e[Number(edge.dataset.edge)];state.inspection={type:'link',pair:[ed[0],ed[1]]};}
 drawMap();drawInspector();
}
$('network-map').addEventListener('click',mapSelect);$('network-map').addEventListener('keydown',mapSelect);
function toast(message){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,3400);}
function download(name,text,mime='text/plain;charset=utf-8'){
 const blob=new Blob([text],{type:mime}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);
}
function csvCell(v){if(v===null||v===undefined)return '';let text=String(v);if(typeof v==='string'&&(/^[\s]*[=+\-@]/.test(text)||/^[\t\r]/.test(text)))text="'"+text;return '"'+text.replace(/"/g,'""')+'"';}
function csv(){
 const columns=['time_s','source','target','metric','disabled_satellites','reachable','hops','distance_km','propagation_ms','path','comparison_kind','comparison_reachable','comparison_hops','comparison_propagation_ms'];
 const rows=F.map((f,i)=>{const r=routes[i],b=comparisons[i];return [f.t,N[state.source].id,N[state.target].id,state.metric,[...state.off].map(i=>N[i].id).join(';'),r.reachable,r.hops,r.distance,r.ms,r.path.map(i=>N[i].id).join(' -> '),state.off.size?'healthy_same_objective':'other_objective',b.reachable,b.hops,b.ms].map(csvCell).join(',');});
 return columns.join(',')+'\r\n'+rows.join('\r\n');
}
function experiment(){return {network:D.network,experiment:{source:N[state.source].id,target:N[state.target].id,metric:state.metric,start_s:D.start_s,duration_s:D.duration_s,step_s:D.step_s,selected_time_s:F[state.index].t,disabled:[...state.off].map(i=>N[i].id),map_centre_deg:state.centre}};}
$('export-csv').addEventListener('click',()=>{download('satellite_metrics.csv','\ufeff'+csv(),'text/csv;charset=utf-8');toast(tr('csvSaved'));});
$('export-config').addEventListener('click',()=>{download('satellite_experiment.json',JSON.stringify(experiment(),null,2),'application/json');toast(tr('saved'));});
$('export-svg').addEventListener('click',()=>{download('satellite_map.svg','<?xml version="1.0" encoding="UTF-8"?>\n'+$('network-map').outerHTML,'image/svg+xml');toast(tr('saved'));});
const EXAMPLE=`from satlab import Network

net = Network("My first constellation")
net.add_constellation(
    planes=6, sats_per_plane=12,
    altitude_km=1000, inclination_deg=53,
)
net.add_ground_station("Vancouver", lat=49.28, lon=-123.12)
net.add_ground_station("Tokyo", lat=35.68, lon=139.69)
net.set_link_policy(max_isl_km=4000, min_elevation_deg=10)

route = net.at(0).route("Vancouver", "Tokyo", metric="delay")
if route.reachable:
    print(route.path, route.propagation_ms)
else:
    print(route.reason)

net.export_html(
    "my_network.html", source="Vancouver", target="Tokyo",
    duration_s=1800, step_s=15,
)`;
$('example-code').textContent=EXAMPLE;
$('copy-code').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(EXAMPLE);toast(tr('copied'));}catch(e){toast(tr('copyFallback'));}});
$('export-python').addEventListener('click',()=>{
 if(D.network.requires_python_callback)return;
 const data=JSON.stringify(experiment());
 const py=`"""Restore an exported experiment. Run from the satlab project directory."""\nimport json\nfrom satlab import Network\n\nsaved = json.loads(${JSON.stringify(data)})\nnet = Network.from_dict(saved["network"])\ne = saved["experiment"]\n\nroute = net.at(e["selected_time_s"], disabled=e["disabled"]).route(\n    e["source"], e["target"], metric=e["metric"]\n)\nprint(route.path, route.propagation_ms, route.reason)\n\nnet.export_html(\n    "restored_experiment.html", source=e["source"], target=e["target"],\n    start_s=e["start_s"], duration_s=e["duration_s"], step_s=e["step_s"],\n    default_disabled=e["disabled"], metric=e["metric"],\n    initial_time_s=e["selected_time_s"],\n)\n`;
 download('restored_experiment.py',py,'text/x-python');toast(tr('saved'));
});
// Reference material is optional; the initial page remains just a workspace.
document.querySelectorAll('[data-dialog]').forEach(button=>{
 button.addEventListener('click',()=>{pause();$(button.dataset.dialog).showModal();});
});
document.querySelectorAll('[data-close-dialog]').forEach(button=>{
 button.addEventListener('click',()=>button.closest('dialog').close());
});
document.querySelectorAll('dialog').forEach(dialog=>{
 dialog.addEventListener('click',e=>{
  const r=dialog.getBoundingClientRect();
  if(e.target===dialog&&(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom))dialog.close();
 });
});
$('export-menu').querySelectorAll('button').forEach(button=>{
 button.addEventListener('click',()=>{$('export-menu').open=false;});
});
document.addEventListener('click',e=>{
 if(!$('export-menu').contains(e.target))$('export-menu').open=false;
});
document.addEventListener('keydown',e=>{
 if(e.key==='Escape'&&$('export-menu').open){$('export-menu').open=false;$('export-menu').querySelector('summary').focus();}
});
// Read-only diagnostics used to cross-check the browser against the Python API.
window.satlab=Object.freeze({
 getState:()=>({index:state.index,time_s:F[state.index].t,source:N[state.source].id,target:N[state.target].id,metric:state.metric,disabled:[...state.off].map(i=>N[i].id),route:routes[state.index]}),
 route:(frameIndex,source,target,metric='delay',disabled=[])=>{
  const s=N.findIndex(n=>n.id===source),t=N.findIndex(n=>n.id===target);
  if(!F[frameIndex]||s<0||t<0||!['delay','hops'].includes(metric))throw new Error('Invalid frame, endpoint or metric.');
  const off=disabled.map(name=>{const i=N.findIndex(n=>n.id===name);if(i<0)throw new Error('Unknown disabled node');return i;});
  const r=route(F[frameIndex],s,t,metric,new Set(off));return {...r,path:r.path.map(i=>N[i].id)};
 }
});
populate();recalculate();
state.inspection.index=routes[state.index].path.find(i=>N[i].kind==='satellite')??initialSat;
translate();
})();
