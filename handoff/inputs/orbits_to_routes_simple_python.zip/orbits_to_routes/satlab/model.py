"""Small, inspectable satellite-network model. All distances are in kilometres.

This is an instantaneous geometric graph, not a packet-level or operational
constellation simulator. See docs/MODEL.md for equations and limitations.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from heapq import heappop, heappush
from math import asin, cos, degrees, isfinite, pi, radians, sin, sqrt
from typing import Callable, Iterable, Literal, Mapping

EARTH_RADIUS_KM = 6371.0
EARTH_MU_KM3_S2 = 398600.4418
EARTH_ROTATION_RAD_S = 7.2921150e-5
LIGHT_SPEED_KM_S = 299792.458
MODEL_VERSION = "0.2.0"
Vec3 = tuple[float, float, float]


def _number(value: float, name: str, low: float | None = None,
            high: float | None = None, *, strict_low: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
        raise ValueError(f"{name} must be a finite number; received {value!r}.")
    if low is not None and (value <= low if strict_low else value < low):
        op = ">" if strict_low else ">="
        raise ValueError(f"{name} must be {op} {low}; received {value}.")
    if high is not None and value > high:
        raise ValueError(f"{name} must be <= {high}; received {value}.")
    return float(value)


def _count(value: int, name: str, low: int = 1) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < low:
        raise ValueError(f"{name} must be an integer >= {low}; received {value!r}.")
    return value


def _name(value: str, name: str = "name") -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > 100:
        raise ValueError(f"{name} must be a non-empty string of at most 100 characters.")
    return value.strip()


def _dot(a: Vec3, b: Vec3) -> float:
    return sum(x*y for x, y in zip(a, b))


def _sub(a: Vec3, b: Vec3) -> Vec3:
    return tuple(x-y for x, y in zip(a, b))  # type: ignore[return-value]


def _norm(a: Vec3) -> float:
    return sqrt(_dot(a, a))


def line_of_sight(a: Vec3, b: Vec3) -> bool:
    """True when the segment a--b does not pass through the spherical Earth."""
    delta = _sub(b, a)
    length2 = _dot(delta, delta)
    if length2 == 0:
        return _norm(a) >= EARTH_RADIUS_KM
    u = max(0.0, min(1.0, -_dot(a, delta) / length2))
    closest = tuple(a[i] + u * delta[i] for i in range(3))
    return _norm(closest) >= EARTH_RADIUS_KM - 1e-7


def elevation_deg(ground: Vec3, satellite: Vec3) -> float:
    """Elevation above a spherical ground station's local horizon."""
    direction = _sub(satellite, ground)
    denom = _norm(direction) * _norm(ground)
    if denom == 0:
        raise ValueError("Elevation is undefined for coincident points or the Earth centre.")
    return degrees(asin(max(-1.0, min(1.0, _dot(direction, ground) / denom))))


@dataclass(frozen=True)
class Satellite:
    name: str
    altitude_km: float
    inclination_deg: float
    raan_deg: float = 0.0
    phase_deg: float = 0.0
    plane: str | None = None

    def __post_init__(self) -> None:
        _name(self.name)
        _number(self.altitude_km, "altitude_km", 0, strict_low=True)
        _number(self.inclination_deg, "inclination_deg", 0, 180)
        _number(self.raan_deg, "raan_deg")
        _number(self.phase_deg, "phase_deg")
        if self.plane is not None:
            _name(self.plane, "plane")

    @property
    def period_s(self) -> float:
        return 2*pi*sqrt((EARTH_RADIUS_KM+self.altitude_km)**3 / EARTH_MU_KM3_S2)

    def position(self, time_s: float) -> Vec3:
        """Earth-fixed Cartesian position, using a circular two-body orbit.

        t=0 is an arbitrary reference, not a real UTC epoch; the Earth-fixed
        and inertial x axes coincide at this reference.
        """
        _number(time_s, "time_s")
        radius = EARTH_RADIUS_KM + self.altitude_km
        u = radians(self.phase_deg) + 2*pi*time_s/self.period_s
        raan, inc = radians(self.raan_deg), radians(self.inclination_deg)
        x = radius*(cos(raan)*cos(u) - sin(raan)*sin(u)*cos(inc))
        y = radius*(sin(raan)*cos(u) + cos(raan)*sin(u)*cos(inc))
        z = radius*sin(u)*sin(inc)
        theta = EARTH_ROTATION_RAD_S*time_s
        return (cos(theta)*x+sin(theta)*y, -sin(theta)*x+cos(theta)*y, z)


@dataclass(frozen=True)
class GroundStation:
    name: str
    lat: float
    lon: float

    def __post_init__(self) -> None:
        _name(self.name)
        _number(self.lat, "lat", -90, 90)
        _number(self.lon, "lon", -180, 180)

    def position(self) -> Vec3:
        a, b = radians(self.lat), radians(self.lon)
        return (EARTH_RADIUS_KM*cos(a)*cos(b), EARTH_RADIUS_KM*cos(a)*sin(b),
                EARTH_RADIUS_KM*sin(a))


@dataclass(frozen=True)
class LinkPolicy:
    max_isl_km: float = 4000.0
    min_elevation_deg: float = 10.0

    def __post_init__(self) -> None:
        _number(self.max_isl_km, "max_isl_km", 0, strict_low=True)
        _number(self.min_elevation_deg, "min_elevation_deg", 0, 90)


@dataclass(frozen=True)
class NodeState:
    name: str
    kind: Literal["satellite", "ground"]
    position_km: Vec3
    lat: float
    lon: float
    altitude_km: float
    plane: str | None = None
    disabled: bool = False


@dataclass(frozen=True)
class Link:
    a: str
    b: str
    distance_km: float
    kind: Literal["isl", "access"] = "isl"

    @property
    def propagation_ms(self) -> float:
        return self.distance_km / LIGHT_SPEED_KM_S * 1000


@dataclass(frozen=True)
class Route:
    source: str
    target: str
    path: tuple[str, ...]
    links: tuple[Link, ...]
    cost: float | None
    metric: str
    reason: str = ""

    @property
    def reachable(self) -> bool:
        return bool(self.path)

    @property
    def hops(self) -> int | None:
        return len(self.links) if self.reachable else None

    @property
    def distance_km(self) -> float | None:
        return sum(edge.distance_km for edge in self.links) if self.reachable else None

    @property
    def propagation_ms(self) -> float | None:
        return sum(edge.propagation_ms for edge in self.links) if self.reachable else None

    def __bool__(self) -> bool:
        return self.reachable


EdgeCost = Callable[[Link], float]
ISLFilter = Callable[[NodeState, NodeState], bool]


@dataclass(frozen=True)
class Snapshot:
    time_s: float
    nodes: Mapping[str, NodeState]
    links: tuple[Link, ...]

    def neighbors(self, name: str) -> tuple[str, ...]:
        if name not in self.nodes:
            raise ValueError(f"Unknown node {name!r}.")
        return tuple(e.b if e.a == name else e.a for e in self.links if name in (e.a, e.b))

    def route(self, source: str, target: str, *,
              metric: str | EdgeCost = "delay") -> Route:
        """Dijkstra path; metric='delay', 'hops', or a non-negative edge cost.

        'hops' breaks ties by propagation delay; 'delay' breaks ties by hops.
        Ground stations can be endpoints but never intermediate relays.
        No path is a valid result: .reachable=False, metrics=None, .reason set.
        """
        for name in (source, target):
            if name not in self.nodes:
                raise ValueError(f"Unknown endpoint {name!r}. Available nodes: {', '.join(self.nodes)}")
        custom = callable(metric)
        if not custom and metric not in ("delay", "hops"):
            raise ValueError("metric must be 'delay', 'hops', or a callable taking one Link.")
        label = "custom" if custom else metric
        empty = lambda reason: Route(source, target, (), (), None, str(label), reason)
        if self.nodes[source].disabled or self.nodes[target].disabled:
            return empty("An endpoint is disabled.")
        if source == target:
            return Route(source, target, (source,), (), 0.0, str(label))
        adj: dict[str, list[tuple[str, Link, tuple[float, float]]]] = {k: [] for k in self.nodes}
        for e in self.links:
            if self.nodes[e.a].disabled or self.nodes[e.b].disabled:
                continue
            if any(self.nodes[k].kind == "ground" and k not in (source, target) for k in (e.a, e.b)):
                continue
            if custom:
                w = _number(metric(e), "custom edge cost", 0)  # type: ignore[operator]
                weight = (w, 1.0)
            else:
                weight = (e.propagation_ms, 1.0) if metric == "delay" else (1.0, e.propagation_ms)
            adj[e.a].append((e.b, e, weight))
            adj[e.b].append((e.a, e, weight))
        best = {source: (0.0, 0.0)}
        parents: dict[str, tuple[str, Link]] = {}
        heap = [(0.0, 0.0, source)]
        while heap:
            first, second, u = heappop(heap)
            if best.get(u) != (first, second):
                continue
            if u == target:
                break
            for v, edge, weight in adj[u]:
                candidate = (first+weight[0], second+weight[1])
                if candidate < best.get(v, (float("inf"), float("inf"))):
                    best[v] = candidate
                    parents[v] = (u, edge)
                    heappush(heap, (*candidate, v))
        if target not in best:
            return empty("No path under the current visibility, link and failure rules.")
        path, edges, node = [target], [], target
        while node != source:
            node, edge = parents[node]
            path.append(node)
            edges.append(edge)
        return Route(source, target, tuple(reversed(path)), tuple(reversed(edges)),
                     best[target][0], str(label))


class Network:
    """Beginner-friendly model builder; no third-party runtime dependencies.

    Example::

        net = Network("My constellation")
        net.add_constellation(planes=6, sats_per_plane=12, altitude_km=1000)
        net.add_ground_station("Vancouver", lat=49.28, lon=-123.12)
        net.add_ground_station("Tokyo", lat=35.68, lon=139.69)
        route = net.at(0).route("Vancouver", "Tokyo")
        net.export_html("my_network.html", source="Vancouver", target="Tokyo")
    """

    def __init__(self, name: str = "My satellite network") -> None:
        self.name = _name(name)
        self._satellites: dict[str, Satellite] = {}
        self._stations: dict[str, GroundStation] = {}
        self.policy = LinkPolicy()
        self._isl_filter: ISLFilter | None = None

    @property
    def satellites(self) -> tuple[Satellite, ...]:
        return tuple(self._satellites.values())

    @property
    def ground_stations(self) -> tuple[GroundStation, ...]:
        return tuple(self._stations.values())

    def _check_new(self, name: str) -> str:
        name = _name(name)
        if name in self._satellites or name in self._stations:
            raise ValueError(f"Node name {name!r} is already in use; every node needs a unique name.")
        return name

    def add_satellite(self, name: str, *, altitude_km: float = 1000,
                      inclination_deg: float = 53, raan_deg: float = 0,
                      phase_deg: float = 0, plane: str | None = None) -> Network:
        """Add one circular orbit. RAAN locates its plane; phase locates the satellite."""
        name = self._check_new(name)
        sat = Satellite(name, altitude_km, inclination_deg, raan_deg, phase_deg, plane)
        self._satellites[name] = sat
        return self

    def add_constellation(self, *, planes: int = 6, sats_per_plane: int = 12,
                          altitude_km: float = 1000, inclination_deg: float = 53,
                          phasing: int | None = None, raan_offset_deg: float = 0,
                          phase_offset_deg: float = 0, prefix: str = "S") -> Network:
        """Add a Walker-delta-style shell of evenly spaced circular orbits.

        Plane p has RAAN=offset+360*p/planes. Satellite j has
        phase=offset+360*j/sats_per_plane+360*phasing*p/(planes*sats_per_plane).
        Angles are degrees. p and j are zero-based. Automatic phasing is 1
        for multiple planes, or 0 for one plane.
        Distinct prefixes permit multiple shells without duplicate node names.
        """
        planes = _count(planes, "planes")
        sats_per_plane = _count(sats_per_plane, "sats_per_plane")
        if phasing is None:
            phasing = 1 if planes > 1 else 0
        _count(phasing, "phasing", 0)
        if phasing >= planes:
            raise ValueError("phasing must be smaller than planes; use phasing=0 for one plane.")
        prefix = _name(prefix, "prefix")
        _number(raan_offset_deg, "raan_offset_deg")
        _number(phase_offset_deg, "phase_offset_deg")
        # Validate all entries before mutating the network (atomic on invalid input).
        pending = []
        for p in range(planes):
            for j in range(sats_per_plane):
                name = self._check_new(f"{prefix}{p+1:02d}-{j+1:02d}")
                pending.append(Satellite(name, altitude_km, inclination_deg,
                    raan_offset_deg+360*p/planes,
                    phase_offset_deg+360*j/sats_per_plane+360*phasing*p/(planes*sats_per_plane),
                    f"{prefix}:{p+1}"))
        self._satellites.update((s.name, s) for s in pending)
        return self

    def add_ground_station(self, name: str, *, lat: float, lon: float) -> Network:
        """Add a fixed surface endpoint. North/east are positive; south/west negative."""
        name = self._check_new(name)
        self._stations[name] = GroundStation(name, lat, lon)
        return self

    def set_link_policy(self, *, max_isl_km: float = 4000,
                        min_elevation_deg: float = 10) -> Network:
        """All visible ISLs inside the range; all access links above the elevation mask.

        No degree, antenna or capacity limits are imposed by default. An ISL
        filter can remove otherwise physically eligible satellite pairs.
        """
        self.policy = LinkPolicy(max_isl_km, min_elevation_deg)
        return self

    def set_isl_filter(self, rule: ISLFilter | None) -> Network:
        """Keep an eligible ISL only when rule(a, b) returns True; None resets it.

        The graph is undirected. Write a symmetric, deterministic predicate;
        it is evaluated once per unordered pair, after the physical checks.
        """
        if rule is not None and not callable(rule):
            raise ValueError("ISL filter must be a callable taking two NodeState objects, or None.")
        self._isl_filter = rule
        return self

    def at(self, time_s: float = 0, *, disabled: Iterable[str] = ()) -> Snapshot:
        """Create an independent topology snapshot. No hidden clock or network mutation."""
        time_s = _number(time_s, "time_s")
        if isinstance(disabled, str):
            disabled = (disabled,)
        off = frozenset(disabled)
        names = set(self._satellites) | set(self._stations)
        if off-names:
            raise ValueError(f"Unknown disabled nodes: {', '.join(sorted(off-names))}")
        nodes: dict[str, NodeState] = {}
        for sat in self.satellites:
            pos = sat.position(time_s)
            radius = _norm(pos)
            from math import atan2
            lat, lon = degrees(asin(max(-1, min(1, pos[2]/radius)))), degrees(atan2(pos[1], pos[0]))
            nodes[sat.name] = NodeState(sat.name, "satellite", pos, lat, lon,
                                        sat.altitude_km, sat.plane, sat.name in off)
        for g in self.ground_stations:
            nodes[g.name] = NodeState(g.name, "ground", g.position(), g.lat, g.lon, 0, None, g.name in off)
        satellites = [n for n in nodes.values() if n.kind == "satellite" and not n.disabled]
        grounds = [n for n in nodes.values() if n.kind == "ground" and not n.disabled]
        edges = []
        for i, a in enumerate(satellites):
            for b in satellites[i+1:]:
                distance = _norm(_sub(a.position_km, b.position_km))
                if distance <= 1e-6 or distance > self.policy.max_isl_km:
                    continue
                if not line_of_sight(a.position_km, b.position_km):
                    continue
                if self._isl_filter is not None and not self._isl_filter(a, b):
                    continue
                edges.append(Link(a.name, b.name, round(distance, 6), "isl"))
        for g in grounds:
            for s in satellites:
                if elevation_deg(g.position_km, s.position_km) + 1e-9 >= self.policy.min_elevation_deg:
                    distance = _norm(_sub(g.position_km, s.position_km))
                    edges.append(Link(g.name, s.name, round(distance, 6), "access"))
        return Snapshot(time_s, nodes, tuple(edges))

    def to_dict(self) -> dict:
        """JSON-compatible configuration, with an explicit flag for Python-only callbacks."""
        return {"schema_version": 1, "model_version": MODEL_VERSION, "name": self.name,
                "satellites": [asdict(x) for x in self.satellites],
                "ground_stations": [asdict(x) for x in self.ground_stations],
                "policy": asdict(self.policy),
                "requires_python_callback": self._isl_filter is not None,
                "isl_filter_name": getattr(self._isl_filter, "__name__", None)}

    @classmethod
    def from_dict(cls, data: dict) -> Network:
        """Restore a serializable configuration; never execute code from JSON."""
        if data.get("schema_version") != 1:
            raise ValueError("Unsupported network schema_version; expected 1.")
        if data.get("requires_python_callback"):
            raise ValueError("This network uses a custom ISL callback. Re-run its Python script; JSON cannot restore code.")
        net = cls(data["name"])
        for sat in data["satellites"]:
            item = dict(sat)
            net.add_satellite(item.pop("name"), **item)
        for gs in data["ground_stations"]:
            item = dict(gs)
            net.add_ground_station(item.pop("name"), **item)
        net.set_link_policy(**data["policy"])
        return net

    def export_html(self, path: str = "my_network.html", *, source: str | None = None,
                    target: str | None = None, duration_s: float = 1800,
                    step_s: float = 15, start_s: float = 0,
                    language: str = "en", default_disabled: Iterable[str] = (),
                    metric: str = "delay", initial_time_s: float | None = None):
        """Write a single offline HTML file: Python geometry + browser graph routing.

        Includes all sampled topologies, so users can change endpoints, routing
        objective and failed satellites offline. Orbit parameters are changed
        in Python, not silently recomputed by an independent browser model.
        """
        from .export import export_html
        return export_html(self, path, source=source, target=target, duration_s=duration_s,
                           step_s=step_s, start_s=start_s, language=language,
                           default_disabled=default_disabled, metric=metric, initial_time_s=initial_time_s)

    def serve(self, *, source: str | None = None, target: str | None = None,
              port: int = 8765, open_browser: bool = True, **export_options) -> None:
        """Build and serve the lab on 127.0.0.1 only; Ctrl+C stops it.

        A local teaching/development convenience, not a production web server.
        Public sites should host the exported HTML instead.
        """
        from .export import serve
        serve(self, source=source, target=target, port=port,
              open_browser=open_browser, **export_options)
