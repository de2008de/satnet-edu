"""Export Python-computed topology snapshots into a self-contained browser lab."""
from __future__ import annotations
import json
import math
from pathlib import Path
from typing import Iterable, TYPE_CHECKING
from .model import EARTH_RADIUS_KM, EARTH_MU_KM3_S2, EARTH_ROTATION_RAD_S, LIGHT_SPEED_KM_S, _number
if TYPE_CHECKING:
    from .model import Network

ASSETS = Path(__file__).parent / "assets"


def sample_times(start_s: float, duration_s: float, step_s: float) -> list[float]:
    _number(start_s, "start_s")
    _number(duration_s, "duration_s", 0)
    _number(step_s, "step_s", 0, strict_low=True)
    count = int(math.floor(duration_s/step_s + 1e-12))
    if count > 10000:
        raise ValueError("HTML export is limited to 10,001 regular samples; increase step_s or shorten duration_s.")
    times = [start_s+i*step_s for i in range(count+1)]
    end = start_s+duration_s
    if times[-1] < end-1e-9:
        times.append(end)
    return times


def build_data(net: Network, *, source: str | None = None, target: str | None = None,
               duration_s: float = 1800, step_s: float = 15, start_s: float = 0,
               language: str = "en", default_disabled: Iterable[str] = (),
               metric: str = "delay", initial_time_s: float | None = None) -> dict:
    if language not in ("en", "zh"):
        raise ValueError("language must be 'en' or 'zh'.")
    if metric not in ("delay", "hops"):
        raise ValueError("The browser supports metric='delay' or 'hops'; custom costs are Python-only.")
    grounds = net.ground_stations
    if len(grounds) < 2:
        raise ValueError("The browser lab needs at least two ground stations. Add them with add_ground_station().")
    if not net.satellites:
        raise ValueError("The browser lab needs at least one satellite. Add satellites or a constellation first.")
    ground_names = [g.name for g in grounds]
    source, target = source or ground_names[0], target or ground_names[1]
    if source not in ground_names or target not in ground_names:
        raise ValueError("Browser endpoints must be names of ground stations in this network.")
    if source == target:
        raise ValueError("Choose two different ground stations for the browser lab.")
    times = sample_times(start_s, duration_s, step_s)
    if len(net.satellites) > 600:
        raise ValueError("This teaching HTML exporter supports at most 600 satellites; use the Python API for other experiments.")
    if initial_time_s is None:
        initial_time_s = start_s
    _number(initial_time_s, "initial_time_s", start_s, start_s+duration_s)
    initial_index = min(range(len(times)), key=lambda i: abs(times[i]-initial_time_s))
    initial = net.at(start_s)
    names = list(initial.nodes)
    indices = {name: i for i, name in enumerate(names)}
    default_disabled = list(default_disabled)
    if any(x not in net._satellites for x in default_disabled):
        raise ValueError("default_disabled must contain existing satellite names, not ground stations.")
    meta = []
    for n in initial.nodes.values():
        sat = net._satellites.get(n.name)
        meta.append({"id": n.name, "kind": n.kind, "plane": n.plane,
                     "altitude": n.altitude_km,
                     "inclination": sat.inclination_deg if sat else None,
                     "period": sat.period_s if sat else None})
    frames = []
    for t in times:
        snap = initial if t == start_s else net.at(t)
        frames.append({"t": round(t, 9),
                       "p": [[round(n.lon, 7), round(n.lat, 7)] for n in snap.nodes.values()],
                       "e": [[indices[e.a], indices[e.b], e.distance_km] for e in snap.links]})
    return {"version": 1, "language": language, "network": net.to_dict(), "nodes": meta,
            "frames": frames, "source": indices[source], "target": indices[target],
            "metric": metric, "initial_index": initial_index,
            "default_disabled": [indices[x] for x in default_disabled],
            "step_s": step_s, "start_s": start_s, "duration_s": duration_s,
            "constants": {"earth_radius_km": EARTH_RADIUS_KM, "mu_km3_s2": EARTH_MU_KM3_S2,
                          "earth_rotation_rad_s": EARTH_ROTATION_RAD_S,
                          "light_speed_km_s": LIGHT_SPEED_KM_S},
            "coastlines": json.loads((ASSETS/"coastlines.json").read_text(encoding="utf-8"))}


def render_html(data: dict) -> str:
    encoded = json.dumps(data, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    # JSON strings must never be allowed to close an inline script element.
    encoded = encoded.replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
    encoded = encoded.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    template = (ASSETS/"lab.html").read_text(encoding="utf-8")
    return template.replace("/*__LAB_CSS__*/", (ASSETS/"lab.css").read_text(encoding="utf-8")).replace(
        "/*__LAB_JS__*/", (ASSETS/"lab.js").read_text(encoding="utf-8")).replace("__LAB_DATA__", encoded)


def export_html(net: Network, path: str | Path, **options) -> Path:
    destination = Path(path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(render_html(build_data(net, **options)), encoding="utf-8")
    return destination


def serve(net: Network, *, port: int = 8765, open_browser: bool = True, **options) -> None:
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    import threading
    import webbrowser
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("port must be an integer between 1 and 65535.")
    print("Computing topology snapshots in Python ...", flush=True)
    page = render_html(build_data(net, **options)).encode("utf-8")

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.split("?", 1)[0] not in ("/", "/index.html"):
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(page)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(page)

        def log_message(self, format, *args):
            pass

    try:
        server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    except OSError as exc:
        raise OSError(f"Cannot open local port {port}. Try net.serve(port={port+1}) or use export_html().") from exc
    url = f"http://127.0.0.1:{port}"
    print(f"Open {url} | Ctrl+C to stop. Local development only.", flush=True)
    if open_browser:
        timer = threading.Timer(0.5, webbrowser.open, args=(url,))
        timer.daemon = True
        timer.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
