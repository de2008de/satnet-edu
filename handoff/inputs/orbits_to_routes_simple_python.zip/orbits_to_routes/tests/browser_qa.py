"""Optional compact-UI regression checks (Playwright + system Chromium).

Run from the project root: python tests/browser_qa.py
No browser dependencies are needed to run the model or the student-facing HTML.
"""
from __future__ import annotations
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import make_network
from satlab import Network
from satlab.export import build_data, render_html

out = ROOT / 'qa'
out.mkdir(exist_ok=True)
html_path = ROOT / 'outputs' / 'orbits_to_routes.html'
html = html_path.read_text(encoding='utf-8')
log = []

def passed(name):
    log.append(name)
    print('PASS', name, flush=True)

def open_export(page):
    if not page.locator('#export-menu').evaluate('(e)=>e.open'):
        page.locator('#export-menu > summary').click()

def save_export(page, selector, filename):
    open_export(page)
    with page.expect_download() as event:
        page.click(selector)
    path = out / filename
    event.value.save_as(str(path))
    return path

with sync_playwright() as p:
    browser = p.chromium.launch(
        headless=True,
        executable_path=os.environ.get('CHROMIUM_PATH', '/usr/bin/chromium'),
        args=['--no-sandbox'],
    )
    context = browser.new_context(viewport={'width':1440, 'height':1060}, accept_downloads=True)
    context.route('**/*', lambda route: route.abort())
    page = context.new_page()
    errors = []; requests = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('request', lambda r: requests.append(r.url))
    page.set_content(html, wait_until='load')
    assert page.evaluate('window.satlab.getState().route.reachable')
    assert not errors
    passed('Standalone compact HTML boots with all requests blocked and no JavaScript errors')

    for selector in ['#delay-chart', '.path-details', '#investigation', '#notes', '.api-section', '.model-section']:
        assert page.locator(selector).count() == 0, selector
    assert not page.locator('#inspector-panel').evaluate('(e)=>e.open')
    assert page.locator('dialog[open]').count() == 0
    assert page.locator('#network-map [data-node]').count() == 76
    passed('Removed sections are absent; the map and controls remain; optional panels start closed')
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.screenshot(path=str(out/'desktop_en.png'), full_page=True)
    passed('1440 px desktop layout has no horizontal overflow')

    net = make_network(); cases = []; expected = []
    for fi, t in enumerate(range(0,1801,15)):
        for a,b,off in [('Vancouver','Tokyo',[]),('Tokyo','London',[]),('Vancouver','Tokyo',['S03-04'])]:
            snap = net.at(t, disabled=off)
            for metric in ('delay','hops'):
                cases.append([fi,a,b,metric,off])
                expected.append(snap.route(a,b,metric=metric))
    actual = page.evaluate('(cases)=>cases.map(c=>window.satlab.route(...c))', cases)
    path_differences = 0
    for got,want in zip(actual,expected):
        assert got['reachable'] == want.reachable
        assert got['hops'] == want.hops
        if want:
            assert abs(got['ms']-want.propagation_ms) < 1e-8
            assert abs(got['distance']-want.distance_km) < 1e-5
            path_differences += tuple(got['path']) != want.path
    passed(f'{len(actual)} Python/browser comparisons agree; node-sequence differences={path_differences}')

    page.click('#step'); assert page.evaluate('window.satlab.getState().time_s') == 15
    page.locator('#timeline').evaluate('(e)=>{e.value=6;e.dispatchEvent(new Event("input",{bubbles:true}))}')
    assert page.evaluate('window.satlab.getState().time_s') == 90
    page.click('#play'); page.wait_for_timeout(500); page.click('#play')
    assert page.evaluate('window.satlab.getState().time_s') > 90
    paused = page.evaluate('window.satlab.getState().time_s')
    page.wait_for_timeout(150)
    assert page.evaluate('window.satlab.getState().time_s') == paused
    page.click('#reset')
    passed('Step, slider, play, pause and reset work without a chart')

    state = page.evaluate('window.satlab.getState()')
    first_sat = state['route']['path'][1]
    page.locator(f'#network-map [data-node="{first_sat}"]').click()
    assert page.locator('#inspector-panel').evaluate('(e)=>e.open')
    page.click('#disable')
    assert len(page.evaluate('window.satlab.getState().disabled')) == 1
    assert page.locator('#baseline-legend').is_visible()
    assert 'same simulation time' in page.locator('#change-note').inner_text()
    page.click('#restore')
    assert page.evaluate('window.satlab.getState().disabled') == []
    passed('Map selection reveals inspector; fault/restore preserves the same-time healthy baseline')

    for name in net.at(0).neighbors('Vancouver'):
        page.select_option('#node-select', label=name); page.click('#disable')
    assert not page.evaluate('window.satlab.getState().route.reachable')
    assert page.locator('#delay-value').inner_text() == '—'
    assert page.locator('#connectivity').inner_text() == 'No path'
    path = save_export(page,'#export-csv','metrics.csv')
    rows = list(csv.DictReader(path.read_text(encoding='utf-8-sig').splitlines()))
    assert len(rows) == 121
    assert rows[0]['reachable'] == 'false' and rows[0]['propagation_ms'] == ''
    page.click('#reset')
    passed('Outages show unavailable metrics, and CSV export retains 121 samples with blank unreachable delays')

    old = page.locator('#network-map').get_attribute('viewBox')
    page.select_option('#centre','0'); assert page.locator('#network-map').get_attribute('viewBox') == old
    assert 'NaN' not in page.locator('#network-map').inner_html()
    page.select_option('#centre','180')
    page.check('#show-labels'); page.uncheck('#show-links'); page.check('#show-links'); page.uncheck('#show-labels')
    page.locator('#network-map [data-edge]').first.click(force=True)
    assert '↔' in page.locator('#inspection-data').inner_text()
    assert 'Distance (km)' in page.locator('#inspection-data').inner_text()
    passed('Fixed map extent, layer toggles and direct map-link inspection work without the hop table')

    page.select_option('#source',label='Tokyo'); page.select_option('#target',label='London')
    page.locator('#timeline').evaluate('(e)=>{e.value=6;e.dispatchEvent(new Event("input",{bubbles:true}))}')
    fast = page.evaluate('window.satlab.getState().route')
    page.select_option('#metric','hops'); few = page.evaluate('window.satlab.getState().route')
    assert few['ms'] > fast['ms'] and few['hops'] < fast['hops']
    passed('Two routing objectives still produce the expected genuine contrast at t=90 s')

    config_path = save_export(page,'#export-config','experiment.json')
    saved = json.loads(config_path.read_text())
    assert saved['experiment']['metric'] == 'hops'
    assert saved['experiment']['selected_time_s'] == 90
    py_path = save_export(page,'#export-python','restored.py')
    compile(py_path.read_text(),str(py_path),'exec')
    env = dict(os.environ,PYTHONPATH=str(ROOT))
    subprocess.run([sys.executable,str(py_path)],cwd=out,env=env,check=True,capture_output=True)
    probe = context.new_page(); probe.set_content((out/'restored_experiment.html').read_text())
    rs = probe.evaluate('window.satlab.getState()')
    assert rs['metric']=='hops' and rs['time_s']==90 and rs['source']=='Tokyo'
    assert probe.locator('#delay-chart').count()==0
    probe.close()
    passed('Exported JSON and runnable Python reproduce the experiment with the compact UI')
    svg_path = save_export(page,'#export-svg','map.svg')
    ET.fromstring(svg_path.read_text())
    passed('Map export is valid standalone SVG XML')

    before = page.evaluate('window.satlab.getState()')
    page.click('[data-dialog="api-dialog"]')
    assert page.locator('#api-dialog').is_visible()
    assert 'from satlab import Network' in page.locator('#example-code').inner_text()
    page.keyboard.press('Escape')
    assert not page.locator('#api-dialog').is_visible()
    assert page.evaluate('document.activeElement.dataset.dialog') == 'api-dialog'
    page.click('[data-dialog="model-dialog"]')
    assert 'does not start Python' in page.locator('#model-dialog').inner_text()
    page.locator('#model-dialog [data-close-dialog]').click()
    assert page.evaluate('window.satlab.getState()') == before
    passed('On-demand references, Escape, focus return and close buttons preserve experiment state')

    open_export(page); page.keyboard.press('Escape')
    assert not page.locator('#export-menu').evaluate('(e)=>e.open')
    passed('Export menu can be dismissed by keyboard')

    page.click('#reset'); page.click('#language')
    assert page.locator('html').get_attribute('lang') == 'zh'
    assert page.locator('h1').inner_text() == '从轨道到路由'
    assert '模型 0.2.0' in page.locator('#sample-info').inner_text()
    page.evaluate('scrollTo(0,0)'); page.screenshot(path=str(out/'desktop_zh.png'),full_page=True)
    page.click('[data-dialog="model-dialog"]')
    assert '不会启动 Python' in page.locator('#model-dialog').inner_text()
    page.keyboard.press('Escape')
    passed('English/Chinese labels include dialogs and the model-version label')

    for lang in ['zh','en']:
        if page.locator('html').get_attribute('lang') != lang: page.click('#language')
        page.set_viewport_size({'width':390,'height':844}); page.evaluate('scrollTo(0,0)')
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        page.screenshot(path=str(out/f'mobile_{lang}.png'),full_page=True)
        page.click('[data-dialog="api-dialog"]')
        rect = page.locator('#api-dialog').bounding_box()
        assert rect['x'] >= 0 and rect['x']+rect['width'] <= 390
        page.keyboard.press('Escape')
    passed('390 px English/Chinese mobile layouts and API dialog fit horizontally')

    custom = Network('Custom four-satellite shell').add_constellation(planes=2,sats_per_plane=2,altitude_km=1500)
    custom.add_ground_station('A',lat=0,lon=0).add_ground_station('B',lat=0,lon=45)
    custom.set_isl_filter(lambda a,b:a.plane==b.plane)
    small = context.new_page(); small.set_content(render_html(build_data(custom,duration_s=45,step_s=15)))
    assert small.locator('#node-select option').count()==6
    assert small.locator('#export-python').is_disabled()
    assert '4 / 2' in small.locator('#parameters').inner_text()
    small.click('[data-dialog="api-dialog"]')
    assert 'callback' in small.locator('#callback-note').inner_text()
    small.close()
    passed('A separate Python-built network loads, and callback reconstruction guardrails remain')

    assert not errors,errors
    assert not requests,requests
    passed('No uncaught JavaScript errors or network requests during the primary-page interactions')
    # Verify direct file loading separately, without altering the network-blocked test.
    local_context = browser.new_context()
    local_page = local_context.new_page()
    try:
        local_page.goto(html_path.as_uri(),wait_until='load',timeout=15000)
        assert local_page.evaluate('window.satlab.getState().route.reachable')
        direct_file = 'PASS: direct file:// load in system Chromium'
        passed('Direct file:// navigation loads the exported HTML in system Chromium')
    except Exception as exc:
        direct_file = 'Not verified: '+str(exc).splitlines()[0]
        print(direct_file,flush=True)
    local_context.close(); browser.close()

results = {'passed':len(log),'checks':log,'route_comparisons':len(actual),
           'path_differences':path_differences,'browser':'system Chromium via Playwright',
           'direct_file':direct_file,'network_requests':len(requests),'javascript_errors':errors}
(out/'browser_qa_results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps({'passed':len(log),'direct_file':direct_file}),flush=True)
