import json
import math
import tempfile
import unittest
from pathlib import Path
from satlab import Network, NodeState, Snapshot, Link
from satlab.model import (Satellite, GroundStation, EARTH_RADIUS_KM, EARTH_ROTATION_RAD_S,
                          elevation_deg, line_of_sight)
from satlab.export import build_data, render_html, sample_times
from app import make_network


def node(name, kind='satellite'):
    return NodeState(name, kind, (7000., 0., 0.), 0., 0., 629.)


class GeometryTests(unittest.TestCase):
    def test_circular_radius_is_constant(self):
        s=Satellite('s',550,53)
        for t in (-300,0,100,3600,10000):
            self.assertAlmostEqual(math.dist(s.position(t),(0,0,0)),EARTH_RADIUS_KM+550,places=7)

    def test_equatorial_orbit(self):
        s=Satellite('s',1000,0)
        self.assertAlmostEqual(s.position(500)[2],0,places=8)

    def test_inclination_bounds_latitude(self):
        n=Network().add_satellite('s',altitude_km=1000,inclination_deg=53)
        for t in range(0,7000,100):
            self.assertLessEqual(abs(n.at(t).nodes['s'].lat),53+1e-8)

    def test_earth_rotation_after_one_orbit(self):
        n=Network().add_satellite('s',altitude_km=1000,inclination_deg=0)
        period=n.satellites[0].period_s
        self.assertAlmostEqual(n.at(period).nodes['s'].lon,-math.degrees(EARTH_ROTATION_RAD_S*period),places=7)

    def test_ground_station_spherical_radius(self):
        for lat,lon in [(0,0),(49,-123),(-90,180)]:
            self.assertAlmostEqual(math.dist(GroundStation('g',lat,lon).position(),(0,0,0)),EARTH_RADIUS_KM,places=7)

    def test_overhead_elevation(self):
        self.assertAlmostEqual(elevation_deg((6371,0,0),(7371,0,0)),90)

    def test_opposite_satellite_below_horizon(self):
        self.assertLess(elevation_deg((6371,0,0),(-7371,0,0)),0)

    def test_earth_blocks_a_link(self):
        self.assertFalse(line_of_sight((7000,0,0),(-7000,0,0)))
        self.assertTrue(line_of_sight((7000,0,0),(7000,1000,0)))

    def test_all_generated_links_respect_geometry(self):
        n=make_network()
        for t in [0,90,600]:
            s=n.at(t)
            for e in s.links:
                a,b=s.nodes[e.a],s.nodes[e.b]
                self.assertAlmostEqual(e.distance_km,math.dist(a.position_km,b.position_km),places=5)
                if e.kind=='isl':
                    self.assertLessEqual(e.distance_km,n.policy.max_isl_km+1e-6)
                    self.assertTrue(line_of_sight(a.position_km,b.position_km))
                else:
                    g,sat=(a,b) if a.kind=='ground' else (b,a)
                    self.assertGreaterEqual(elevation_deg(g.position_km,sat.position_km),n.policy.min_elevation_deg-1e-7)


class APITests(unittest.TestCase):
    def test_constellation_size(self):
        n=Network().add_constellation(planes=3,sats_per_plane=8)
        self.assertEqual(len(n.satellites),24)
        self.assertEqual(len({s.plane for s in n.satellites}),3)

    def test_one_plane_default_is_friendly(self):
        self.assertEqual(len(Network().add_constellation(planes=1,sats_per_plane=3).satellites),3)

    def test_multiple_shells(self):
        n=Network().add_constellation(planes=2,sats_per_plane=3,prefix='A')
        n.add_constellation(planes=3,sats_per_plane=4,prefix='B',altitude_km=1500)
        self.assertEqual(len(n.satellites),18)

    def test_duplicate_is_rejected_atomically(self):
        n=Network().add_satellite('S01-01')
        with self.assertRaises(ValueError):n.add_constellation(planes=2,sats_per_plane=3)
        self.assertEqual(len(n.satellites),1)

    def test_invalid_count(self):
        for count in [0,-1,True,2.5]:
            with self.assertRaises(ValueError):Network().add_constellation(planes=count)

    def test_invalid_coordinates(self):
        for lat,lon in [(91,0),(0,181),(math.nan,0)]:
            with self.assertRaises(ValueError):Network().add_ground_station('G',lat=lat,lon=lon)

    def test_invalid_orbits(self):
        for kwargs in [dict(altitude_km=-1),dict(inclination_deg=181),dict(phase_deg=math.inf)]:
            with self.assertRaises(ValueError):Network().add_satellite('s',**kwargs)

    def test_disabled_snapshot_does_not_mutate_network(self):
        n=make_network();name='S03-04'
        original=n.at(0);off=n.at(0,disabled=[name]);after=n.at(0)
        self.assertTrue(off.nodes[name].disabled)
        self.assertFalse(any(name in (e.a,e.b) for e in off.links))
        self.assertEqual(original.links,after.links)

    def test_unknown_names_and_metric(self):
        n=make_network()
        with self.assertRaises(ValueError):n.at(0,disabled=['missing'])
        with self.assertRaises(ValueError):n.at(0).route('missing','Tokyo')
        with self.assertRaises(ValueError):n.at(0).route('Vancouver','Tokyo',metric='bandwidth')

    def test_json_round_trip(self):
        n=make_network();r=Network.from_dict(json.loads(json.dumps(n.to_dict())))
        self.assertEqual(n.at(90).links,r.at(90).links)
        self.assertEqual(n.to_dict(),r.to_dict())

    def test_custom_isl_filter_is_applied(self):
        n=make_network().set_isl_filter(lambda a,b:a.plane==b.plane)
        s=n.at(0)
        self.assertTrue(all(s.nodes[e.a].plane==s.nodes[e.b].plane for e in s.links if e.kind=='isl'))
        n.set_isl_filter(lambda a,b:False)
        self.assertFalse(any(e.kind=='isl' for e in n.at(0).links))
        self.assertTrue(any(e.kind=='access' for e in n.at(0).links))

    def test_callback_round_trip_cannot_silently_drop_rule(self):
        n=make_network().set_isl_filter(lambda a,b:True)
        self.assertTrue(n.to_dict()['requires_python_callback'])
        with self.assertRaises(ValueError):Network.from_dict(n.to_dict())


class RoutingTests(unittest.TestCase):
    def setUp(self):
        self.snap=Snapshot(0,{x:node(x) for x in ['A','B','C','D']},
            (Link('A','B',12),Link('A','C',3),Link('C','D',3),Link('D','B',3)))

    def test_two_objectives_choose_different_routes(self):
        r=self.snap.route('A','B');h=self.snap.route('A','B',metric='hops')
        self.assertEqual(r.path,('A','C','D','B'))
        self.assertEqual(h.path,('A','B'))
        self.assertLess(r.propagation_ms,h.propagation_ms)

    def test_custom_nonnegative_cost(self):
        r=self.snap.route('A','B',metric=lambda e:1)
        self.assertEqual(r.path,('A','B'))

    def test_negative_and_nan_cost_rejected(self):
        for value in [-1,math.nan]:
            with self.assertRaises(ValueError):self.snap.route('A','B',metric=lambda e:value)

    def test_zero_cost_has_no_parent_cycle(self):
        self.assertTrue(self.snap.route('A','B',metric=lambda e:0))

    def test_station_cannot_be_a_relay(self):
        s=Snapshot(0,{'A':node('A','ground'),'B':node('B','ground'),'G':node('G','ground'),
                      'X':node('X'),'Y':node('Y')},
                    (Link('A','X',1),Link('X','G',1),Link('G','Y',1),Link('Y','B',1)))
        self.assertFalse(s.route('A','B').reachable)

    def test_no_path_has_null_metrics(self):
        s=Snapshot(0,{'A':node('A'),'B':node('B')},())
        r=s.route('A','B')
        self.assertFalse(r);self.assertIsNone(r.propagation_ms);self.assertIsNone(r.hops)
        self.assertTrue(r.reason)

    def test_self_route(self):
        r=self.snap.route('A','A');self.assertTrue(r);self.assertEqual(r.hops,0)
        self.assertEqual(r.propagation_ms,0)

    def test_bundled_contrasting_case(self):
        s=make_network().at(90)
        fast=s.route('Tokyo','London');few=s.route('Tokyo','London',metric='hops')
        self.assertGreater(fast.hops,few.hops)
        self.assertLess(fast.propagation_ms,few.propagation_ms)

    def test_path_metrics_are_sums_of_edges(self):
        r=make_network().at(0).route('Vancouver','Tokyo')
        self.assertEqual(r.distance_km,sum(e.distance_km for e in r.links))
        self.assertEqual(r.propagation_ms,sum(e.propagation_ms for e in r.links))


class ExportTests(unittest.TestCase):
    def test_sampling_includes_nonaligned_endpoint(self):
        self.assertEqual(sample_times(10,35,15),[10,25,40,45])
        self.assertEqual(sample_times(0,0,15),[0])

    def test_invalid_sampling(self):
        with self.assertRaises(ValueError):sample_times(0,20,0)
        with self.assertRaises(ValueError):sample_times(0,-1,5)

    def test_snapshot_data_matches_python(self):
        n=make_network();data=build_data(n,duration_s=30,step_s=15)
        self.assertEqual(len(data['frames']),3)
        f=data['frames'][1];s=n.at(15)
        self.assertEqual(len(f['e']),len(s.links))
        self.assertEqual([e[2] for e in f['e']],[e.distance_km for e in s.links])

    def test_initial_state_is_recorded(self):
        d=build_data(make_network(),duration_s=90,metric='hops',initial_time_s=90,default_disabled=['S01-01'])
        self.assertEqual(d['metric'],'hops');self.assertEqual(d['frames'][d['initial_index']]['t'],90)
        self.assertEqual(len(d['default_disabled']),1)

    def test_html_export_has_no_template_tokens(self):
        n=make_network()
        with tempfile.TemporaryDirectory() as tmp:
            p=n.export_html(Path(tmp)/'lab.html',duration_s=15)
            text=p.read_text()
            self.assertNotIn('__LAB_DATA__',text);self.assertNotIn('/*__LAB_JS__*/',text)
            self.assertIn('network-map',text)

    def test_script_terminators_are_escaped(self):
        n=make_network();n.name='</script><script>alert("bad")</script>'
        text=render_html(build_data(n,duration_s=0))
        self.assertNotIn('</script><script>alert',text)
        self.assertIn('\\u003c/script\\u003e',text)

    def test_insufficient_network_rejected(self):
        with self.assertRaises(ValueError):build_data(Network())


if __name__=='__main__':unittest.main(verbosity=2)
