# Licensing and attribution notes

The source code and instructional text in this delivery were newly generated for this project. No project-wide public-release license has been selected; choose one before presenting the repository as open source. This file is not a grant of rights over third-party material.

The bundled `satlab/assets/coastlines.json` contains Natural Earth-derived land outlines. Natural Earth map data are public domain, according to https://www.naturalearthdata.com/about/terms-of-use/ . A courtesy credit and provenance are retained in the page and model notes.

No font files, remote map tiles, satellite-provider logos or third-party application source code are included. The UDTJ name and journal-style layout follow the user-provided reference; this prototype has not been published to or endorsed by a journal through this workflow.
