"""Run from the project root: python -m examples.first_network"""
from satlab import Network

net = Network("My first constellation")
net.add_constellation(
    planes=6, sats_per_plane=12,
    altitude_km=1000, inclination_deg=53,
)
net.add_ground_station("Vancouver", lat=49.28, lon=-123.12)
net.add_ground_station("Tokyo", lat=35.68, lon=139.69)
net.set_link_policy(max_isl_km=4000, min_elevation_deg=10)

snapshot = net.at(0)  # Seconds from an arbitrary reference, not a UTC date.
route = snapshot.route("Vancouver", "Tokyo", metric="delay")
if route.reachable:
    print("Path:", " -> ".join(route.path))
    print("One-way propagation delay:", route.propagation_ms, "ms")
else:
    print(route.reason)

# This is a single HTML file, with no server, map tiles or font downloads.
path = net.export_html(
    "outputs/my_network.html", source="Vancouver", target="Tokyo",
    duration_s=1800, step_s=15,
)
print("Open:", path)
