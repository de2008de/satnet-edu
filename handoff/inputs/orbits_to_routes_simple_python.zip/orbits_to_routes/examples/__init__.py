"""Run examples from the project root with python -m examples.first_network."""
