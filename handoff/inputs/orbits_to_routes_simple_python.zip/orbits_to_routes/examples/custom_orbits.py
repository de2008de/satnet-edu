"""Define each orbit yourself. Run: python -m examples.custom_orbits"""
from satlab import Network

net = Network("An equatorial ring")
for i in range(12):
    net.add_satellite(
        f"E{i+1:02d}", altitude_km=1200,
        inclination_deg=0, raan_deg=0,
        phase_deg=i*30, plane="equatorial",
    )
# These are synthetic endpoints, not named cities.
net.add_ground_station("West", lat=0, lon=10)
net.add_ground_station("East", lat=0, lon=80)
net.set_link_policy(max_isl_km=4500, min_elevation_deg=10)
print(net.at(0).route("West", "East"))
print(net.export_html("outputs/equatorial_ring.html", duration_s=1200, step_s=30))
