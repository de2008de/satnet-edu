"""A reproducible parameter-controlled comparison. Run: python -m examples.compare_routes"""
import csv
from pathlib import Path
from app import make_network

net = make_network()
output = Path("outputs/comparison.csv")
output.parent.mkdir(exist_ok=True)
with output.open("w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["time_s", "metric", "reachable", "hops", "distance_km", "propagation_ms", "path"])
    for t in range(0, 1801, 15):
        snapshot = net.at(t)  # Both objectives use exactly this snapshot.
        for metric in ("delay", "hops"):
            r = snapshot.route("Tokyo", "London", metric=metric)
            writer.writerow([t, metric, r.reachable, r.hops, r.distance_km,
                             r.propagation_ms, " -> ".join(r.path)])
print("Saved:", output.resolve())

# Optional custom routing objective: a synthetic per-hop penalty, not measured delay.
snapshot = net.at(90)
route = snapshot.route("Tokyo", "London", metric=lambda edge: edge.propagation_ms + 0.5)
print("Custom objective:", route.cost, "| Pure propagation:", route.propagation_ms, "ms")
# Custom cost callbacks are Python-only; the browser exposes delay and hops.
