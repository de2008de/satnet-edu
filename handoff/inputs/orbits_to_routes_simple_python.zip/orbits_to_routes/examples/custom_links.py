"""An ISL rule can only remove physically eligible pairs.

Run: python -m examples.custom_links
"""
from satlab import Network, NodeState


def same_plane(a: NodeState, b: NodeState) -> bool:
    """No cross-plane links; symmetric and deterministic."""
    return a.plane == b.plane


net = Network("In-plane links only")
net.add_constellation(planes=6, sats_per_plane=12, altitude_km=1000)
net.add_ground_station("Vancouver", lat=49.28, lon=-123.12)
net.add_ground_station("Tokyo", lat=35.68, lon=139.69)
net.set_isl_filter(same_plane)

snapshot = net.at(0)
print("Eligible links retained:", len(snapshot.links))
route = snapshot.route("Vancouver", "Tokyo")
print(route.path if route else route.reason)
# The callback is evaluated by Python. Its resulting topology is embedded in HTML.
# Keep this Python script: arbitrary callback code cannot be restored from JSON.
print(net.export_html("outputs/in_plane_only.html", duration_s=900, step_s=30))
