# INFOCOM 2025: Commercial Dishes Can Be My Ladder: Sustainable and Collaborative Data Offloading in LEO Satellite Networks

UserGS_simulation

The results were produced by using Python 3.11.

To run simulation and produce data, run:

```
cd source
python main.py
```

The simulation data will be stored in the output folder.

To debug, make DEBUG = True in main.py. This will change the simulation to be single thread with auction algorithm only. Then, we can place debugger point and run debugger.

After the simulation is completed, run this to make plot:

```
cd source
python plot.py
```

The plots will be in the output folder.

To get the statistics such as percentage of better performance, run:

```
cd source
python statistics.py
```

Some csv files with statistics will be stored in the output folder.
