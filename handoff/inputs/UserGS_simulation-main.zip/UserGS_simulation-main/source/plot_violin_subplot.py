from matplotlib import rcParams
import matplotlib.pyplot as plt
import os
import numpy as np
from models.global_var import AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION, MAX_BUDGETS
from models.enum import Algorithms
from plot import ALGO_TO_PLOT, ALGO_INFO, LINE_WIDTH, LINE_STYLES

rcParams['font.family'] = 'serif'
rcParams['font.serif'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['font.size'] = 32

def plot_violin(ax, constellation_name, max_budget=MAX_BUDGETS[0], base_dir='output', failure_rate=AVG_FAILURE_RATES[0], bad_dish_prob=BAD_DISH_PROBS[0], failure_rate_fluctuation=FAILURE_RATE_FLUCTUATION[0], metric='uc_ratio'):
    label_fontsize = 24
    tick_fontsize = 20
    data = []
    labels = []
    colors = []

    for algo in ALGO_TO_PLOT:
        if algo == Algorithms.DEFAULT:
            continue

        if metric == 'uc_ratio':
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_uc_ratio.csv")
        else:
            csv_file_path = os.path.join(
                base_dir,
                constellation_name,
                f'max_budget_{max_budget}',
                f'failure_rate_{failure_rate}',
                f'bad_dish_prob_{bad_dish_prob}',
                f'failure_rate_fluctuation_{failure_rate_fluctuation}',
                algo.name,
                f"{algo.name}_{metric}.csv"
            )

        if not os.path.isfile(csv_file_path):
            print(f"File not found: {csv_file_path}")
            continue

        # Read the CSV file
        algo_data = []
        if metric == 'uc_ratio':
            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    algo_data.extend(values)
        else:
            algo_data = np.loadtxt(csv_file_path, delimiter=',')

        data.append(algo_data)
        labels.append(ALGO_INFO[algo.name][0])
        colors.append(ALGO_INFO[algo.name][1])  # Get the color for each algorithm

    # Plot the violin plot
    parts = ax.violinplot(data, showmeans=False, showmedians=True)
    
    for idx, pc in enumerate(parts['bodies']):
        pc.set_facecolor(colors[idx])
        pc.set_edgecolor('black')
        pc.set_alpha(1)
    
    ax.set_xticks(np.arange(1, len(labels) + 1))
    ax.set_xticklabels(labels, fontsize=label_fontsize, rotation=45, ha='right')
    ax.set_ylabel('Value', fontsize=label_fontsize)
    ax.tick_params(axis='both', which='major', labelsize=tick_fontsize)
    ax.grid(True)

    if metric == 'uc_ratio':
        ax.set_xlabel('Ratio between utility and cost', fontsize=label_fontsize)
    else:
        ax.set_xlabel(metric.replace('_', ' ').capitalize(), fontsize=label_fontsize)


def main():
    max_budget = MAX_BUDGETS[0]
    failure_rate = AVG_FAILURE_RATES[0]
    bad_dish_prob = BAD_DISH_PROBS[0]
    failure_rate_fluctuation = FAILURE_RATE_FLUCTUATION[0]
    
    FIXED_BUDGET_BASE_DIR = 'output/FIXED_BUDGET'
    
    constellation_names = ['CONSTELLATION_NAME.STARLINK_550', 'CONSTELLATION_NAME.ONEWEB_18_40_1200']
    
    fig, axs = plt.subplots(2, 4, figsize=(32, 16))
    fig.subplots_adjust(wspace=0.4, hspace=0.6)

    metrics = ['uc_ratio', 'total_life_consumption', 'total_delay_ms', 'total_energy_consumption']
    
    for row, cname in enumerate(constellation_names):
        for col, metric in enumerate(metrics):
            plot_violin(axs[row, col], constellation_name=cname, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=FIXED_BUDGET_BASE_DIR, metric=metric)

    handles, labels = axs[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', ncol=4, fontsize=24)
    
    # Adding subtitles below each row
    fig.text(0.5, 0.47, 'Performance metric comparison in Starlink', ha='center', fontsize=28)
    fig.text(0.5, 0.02, 'Performance metric comparison in OneWeb', ha='center', fontsize=28)
    
    plt.subplots_adjust(top=0.9, bottom=0.1)  # Adjust the top and bottom to give more space
    fig.tight_layout(rect=[0, 0, 1, 0.95])

    plt.savefig(os.path.join('output', 'violin_plots_all_metrics.pdf'), format='pdf')
    plt.close()


if __name__ == '__main__':
    main()
