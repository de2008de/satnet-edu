from models.enum import Algorithms
from matplotlib import rcParams
import os, csv
import matplotlib.pyplot as plt
import numpy as np
from statsmodels.distributions.empirical_distribution import ECDF
from models.global_var import AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION, MAX_BUDGETS


ALGO_INFO = {
    'REVERSE_AUCTION': ('SusCO', '#FF6961'),  # Light Red (Pastel Red)
    'SERVICE': ('SERvICE', '#00BFFF'),  # Medium (Deep Sky Blue)
    'SUSTAINABILITY': ('SMTSN', '#BF5700'),  # Dark (Burnt Orange)
    'SERVICE_MARGIN_5': ('LBSQ-5', '#0096FF'), 
    'SUSTAINABILITY_MARGIN_5': ('SLSQ-5', '#FFA07A'),
    'FALCON': ('FALCON', '#32CD32'),  # Lime Green
    'FALCON_MARGIN_5': ('FALCON-5', '#228B22')  # Forest Green
}


ALGO_TO_PLOT = [
    Algorithms.REVERSE_AUCTION,
    Algorithms.SERVICE,
    Algorithms.SUSTAINABILITY,
    Algorithms.FALCON,
]


# Patterns for bars to distinguish in grayscale
PATTERNS = ('//', 'X', '\\', '-', '++')
SCATTER_PATTERNS = ('o', 's', '^', 'D', 'P')  # 'D' for diamond, 'P' for plus (filled)
LINE_STYLES = ['-', '--', '-.', ':', (0, (3, 5, 1, 5))]
LINE_WIDTH = 5
MARKER_SIZE = 14


rcParams['font.family'] = 'serif'
rcParams['font.serif'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['font.size'] = 32


constellation_mapping = {
    'CONSTELLATION_NAME.IRIDIUM_6_11_780': {'num_orbits': 6, 'sats_per_orbit': 11},
    'CONSTELLATION_NAME.LEO_36_11_550': {'num_orbits': 36, 'sats_per_orbit': 11},
    'CONSTELLATION_NAME.LEO_48_11_550': {'num_orbits': 48, 'sats_per_orbit': 11},
    'CONSTELLATION_NAME.KUIPER_28_28_590': {'num_orbits': 28, 'sats_per_orbit': 28},
    'CONSTELLATION_NAME.LEO_72_33_550': {'num_orbits': 72, 'sats_per_orbit': 33},
    'CONSTELLATION_NAME.LEO_72_44_550': {'num_orbits': 72, 'sats_per_orbit': 44},
    'CONSTELLATION_NAME.LEO_72_66_550': {'num_orbits': 72, 'sats_per_orbit': 66},
    'CONSTELLATION_NAME.LEO_84_66_550': {'num_orbits': 84, 'sats_per_orbit': 66},
    'CONSTELLATION_NAME.STARLINK_550': {'num_orbits': 72, 'sats_per_orbit': 22},
    'CONSTELLATION_NAME.ONEWEB_18_40_1200': {'num_orbits': 18, 'sats_per_orbit': 40},
    'CONSTELLATION_NAME.TELESAT_6_12_1000': {'num_orbits': 6, 'sats_per_orbit': 12},
}


def plot_uc_ratio_ecdf(constellation_name, max_budget=MAX_BUDGETS[0], base_dir='output', output_dir='output', failure_rate=AVG_FAILURE_RATES[0], bad_dish_prob=BAD_DISH_PROBS[0], failure_rate_fluctuation=FAILURE_RATE_FLUCTUATION[0]):
    aggregated_uc_ratios = {}  # Dictionary to store the aggregated uc ratios for each algorithm

    for algo in ALGO_TO_PLOT:
        if algo == Algorithms.DEFAULT:
            continue
        csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_uc_ratio.csv")
        
        if not os.path.isfile(csv_file_path):
            print(f"File not found: {csv_file_path}")
            continue

        # Read the entire CSV file line by line and aggregate UC ratios
        all_uc_ratios = []
        with open(csv_file_path, 'r') as file:
            for line in file:
                values = [float(val) for val in line.strip().split(',')]
                all_uc_ratios.extend(values)

        aggregated_uc_ratios[algo.name] = all_uc_ratios

    plt.figure(figsize=(8, 6))
    idx = 0
    for algo, uc_ratios in aggregated_uc_ratios.items():
        ecdf = ECDF(uc_ratios)
        plt.plot(ecdf.x, ecdf.y, label=ALGO_INFO[algo][0], linestyle=LINE_STYLES[idx % len(LINE_STYLES)], color=ALGO_INFO[algo][1], linewidth=LINE_WIDTH)
        idx += 1

    plt.xlabel('Ratio between utility and cost')
    plt.ylabel('CDF')
    # plt.title('ECDF of Aggregated UC Ratio Across All Intervals')
    plt.legend()
    plt.grid(True)
    plt.tick_params(axis='both', which='major', labelsize=28)
    plt.tight_layout()

    constellation_name_safe = constellation_name.replace('.', '_')
    plt.savefig(os.path.join(output_dir, f'aggregated_uc_ratio_ecdf_max_budget_{constellation_name_safe}_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_fluctuate_{failure_rate_fluctuation}.pdf'), format='pdf')
    plt.close()


def plot_avg_uc_ratio_bar_chart(constellation_name, max_budget=MAX_BUDGETS[0], base_dir='output', output_dir='output', failure_rate=AVG_FAILURE_RATES[0], failure_rate_fluctuation=FAILURE_RATE_FLUCTUATION[0], label_fontsize=12, ticklabel_fontsize=10, legend_fontsize=12):
    # Specific bad_dish_prob values to use
    bad_dish_probs = [0.05, 0.1, 0.2, 0.3]

    # Dictionary to store the aggregated UC ratios for each algorithm and bad_dish_prob
    aggregated_uc_ratios = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_uc_ratios[algo.name] = {}
            for bdp in bad_dish_probs:
                aggregated_uc_ratios[algo.name][bdp] = []

    for bad_dish_prob in bad_dish_probs:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_uc_ratio.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                continue

            # Read the entire CSV file line by line and aggregate UC ratios
            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_uc_ratios[algo.name][bad_dish_prob].extend(values)

    # Compute the average UC ratio for each combination of algorithm and bad_dish_prob
    average_uc_ratios = {}
    for algo, bdp_dict in aggregated_uc_ratios.items():
        average_uc_ratios[algo] = {}
        for bdp, uc_ratios in bdp_dict.items():
            if uc_ratios:
                average_uc_ratios[algo][bdp] = np.mean(uc_ratios)
            else:
                average_uc_ratios[algo][bdp] = 0

    # Plotting
    fig, ax = plt.subplots(figsize=(8, 5))

    # Number of bars per group
    n_bars_per_group = 0
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            n_bars_per_group += 1

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(bad_dish_probs))
    
    max_avg_uc_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_uc_values = []
        for bdp in bad_dish_probs:
            avg_uc_values.append(average_uc_ratios[algo.name][bdp])
            if average_uc_ratios[algo.name][bdp] > max_avg_uc_value:
                max_avg_uc_value = average_uc_ratios[algo.name][bdp]
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_uc_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    label_fontsize = 30
    legend_fontsize = 22
    ticklabel_fontsize = 22

    ax.set_xlabel('Unreliable dish population (%)', fontsize=label_fontsize)
    ax.set_ylabel('Avg. utility-to-cost ratio', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([str(int(bdp*100)) for bdp in bad_dish_probs])
    ax.tick_params(axis='both', labelsize=ticklabel_fontsize)
    ax.legend(fontsize=legend_fontsize, loc='upper center', bbox_to_anchor=(0.5, 1.025), ncol=2, frameon=True, handletextpad=0.5, columnspacing=1.0)
    y_max = max_avg_uc_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')

    # Save the plot
    constellation_name_safe = constellation_name.replace('.', '_')
    plt.savefig(os.path.join(output_dir, f'average_uc_ratio_max_budget_{constellation_name_safe}_{max_budget}_failure_rate_{failure_rate}_fluctuate_{failure_rate_fluctuation}.pdf'), format='pdf', bbox_inches='tight')
    plt.close()


def plot_avg_uc_ratio_bar_chart_over_network_sizes(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y = []

    selected_constellations = [
        'CONSTELLATION_NAME.TELESAT_6_12_1000',
        'CONSTELLATION_NAME.ONEWEB_18_40_1200',
        'CONSTELLATION_NAME.KUIPER_28_28_590',
        'CONSTELLATION_NAME.STARLINK_550'
    ]

    # Dictionary to store the aggregated UC ratios for each algorithm
    aggregated_uc_ratios = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_uc_ratios[algo.name] = {}
            for constellation_name in selected_constellations:
                aggregated_uc_ratios[algo.name][constellation_name] = []

    for constellation_name in selected_constellations:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_uc_ratio.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                raise FileNotFoundError

            # Read the entire CSV file line by line and aggregate UC ratios
            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_uc_ratios[algo.name][constellation_name].extend(values)

    # Compute the average UC ratio for each algorithm
    average_uc_ratios = {}
    for algo, uc_ratios in aggregated_uc_ratios.items():
        average_uc_ratios[algo] = {}
        for constellation_name, uc_ratio_values in uc_ratios.items():
            if uc_ratio_values:
                average_uc_ratios[algo][constellation_name] = np.mean(uc_ratio_values)
            else:
                average_uc_ratios[algo][constellation_name] = 0

    # Plotting
    fig, ax = plt.subplots(figsize=(8, 5))

    # Number of bars per group
    n_bars_per_group = len(ALGO_TO_PLOT)

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(selected_constellations))
    
    max_avg_uc_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_uc_values = []
        for constellation_name in selected_constellations:
            avg_uc_values.append(average_uc_ratios[algo.name][constellation_name])
            if average_uc_ratios[algo.name][constellation_name] > max_avg_uc_value:
                max_avg_uc_value = average_uc_ratios[algo.name][constellation_name]
        
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_uc_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    label_fontsize = 30
    legend_fontsize = 22
    ticklabel_fontsize = 22

    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}

    ax.set_xlabel('Constellation', fontsize=label_fontsize)
    ax.set_ylabel('Avg. utility-to-cost ratio', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([text_labels[str(constellation_mapping[name]['num_orbits'] * constellation_mapping[name]['sats_per_orbit'])] for name in selected_constellations])
    ax.tick_params(axis='both', labelsize=ticklabel_fontsize)
    ax.legend(fontsize=legend_fontsize, loc='upper center', bbox_to_anchor=(0.5, 1.025), ncol=2, frameon=True, handletextpad=0.5, columnspacing=1.0)
    y_max = max_avg_uc_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')

    # Save the plot
    plt.savefig(os.path.join(output_dir, f'average_uc_ratio_over_network_sizes_max_budget_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_fluctuate_{fluctuation}.pdf'), format='pdf', bbox_inches='tight')
    plt.close()


def plot_reduced_life_consumption_over_network_sizes(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y = []

    selected_constellations = [
        'CONSTELLATION_NAME.TELESAT_6_12_1000',
        'CONSTELLATION_NAME.ONEWEB_18_40_1200',
        'CONSTELLATION_NAME.KUIPER_28_28_590',
        'CONSTELLATION_NAME.STARLINK_550'
    ]

    aggregated_reduced_life_consumption = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_reduced_life_consumption[algo.name] = {}
            for constellation_name in selected_constellations:
                aggregated_reduced_life_consumption[algo.name][constellation_name] = []

    for constellation_name in selected_constellations:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_conserved_life_consumption.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                raise FileNotFoundError

            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_reduced_life_consumption[algo.name][constellation_name].extend([np.sum(values)])

    average_reduced_life_consumption = {}
    for algo, reduced_life_consumption in aggregated_reduced_life_consumption.items():
        average_reduced_life_consumption[algo] = {}
        for constellation_name, reduced_life_consumption_values in reduced_life_consumption.items():
            if reduced_life_consumption_values:
                average_reduced_life_consumption[algo][constellation_name] = np.mean(reduced_life_consumption_values)
            else:
                average_reduced_life_consumption[algo][constellation_name] = 0

    # Plotting
    fig, ax = plt.subplots(figsize=(8, 5))

    # Number of bars per group
    n_bars_per_group = len(ALGO_TO_PLOT)

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(selected_constellations))
    
    max_avg_reduced_life_consumption_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_reduced_life_consumption_values = []
        for constellation_name in selected_constellations:
            avg_reduced_life_consumption_values.append(average_reduced_life_consumption[algo.name][constellation_name])
            if average_reduced_life_consumption[algo.name][constellation_name] > max_avg_reduced_life_consumption_value:
                max_avg_reduced_life_consumption_value = average_reduced_life_consumption[algo.name][constellation_name]
        
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_reduced_life_consumption_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    label_fontsize = 30
    legend_fontsize = 22
    ticklabel_fontsize = 22

    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}

    ax.set_xlabel('Constellation', fontsize=label_fontsize)
    ax.set_ylabel('Avg. reduced\nlife consumption', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([text_labels[str(constellation_mapping[name]['num_orbits'] * constellation_mapping[name]['sats_per_orbit'])] for name in selected_constellations])
    ax.tick_params(axis='both', labelsize=ticklabel_fontsize)
    ax.legend(fontsize=legend_fontsize, loc='upper center', bbox_to_anchor=(0.5, 1.025), ncol=2, frameon=True, handletextpad=0.5, columnspacing=1.0)
    y_max = max_avg_reduced_life_consumption_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')

    # Save the plot
    plt.savefig(os.path.join(output_dir, f'average_reduced_life_consumption_over_network_sizes_max_budget_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_fluctuate_{fluctuation}.pdf'), format='pdf', bbox_inches='tight')
    plt.close()


def plot_reduced_energy_consumption_over_network_sizes(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y = []

    selected_constellations = [
        'CONSTELLATION_NAME.TELESAT_6_12_1000',
        'CONSTELLATION_NAME.ONEWEB_18_40_1200',
        'CONSTELLATION_NAME.KUIPER_28_28_590',
        'CONSTELLATION_NAME.STARLINK_550'
    ]

    aggregated_reduced_energy_consumption = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_reduced_energy_consumption[algo.name] = {}
            for constellation_name in selected_constellations:
                aggregated_reduced_energy_consumption[algo.name][constellation_name] = []

    for constellation_name in selected_constellations:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_conserved_energy_consumption.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                raise FileNotFoundError

            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_reduced_energy_consumption[algo.name][constellation_name].extend([np.sum(values)])

    average_reduced_energy_consumption = {}
    for algo, reduced_energy_consumption in aggregated_reduced_energy_consumption.items():
        average_reduced_energy_consumption[algo] = {}
        for constellation_name, reduced_energy_consumption_values in reduced_energy_consumption.items():
            if reduced_energy_consumption_values:
                average_reduced_energy_consumption[algo][constellation_name] = np.mean(reduced_energy_consumption_values)
            else:
                average_reduced_energy_consumption[algo][constellation_name] = 0

    # Plotting
    fig, ax = plt.subplots(figsize=(8, 5))

    # Number of bars per group
    n_bars_per_group = len(ALGO_TO_PLOT)

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(selected_constellations))
    
    max_avg_reduced_energy_consumption_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_reduced_energy_consumption_values = []
        for constellation_name in selected_constellations:
            avg_reduced_energy_consumption_values.append(average_reduced_energy_consumption[algo.name][constellation_name])
            if average_reduced_energy_consumption[algo.name][constellation_name] > max_avg_reduced_energy_consumption_value:
                max_avg_reduced_energy_consumption_value = average_reduced_energy_consumption[algo.name][constellation_name]
        
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_reduced_energy_consumption_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    label_fontsize = 30
    legend_fontsize = 22
    ticklabel_fontsize = 22

    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}

    ax.set_xlabel('Constellation', fontsize=label_fontsize)
    ax.set_ylabel('Avg. reduced\nenergy consumption', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([text_labels[str(constellation_mapping[name]['num_orbits'] * constellation_mapping[name]['sats_per_orbit'])] for name in selected_constellations])
    ax.tick_params(axis='both', labelsize=ticklabel_fontsize)
    ax.legend(fontsize=legend_fontsize, loc='upper center', bbox_to_anchor=(0.5, 1.025), ncol=2, frameon=True, handletextpad=0.5, columnspacing=1.0)
    y_max = max_avg_reduced_energy_consumption_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')

    # Save the plot
    plt.savefig(os.path.join(output_dir, f'average_reduced_energy_consumption_over_network_sizes_max_budget_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_fluctuate_{fluctuation}.pdf'), format='pdf', bbox_inches='tight')
    plt.close()


def plot_reduced_total_latency_over_network_sizes(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y = []

    selected_constellations = [
        'CONSTELLATION_NAME.TELESAT_6_12_1000',
        'CONSTELLATION_NAME.ONEWEB_18_40_1200',
        'CONSTELLATION_NAME.KUIPER_28_28_590',
        'CONSTELLATION_NAME.STARLINK_550'
    ]

    aggregated_reduced_total_latency = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_reduced_total_latency[algo.name] = {}
            for constellation_name in selected_constellations:
                aggregated_reduced_total_latency[algo.name][constellation_name] = []

    for constellation_name in selected_constellations:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_reduced_end_to_end_delay.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                raise FileNotFoundError

            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_reduced_total_latency[algo.name][constellation_name].extend([np.sum(values)])

    average_reduced_total_latency = {}
    for algo, reduced_total_latency in aggregated_reduced_total_latency.items():
        average_reduced_total_latency[algo] = {}
        for constellation_name, reduced_total_latency_values in reduced_total_latency.items():
            if reduced_total_latency_values:
                average_reduced_total_latency[algo][constellation_name] = np.mean(reduced_total_latency_values)
            else:
                average_reduced_total_latency[algo][constellation_name] = 0

    # Plotting
    fig, ax = plt.subplots(figsize=(8, 5))

    # Number of bars per group
    n_bars_per_group = len(ALGO_TO_PLOT)

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(selected_constellations))
    
    max_avg_reduced_total_latency_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_reduced_total_latency_values = []
        for constellation_name in selected_constellations:
            avg_reduced_total_latency_values.append(average_reduced_total_latency[algo.name][constellation_name])
            if average_reduced_total_latency[algo.name][constellation_name] > max_avg_reduced_total_latency_value:
                max_avg_reduced_total_latency_value = average_reduced_total_latency[algo.name][constellation_name]
        
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_reduced_total_latency_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    label_fontsize = 30
    legend_fontsize = 22
    ticklabel_fontsize = 22

    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}

    ax.set_xlabel('Constellation', fontsize=label_fontsize)
    ax.set_ylabel('Avg. reduced\nenergy consumption', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([text_labels[str(constellation_mapping[name]['num_orbits'] * constellation_mapping[name]['sats_per_orbit'])] for name in selected_constellations])
    ax.tick_params(axis='both', labelsize=ticklabel_fontsize)
    ax.legend(fontsize=legend_fontsize, loc='upper center', bbox_to_anchor=(0.5, 1.025), ncol=2, frameon=True, handletextpad=0.5, columnspacing=1.0)
    y_max = max_avg_reduced_total_latency_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')

    # Save the plot
    plt.savefig(os.path.join(output_dir, f'average_reduced_total_latency_over_network_sizes_max_budget_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_fluctuate_{fluctuation}.pdf'), format='pdf', bbox_inches='tight')
    plt.close()


def export_sorted_traffic_to_csv(sorted_traffic, file_name):
    with open(file_name, 'w', newline='') as file:
        writer = csv.writer(file)
        for value in sorted_traffic:
            writer.writerow([value])


def export_sorted_bandwidth_to_csv(sorted_bandwidth, file_name):
    with open(file_name, 'w', newline='') as file:
        writer = csv.writer(file)
        for value in sorted_bandwidth:
            writer.writerow([value])


def plot_2d_failed_task_graph(constellation_name, max_budget=MAX_BUDGETS[0], base_dir='output', output_dir='output', failure_rate=AVG_FAILURE_RATES[0], fixed_variable='bad_dish_prob', fixed_value=0.1):
    avg_failed_tasks = {}

    for algo in ALGO_TO_PLOT:
        if algo == Algorithms.DEFAULT:
            continue

        avg_failed_tasks[algo.name] = []

        # Iterate over the variable that is not fixed
        variable_range = BAD_DISH_PROBS if fixed_variable == 'failure_rate_fluctuation' else FAILURE_RATE_FLUCTUATION
        for variable in variable_range:
            csv_file_path = None
            if fixed_variable == 'failure_rate_fluctuation':
                csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{variable}', f'failure_rate_fluctuation_{fixed_value}', algo.name, f"{algo.name}_per_offloaded_task_is_failed.csv")
            else:    
                csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{fixed_value}', f'failure_rate_fluctuation_{variable}', algo.name, f"{algo.name}_per_offloaded_task_is_failed.csv")

            if not os.path.isfile(csv_file_path):
                raise FileNotFoundError(csv_file_path)

            with open(csv_file_path, 'r') as file:
                total_tasks = 0
                failed_tasks = 0
                for line in file:
                    values = line.strip().split(',')
                    total_tasks += len(values)
                    failed_tasks += values.count('True')

                if total_tasks > 0:
                    percentage_failed = (failed_tasks / total_tasks) * 100
                    avg_failed_tasks[algo.name].append((variable, percentage_failed))

    # Plotting the 2D graph
    plt.figure(figsize=(8, 5))
    for idx, (algo, data) in enumerate(avg_failed_tasks.items()):
        x, y = zip(*data)
        if fixed_variable == 'bad_dish_prob':
            x = tuple([convert_failure_rate_fluctuation_to_bad_dish_failure_rate(val, failure_rate) for val in x])
        
        # Sort x and y so the line chart is in the correct order
        if fixed_variable == 'failure_rate_fluctuation':
            x = [int(_x*100) for _x in x]
        x = np.array(x)
        y = np.array(y)
        indices = np.argsort(x)
        x = x[indices]
        y = y[indices]
        plt.plot(x, y, label=ALGO_INFO[algo][0], linestyle=LINE_STYLES[idx % len(LINE_STYLES)], color=ALGO_INFO[algo][1], linewidth=LINE_WIDTH)

    if fixed_variable == 'failure_rate_fluctuation':
        x_label = 'Unreliable dish population (%)'
    else:
        x_label = 'Failure rate of unreliable dishes'
    
    label_fontsize = 32
    legend_fontsize = 22
    tick_fontsize = 22
    
    plt.xlabel(x_label, fontsize=label_fontsize)
    plt.ylabel('Failed tasks (%)', fontsize=label_fontsize)
    plt.tick_params(axis='both', which='major', labelsize=tick_fontsize)
    # plt.title(f'Percentage of Failed Tasks vs {fixed_variable.title()} (Fixed {fixed_variable.title()}={fixed_value})')
    plt.legend(loc='upper left', fontsize=legend_fontsize)
    plt.grid(True)
    # plt.tight_layout()

    constellation_name_safe = constellation_name.replace('.', '_')
    plt.savefig(os.path.join(output_dir, f'2d_failed_task_max_budget_{constellation_name_safe}_{max_budget}_fixed_variable_{fixed_variable}_fixed_value_{fixed_value}_failure_rate_{failure_rate}.pdf'), format='pdf', bbox_inches='tight')
    plt.close()


def convert_failure_rate_fluctuation_to_bad_dish_failure_rate(fluctuation, base_failure_rate):
    return base_failure_rate * fluctuation


def plot_ecdf_life_consumption(constellation_name, max_budget=MAX_BUDGETS[0], base_dir='output', output_dir='output', failure_rate='0.0001', bad_dish_prob='0.1', failure_rate_fluctuation='1000'):
    plt.figure(figsize=(8, 6))

    idx = 0
    for algo_key, (algo_name, color) in ALGO_INFO.items():
        file_path = os.path.join(
            base_dir,
            constellation_name,
            f'max_budget_{max_budget}',
            f'failure_rate_{failure_rate}',
            f'bad_dish_prob_{bad_dish_prob}',
            f'failure_rate_fluctuation_{failure_rate_fluctuation}',
            algo_key,
            f"{algo_key}_total_life_consumption.csv"
        )

        if os.path.isfile(file_path):
            # Load the data from the file
            life_consumption_data = np.loadtxt(file_path, delimiter=',')
            
            # Calculate the ECDF for the loaded data
            ecdf = ECDF(life_consumption_data)
            
            # Plot the ECDF using the algorithm's color and name for the legend
            plt.step(ecdf.x, ecdf.y, label=algo_name, linestyle=LINE_STYLES[idx % len(LINE_STYLES)], color=color, linewidth=LINE_WIDTH)
        idx += 1
    
    # Configure and show the plot
    plt.xlabel('Total life consumption')
    plt.ylabel('CDF')
    # plt.title('ECDF of Total Life Consumption per Interval')
    plt.legend(loc='lower right')
    plt.tick_params(axis='both', which='major', labelsize=28)
    plt.grid(True)
    plt.tight_layout()

    # Save the ECDF plot as a PDF file
    constellation_name_safe = constellation_name.replace('.', '_')
    pdf_filename = f'ecdf_life_cons_interval_max_budget_{constellation_name_safe}_{max_budget}_failure_rate{failure_rate}_bad_dish_prob_{bad_dish_prob}_failure_rate_fluctuation_{failure_rate_fluctuation}.pdf'
    plt.savefig(os.path.join(output_dir, pdf_filename), format='pdf')
    plt.close()


def plot_ecdf_total_delay_ms(constellation_name, max_budget=MAX_BUDGETS[0], base_dir='output', output_dir='output', failure_rate='0.0001', bad_dish_prob='0.1', failure_rate_fluctuation='1000'):
    plt.figure(figsize=(8, 6))

    idx = 0
    for algo_key, (algo_name, color) in ALGO_INFO.items():
        file_path = os.path.join(
            base_dir,
            constellation_name,
            f'max_budget_{max_budget}',
            f'failure_rate_{failure_rate}',
            f'bad_dish_prob_{bad_dish_prob}',
            f'failure_rate_fluctuation_{failure_rate_fluctuation}',
            algo_key,
            f"{algo_key}_total_delay_ms.csv"
        )

        if os.path.isfile(file_path):
            # Load the data from the file
            delay_ms_data = np.loadtxt(file_path, delimiter=',')
            
            # Calculate the ECDF for the loaded data
            ecdf = ECDF(delay_ms_data)
            
            # Plot the ECDF using the algorithm's color and name for the legend
            plt.step(ecdf.x, ecdf.y, label=algo_name, linestyle=LINE_STYLES[idx % len(LINE_STYLES)], color=color, linewidth=LINE_WIDTH)
        idx += 1
    
    # Configure and show the plot
    plt.xlabel('Total delay (ms)')
    plt.ylabel('CDF')
    # plt.title('ECDF of Total Delay (ms) per Interval')
    plt.legend(loc='lower right')
    plt.tick_params(axis='both', which='major', labelsize=28)
    plt.grid(True)
    plt.tight_layout()

    # Save the ECDF plot as a PDF file
    constellation_name_safe = constellation_name.replace('.', '_')
    pdf_filename = f'ecdf_total_delayms_inter_max_budget_{constellation_name_safe}_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_failure_rate_fluctuation_{failure_rate_fluctuation}.pdf'
    plt.savefig(os.path.join(output_dir, pdf_filename), format='pdf')
    plt.close()


def plot_ecdf_total_energy_consumption(constellation_name, max_budget=MAX_BUDGETS[0], base_dir='output', output_dir='output', failure_rate='0.0001', bad_dish_prob='0.1', failure_rate_fluctuation='1000'):
    plt.figure(figsize=(8, 6))

    idx = 0
    for algo_key, (algo_name, color) in ALGO_INFO.items():
        file_path = os.path.join(
            base_dir,
            constellation_name,
            f'max_budget_{max_budget}',
            f'failure_rate_{failure_rate}',
            f'bad_dish_prob_{bad_dish_prob}',
            f'failure_rate_fluctuation_{failure_rate_fluctuation}',
            algo_key,
            f"{algo_key}_total_energy_consumption.csv"
        )

        if os.path.isfile(file_path):
            # Load the data from the file
            energy_consumption_data = np.loadtxt(file_path, delimiter=',')
            
            # Calculate the ECDF for the loaded data
            ecdf = ECDF(energy_consumption_data)
            
            # Plot the ECDF using the algorithm's color and name for the legend
            plt.step(ecdf.x, ecdf.y, label=algo_name, linestyle=LINE_STYLES[idx % len(LINE_STYLES)], color=color, linewidth=LINE_WIDTH)
        idx += 1
    
    # Configure and show the plot
    plt.xlabel('Total energy consumption (Watt)')
    plt.ylabel('CDF')
    plt.legend(loc='lower right')
    plt.tick_params(axis='both', which='major', labelsize=28)
    plt.grid(True)
    plt.tight_layout()

    # Save the ECDF plot as a PDF file
    constellation_name_safe = constellation_name.replace('.', '_')
    pdf_filename = f'ecdf_energy_consumption_max_budget_{constellation_name_safe}_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_failure_rate_fluctuation_{failure_rate_fluctuation}.pdf'
    plt.savefig(os.path.join(output_dir, pdf_filename), format='pdf')
    plt.close()


def plot_avg_energy_consumption_among_budget_per_algorithm(constellation_name, base_dir='output', output_dir='output', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    base_dir = os.path.join(base_dir, constellation_name)
    # Discover available max budget values
    max_budget_values = []
    energy_consumption_data = {}

    # Initialize a dictionary to hold the average energy consumption for each algorithm
    for algo_key in ALGO_INFO:
        energy_consumption_data[algo_key] = {}

    # Traverse the directory to find all max budget values
    for item in os.listdir(base_dir):
        if item.startswith('max_budget_'):
            budget_value = float(item.split('_')[-1])
            max_budget_values.append(budget_value)

            for algo_key in ALGO_INFO:
                energy_consumption_data[algo_key][budget_value] = []

    max_budget_values.sort()

    for budget_value in max_budget_values:
        for algo_key, _ in ALGO_INFO.items():
            csv_file_path = os.path.join(
                base_dir,
                f'max_budget_{budget_value}',
                f'failure_rate_{failure_rate}',
                f'bad_dish_prob_{bad_dish_prob}',
                f'failure_rate_fluctuation_{fluctuation}',
                algo_key,
                f"{algo_key}_total_energy_consumption.csv"
            )

            if os.path.isfile(csv_file_path):
                # Read energy consumption data
                consumption_data = np.loadtxt(csv_file_path, delimiter=',')
                # Calculate and store the average energy consumption for this budget value
                energy_consumption_data[algo_key][budget_value] = np.mean(consumption_data)

    # Plotting the average energy consumption for different budget values for each algorithm
    plt.figure(figsize=(8, 6))

    idx = 0
    for algo_key, algo_data in energy_consumption_data.items():
        algo_name, color = ALGO_INFO[algo_key]
        sorted_avg_consumption = [algo_data[budget] for budget in max_budget_values]
        marker = SCATTER_PATTERNS[idx % len(SCATTER_PATTERNS)]
        max_buget_precentages = []
        for b in max_budget_values:
            max_buget_precentages.append(convert_max_budget_to_percentage(MAX_BUDGETS[0], b))
        plt.plot(max_buget_precentages, sorted_avg_consumption, label=algo_name, color=color, marker=marker, linewidth=LINE_WIDTH, markersize=MARKER_SIZE)
        idx += 1
    
    plt.xlabel('Original budget percentage (%)')
    plt.ylabel('Avg. energy\nconsumption (watt min.)')
    # plt.title('Average Energy Consumption vs Max Budget Value for Each Algorithm')
    plt.legend()
    plt.grid(True)
    plt.tick_params(axis='both', which='major', labelsize=28)
    plt.tight_layout()

    # Save the plot as a PDF
    plt.savefig(os.path.join(output_dir, f'{constellation_name}_avg_energy_consumption_per_algo_{failure_rate}_{bad_dish_prob}_{fluctuation}.pdf'), format='pdf')
    plt.close()



def plot_uc_ratio_among_budget_per_algorithm(constellation_name, base_dir='output', output_dir='output', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    base_dir = os.path.join(base_dir, constellation_name)
    # Discover available max budget values
    max_budget_values = []
    uc_ratio_data = {}

    for algo_key in ALGO_INFO:
        uc_ratio_data[algo_key] = {}

    # Traverse the directory to find all max budget values
    for item in os.listdir(base_dir):
        if item.startswith('max_budget_'):
            budget_value = float(item.split('_')[-1])
            max_budget_values.append(budget_value)

            for algo_key in ALGO_INFO:
                uc_ratio_data[algo_key][budget_value] = []

    max_budget_values.sort()

    for budget_value in max_budget_values:
        for algo_key, _ in ALGO_INFO.items():
            csv_file_path = os.path.join(
                base_dir,
                f'max_budget_{budget_value}',
                f'failure_rate_{failure_rate}',
                f'bad_dish_prob_{bad_dish_prob}',
                f'failure_rate_fluctuation_{fluctuation}',
                algo_key,
                f"{algo_key}_per_offloaded_task_uc_ratio.csv"
            )

            if os.path.isfile(csv_file_path):
                with open(csv_file_path, 'r') as file:
                    avg_uc_ratio_per_interval = []
                    for line in file:
                        _columns = line.strip().split(',')
                        columns = []
                        for val in _columns:
                            columns.append(float(val))
                        avg_uc_ratio_per_interval.append(np.mean(columns))
                        
                    total_avg_uc_data = np.mean(avg_uc_ratio_per_interval)
                        
                uc_ratio_data[algo_key][budget_value] = np.mean(total_avg_uc_data)

    plt.figure(figsize=(8, 6))

    idx = 0
    for algo_key, algo_data in uc_ratio_data.items():
        algo_name, color = ALGO_INFO[algo_key]
        sorted_avg_uc_ratio = [algo_data[budget] for budget in max_budget_values]
        marker = SCATTER_PATTERNS[idx % len(SCATTER_PATTERNS)]
        max_buget_precentages = []
        for b in max_budget_values:
            max_buget_precentages.append(convert_max_budget_to_percentage(MAX_BUDGETS[0], b))
        plt.plot(max_buget_precentages, sorted_avg_uc_ratio, label=algo_name, color=color, marker=marker, linewidth=LINE_WIDTH, markersize=MARKER_SIZE)
        idx += 1
    
    plt.xlabel('Original budget percentage (%)')
    plt.ylabel('Avg. UC ratio')
    plt.legend()
    plt.grid(True)
    plt.tick_params(axis='both', which='major', labelsize=28)
    plt.tight_layout()

    plt.savefig(os.path.join(output_dir, f'{constellation_name}_avg_uc_ratio_per_algo_{failure_rate}_{bad_dish_prob}_{fluctuation}.pdf'), format='pdf')
    plt.close()


def convert_max_budget_to_percentage(base_budget, value):
    return round(value / base_budget * 100, 2)


def plot_runtime_on_different_constellation_sizes(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y1 = []
    y2 = []
    
    folders = os.listdir(base_dir)
    for folder in folders:
        if folder in constellation_mapping:
            x.append(constellation_mapping[folder]['num_orbits'] * constellation_mapping[folder]['sats_per_orbit'])
            csv_path = os.path.join(base_dir, folder, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}', f'REVERSE_AUCTION')
            group_construction_avg_runtime_second, selection_payment_runtime_second_tasks = get_avg_runtime_from_csv(csv_path)
            y1.append(group_construction_avg_runtime_second)
            y2.append(selection_payment_runtime_second_tasks)

    combined_data = list(zip(x, y1, y2))
    sorted_data = sorted(combined_data)

    x_sorted, y1_sorted, y2_sorted = zip(*sorted_data)

    plt.figure(figsize=(10, 5))
    plt.plot(x_sorted, y1_sorted, marker='o', linestyle='-', color='b')
    plt.xlabel('Network sizes (number of satellites)')
    plt.ylabel('CGSC Average Runtime (s)')
    plt.tight_layout()
    plt.savefig('output/cgsc_runtime_vs_network_sizes.pdf')
    
    plt.figure(figsize=(10, 5))
    plt.plot(x_sorted, y2_sorted, marker='o', linestyle='-', color='r')
    plt.xlabel('Network sizes (number of satellites)')
    plt.ylabel('CSTP Average Runtime (s)')
    plt.tight_layout()
    plt.savefig('output/cstp_runtime_vs_network_sizes.pdf')


def plot_total_runtime_on_different_constellation_sizes(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y_cgsc = []
    y_cstp = []
    
    folders = os.listdir(base_dir)
    for folder in folders:
        if folder in constellation_mapping:
            x.append(constellation_mapping[folder]['num_orbits'] * constellation_mapping[folder]['sats_per_orbit'])
            csv_path = os.path.join(base_dir, folder, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}', f'REVERSE_AUCTION')
            group_construction_avg_runtime_second, selection_payment_avg_runtime_second = get_avg_runtime_from_csv(csv_path)
            y_cgsc.append(group_construction_avg_runtime_second)
            y_cstp.append(selection_payment_avg_runtime_second)

    combined_data = list(zip(x, y_cgsc, y_cstp))
    sorted_data = sorted(combined_data)

    x_sorted, y_cgsc_sorted, y_cstp_sorted = zip(*sorted_data)

    plt.figure(figsize=(4, 3))
    plt.xlabel('Network sizes (number of satellites)', fontsize=12)
    plt.ylabel('CGSC + CSTP Average Runtime (s)', fontsize=12)
    plt.tick_params(axis='both', which='major', labelsize=10)
    
    plt.plot(x_sorted, y_cgsc_sorted, linestyle='-', color='#ff5733', label='Algorithm 1: CGSC')
    plt.plot(x_sorted, y_cstp_sorted, linestyle='--', color='#1477c1', label='Algorithm 2: CSTP')
    plt.xlabel('Number of satellites')
    plt.ylabel('Average runtime (s)')
    
    # plt.legend(loc='center right', fontsize=10)
    plt.legend(loc='upper right', fontsize=10)
    
    annotations = prepare_constellation_annotations()
    add_satellite_type_annotations(plt, annotations)
    
    plt.tight_layout()
    plt.savefig('output/cgsc_cstp_avg_runtime_vs_network_sizes.pdf',  bbox_inches='tight')


def prepare_constellation_annotations():
    annotations = []
    line_width = 1
    max_y_value = 0.2  # Set this to the maximum y-value of your plot
    text_y_offset = 0.02
    text_x_offset = -300

    params = constellation_mapping['CONSTELLATION_NAME.IRIDIUM_6_11_780']
    network_size = params['num_orbits'] * params['sats_per_orbit']
    annotations.append({
        'type': 'line',
        'x0': network_size,
        'y0': 0,
        'x1': network_size,
        'y1': max_y_value,
        'line': {
            'color': 'red',
            'width': line_width,
            'dash': 'dash'
        }
    })
    annotations.append({
        'x': network_size,
        'y': max_y_value,
        'text': 'Iridium\nTelesat',
        'text_x': network_size + text_x_offset - 50,
        'text_y': max_y_value + text_y_offset
    })
    
    params = constellation_mapping['CONSTELLATION_NAME.ONEWEB_18_40_1200']
    network_size = params['num_orbits'] * params['sats_per_orbit']
    annotations.append({
        'type': 'line',
        'x0': network_size,
        'y0': 0,
        'x1': network_size,
        'y1': max_y_value,
        'line': {
            'color': 'red',
            'width': line_width,
            'dash': 'dash'
        }
    })
    # annotations.append({
    #     'x': network_size,
    #     'y': max_y_value,
    #     'text': 'OneWeb',
    #     'text_x': network_size + text_x_offset,
    #     'text_y': max_y_value + text_y_offset
    # })
    
    params = constellation_mapping['CONSTELLATION_NAME.KUIPER_28_28_590']
    network_size = params['num_orbits'] * params['sats_per_orbit']
    annotations.append({
        'type': 'line',
        'x0': network_size,
        'y0': 0,
        'x1': network_size,
        'y1': max_y_value,
        'line': {
            'color': 'red',
            'width': line_width,
            'dash': 'dash'
        }
    })
    annotations.append({
        'x': network_size,
        'y': max_y_value,
        'text': 'OneWeb\nKuiper',
        'text_x': network_size + text_x_offset,
        'text_y': max_y_value + text_y_offset
    })
    
    params = constellation_mapping['CONSTELLATION_NAME.STARLINK_550']
    network_size = params['num_orbits'] * params['sats_per_orbit']
    annotations.append({
        'type': 'line',
        'x0': network_size,
        'y0': 0,
        'x1': network_size,
        'y1': max_y_value,
        'line': {
            'color': 'red',
            'width': line_width,
            'dash': 'dash'
        }
    })
    annotations.append({
        'x': network_size,
        'y': max_y_value,
        'text': 'Starlink',
        'text_x': network_size + text_x_offset,
        'text_y': max_y_value + text_y_offset
    })
    
    return annotations


def add_satellite_type_annotations(plt, annotations):
    for a in annotations:
        if a.get('type') == 'line':
            # Add vertical dashed red line
            plt.plot([a['x0'], a['x1']], [a['y0'], a['y1']], linestyle='--', color=a['line']['color'], linewidth=a['line']['width'])
        else:
            # Add text annotation
            x_annotation = a['x']
            y_annotation = a['y']
            plt.annotate(a['text'], xy=(x_annotation, y_annotation), xytext=(a['text_x'], a['text_y']),
                         fontsize=7, color='black')


def get_avg_runtime_from_csv(csv_path):
    group_construction_runtime_csv = os.path.join(csv_path, 'REVERSE_AUCTION_collaborator_group_set_construction_runtime_second_per_task.csv')
    selection_payment_runtime_csv = os.path.join(csv_path, 'REVERSE_AUCTION_collaborator_selection_and_truthful_payment_runtime_second_per_task.csv')
    
    group_construction_runtime_second_tasks = []
    group_construction_avg_runtime_second = None
    with open(group_construction_runtime_csv, mode='r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            group_construction_runtime_second_tasks.append(float(row[0]))
    group_construction_avg_runtime_second = np.mean(group_construction_runtime_second_tasks)
    
    selection_payment_runtime_second_tasks = []
    selection_payment_avg_runtime_second = None
    with open(selection_payment_runtime_csv, mode='r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            selection_payment_runtime_second_tasks.append(float(row[0]))
    selection_payment_avg_runtime_second = np.mean(selection_payment_runtime_second_tasks)
    
    return group_construction_avg_runtime_second, selection_payment_avg_runtime_second


def plot_is_offloaded_bar_chart(constellation_name, max_budget, failure_rate, bad_dish_prob, failure_rate_fluctuation, base_dir):
    dirpath = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}')
    
    results = {}
    
    for algo in ALGO_TO_PLOT:
        algo_name = algo.name
        filepath = os.path.join(dirpath, algo_name, f'{algo_name}_is_task_offloaded.csv')
        
        if os.path.exists(filepath):
            true_counts = 0
            with open(filepath, 'r') as file:
                for line in file:
                    tokens = line.strip().split(',')
                    true_counts += tokens.count('True')
            results[algo_name] = true_counts
        else:
            results[algo_name] = 0  # If file does not exist, set count to 0

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.bar([ALGO_INFO[algo_key][0] for algo_key in results.keys()], results.values(), color='skyblue')
    plt.ylabel('Sum of True Values')

    # Save the figure as a PDF
    pdf_filepath = os.path.join('output', f'task_offloading_comparison_{constellation_name}.pdf')
    plt.savefig(pdf_filepath, format='pdf')
    plt.close()


if __name__ == '__main__':
    max_budget = MAX_BUDGETS[0]
    failure_rate = AVG_FAILURE_RATES[0]
    bad_dish_prob = BAD_DISH_PROBS[0]
    failure_rate_fluctuation = FAILURE_RATE_FLUCTUATION[0]
    
    FIXED_BUDGET_BASE_DIR = 'output/FIXED_BUDGET'
    VARIABLE_BUDGET_BASE_DIR = 'output/VARIABLE_BUDGET/'
    NETWORK_SIZES_BASE_DIR = 'output/NETWORK_SIZES'
    
    

    
    
    constellation_names = ['CONSTELLATION_NAME.STARLINK_550', 'CONSTELLATION_NAME.ONEWEB_18_40_1200']
    for cname in constellation_names:
        plot_2d_failed_task_graph(constellation_name=cname, max_budget=max_budget, failure_rate=failure_rate, fixed_variable='bad_dish_prob', fixed_value=0.2, base_dir=FIXED_BUDGET_BASE_DIR)
        plot_2d_failed_task_graph(constellation_name=cname, max_budget=max_budget, failure_rate=failure_rate, fixed_variable='failure_rate_fluctuation', fixed_value=2000, base_dir=FIXED_BUDGET_BASE_DIR)
        plot_ecdf_life_consumption(constellation_name=cname, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=FIXED_BUDGET_BASE_DIR)
        plot_ecdf_total_delay_ms(constellation_name=cname, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=FIXED_BUDGET_BASE_DIR)
        plot_ecdf_total_energy_consumption(constellation_name=cname, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=FIXED_BUDGET_BASE_DIR)
        plot_uc_ratio_ecdf(constellation_name=cname, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=FIXED_BUDGET_BASE_DIR)
        plot_avg_uc_ratio_bar_chart(constellation_name=cname, max_budget=max_budget, failure_rate=failure_rate, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=FIXED_BUDGET_BASE_DIR)
    
        plot_avg_energy_consumption_among_budget_per_algorithm(constellation_name=cname, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation, base_dir=VARIABLE_BUDGET_BASE_DIR)
        
        plot_uc_ratio_among_budget_per_algorithm(constellation_name=cname, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation, base_dir=VARIABLE_BUDGET_BASE_DIR)
    
    plot_runtime_on_different_constellation_sizes(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
    plot_total_runtime_on_different_constellation_sizes(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
    plot_avg_uc_ratio_bar_chart_over_network_sizes(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
    plot_reduced_life_consumption_over_network_sizes(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
    plot_reduced_energy_consumption_over_network_sizes(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
    plot_reduced_total_latency_over_network_sizes(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)

    plot_is_offloaded_bar_chart(constellation_name='CONSTELLATION_NAME.STARLINK_550', max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=FIXED_BUDGET_BASE_DIR)
    