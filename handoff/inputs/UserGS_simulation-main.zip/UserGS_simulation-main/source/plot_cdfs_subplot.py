from matplotlib import rcParams
import matplotlib.pyplot as plt
import os
from models.global_var import AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION, MAX_BUDGETS
from models.enum import Algorithms
from plot import ALGO_TO_PLOT, ALGO_INFO, LINE_STYLES, MARKER_SIZE
from statsmodels.distributions.empirical_distribution import ECDF
import numpy as np
import csv


rcParams['font.family'] = 'serif'
rcParams['font.serif'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['font.size'] = 32


LINE_WIDTH = 3


label_fontsize = 20
tick_fontsize = 16
legend_fontsize = 20
subtitle_fontsize = 22


def plot_cdfs(ax, constellation_name, max_budget=MAX_BUDGETS[0], base_dir='output', failure_rate=AVG_FAILURE_RATES[0], bad_dish_prob=BAD_DISH_PROBS[0], failure_rate_fluctuation=FAILURE_RATE_FLUCTUATION[0], metric='uc_ratio', xlabel=''):
    idx = 0
    for algo in ALGO_TO_PLOT:
        algo_key = algo.name
        (algo_name, color) = ALGO_INFO[algo_key]
        file_path = os.path.join(
            base_dir,
            constellation_name,
            f'max_budget_{max_budget}',
            f'failure_rate_{failure_rate}',
            f'bad_dish_prob_{bad_dish_prob}',
            f'failure_rate_fluctuation_{failure_rate_fluctuation}',
            algo_key,
            f"{algo_key}_{metric}.csv"
        )

        if os.path.isfile(file_path):
            # Load the data from the file
            all_values = []
            with open(file_path, 'r') as file:
                reader = csv.reader(file)
                for row in reader:
                    _row = [float(val) for val in row if val]
                    all_values.append(np.sum(_row)) 
            data = np.array(all_values)
            
            # Calculate the ECDF for the loaded data
            ecdf = ECDF(data)
            
            # Plot the ECDF using the algorithm's color and name for the legend
            ax.step(ecdf.x, ecdf.y, label=algo_name, linestyle=LINE_STYLES[idx % len(LINE_STYLES)], color=color, linewidth=LINE_WIDTH)
        idx += 1

        ax.set_xlabel(xlabel, fontsize=label_fontsize)
        ax.set_ylabel('CDF', fontsize=label_fontsize)
        ax.grid(True)
        ax.tick_params(axis='both', which='major', labelsize=tick_fontsize)


def plot_uc_ratio_among_budget_per_algorithm(ax, constellation_name, base_dir='output', failure_rate='0.0001', bad_dish_prob='0.1', failure_rate_fluctuation='1000'):
    base_dir = os.path.join(base_dir, constellation_name)
    # Discover available max budget values
    max_budget_values = []
    uc_ratio_data = {}

    for algo in ALGO_TO_PLOT:
        algo_key = algo.name
        uc_ratio_data[algo_key] = {}

    # Traverse the directory to find all max budget values
    for item in os.listdir(base_dir):
        if item.startswith('max_budget_'):
            budget_value = float(item.split('_')[-1])
            max_budget_values.append(budget_value)

            for algo in ALGO_TO_PLOT:
                algo_key = algo.name
                uc_ratio_data[algo_key][budget_value] = []

    max_budget_values.sort()

    for budget_value in max_budget_values:
        for algo_key, _ in ALGO_INFO.items():
            csv_file_path = os.path.join(
                base_dir,
                f'max_budget_{budget_value}',
                f'failure_rate_{failure_rate}',
                f'bad_dish_prob_{bad_dish_prob}',
                f'failure_rate_fluctuation_{failure_rate_fluctuation}',
                algo_key,
                f"{algo_key}_per_offloaded_task_uc_ratio.csv"
            )

            if os.path.isfile(csv_file_path):
                with open(csv_file_path, 'r') as file:
                    avg_uc_ratio_per_interval = []
                    for line in file:
                        _columns = line.strip().split(',')
                        columns = [float(val) for val in _columns]
                        avg_uc_ratio_per_interval.append(np.mean(columns))
                        
                    total_avg_uc_data = np.mean(avg_uc_ratio_per_interval)
                        
                uc_ratio_data[algo_key][budget_value] = total_avg_uc_data

    idx = 0
    for algo_key, algo_data in uc_ratio_data.items():
        algo_name, color = ALGO_INFO[algo_key]
        sorted_avg_uc_ratio = [algo_data[budget] for budget in max_budget_values]
        max_buget_precentages = [convert_max_budget_to_percentage(MAX_BUDGETS[0], b) for b in max_budget_values]
        ax.plot(max_buget_precentages, sorted_avg_uc_ratio, label=algo_name, color=color, linestyle=LINE_STYLES[idx % len(LINE_STYLES)], linewidth=LINE_WIDTH, markersize=MARKER_SIZE)
        idx += 1
    
    ax.set_xlabel('Original budget percentage (%)', fontsize=label_fontsize)
    ax.set_ylabel('Avg.\nutility-to-cost ratio', fontsize=label_fontsize)
    ax.grid(True)
    ax.tick_params(axis='both', which='major', labelsize=tick_fontsize)


def convert_max_budget_to_percentage(base_budget, value):
    return round(value / base_budget * 100, 2)


def main():
    max_budget = MAX_BUDGETS[0]
    failure_rate = AVG_FAILURE_RATES[0]
    bad_dish_prob = BAD_DISH_PROBS[0]
    failure_rate_fluctuation = FAILURE_RATE_FLUCTUATION[0]
    
    subtitle_fontsize = 23
    
    FIXED_BUDGET_BASE_DIR = 'output/FIXED_BUDGET'
    VARIABLE_BUDGET_BASE_DIR = 'output/VARIABLE_BUDGET/'
    
    constellation_names = ['CONSTELLATION_NAME.STARLINK_550']
    
    fig, axs = plt.subplots(1, 4, figsize=(22, 3))
    fig.subplots_adjust(wspace=0.28, hspace=0.6)

    metrics = ['per_offloaded_task_conserved_life_consumption', 'per_offloaded_task_conserved_energy_consumption', 'per_offloaded_task_reduced_end_to_end_delay']
    xlabels = ['Reduced life consumption', 'Reduced energy consumption', 'Reduced total latency (ms)', 'Avg. utility-to-cost ratio']
    subtitles = ['(a) Reduced life\nconsumption per interval.', '(b) Reduced\nenergy consumption per interval.', '(c) Reduced total\nlatency (ms) per interval.', '(d) Avg. total\nutility-to-cost ratio per task.']

    for col, metric in enumerate(metrics):
        plot_cdfs(axs[col], constellation_name=constellation_names[0], max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=FIXED_BUDGET_BASE_DIR, metric=metric, xlabel=xlabels[col])
        axs[col].text(0.5, -0.3, subtitles[col], ha='center', va='top', transform=axs[col].transAxes, fontsize=subtitle_fontsize)

    plot_uc_ratio_among_budget_per_algorithm(axs[-1], constellation_name=constellation_names[0], failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, base_dir=VARIABLE_BUDGET_BASE_DIR)
    axs[-1].text(0.5, -0.3, subtitles[-1], ha='center', va='top', transform=axs[-1].transAxes, fontsize=subtitle_fontsize)

    handles, labels = axs[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', ncol=4, fontsize=legend_fontsize, bbox_to_anchor=(0.5, 1.1), frameon=False)

    plt.savefig(os.path.join('output', 'cdfs_all_metrics.pdf'), format='pdf', bbox_inches='tight')
    plt.close()


if __name__ == '__main__':
    main()
