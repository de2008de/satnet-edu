from models.auction import ReverseAuction
from models.dish import DishManager
from helpers.users_scale import TRAFFIC_GRID


def test_get_limited_power_set():
    dish_generator = DishManager(TRAFFIC_GRID)
    ra = ReverseAuction(dish_generator)

    # Test case 1
    original_set = [1, 2, 3, 4]
    max_subset_size = 3
    expected_power_set = [[], [1], [2], [1, 2]]
    generated_power_set = ra.get_limited_power_set(original_set, max_subset_size - 1)
    assert generated_power_set == expected_power_set, "Test case 1 failed"

    # Test case 2
    original_set = [5, 6, 7]
    max_subset_size = 2
    expected_power_set = [[], [5]]
    generated_power_set = ra.get_limited_power_set(original_set, max_subset_size - 1)
    assert generated_power_set == expected_power_set, "Test case 2 failed"

    # Test case 3
    original_set = [8, 9, 10, 11, 12]
    max_subset_size = 4
    expected_power_set = [[], [8], [9], [8, 9], [10], [8, 10], [9, 10], [8, 9, 10]]
    generated_power_set = ra.get_limited_power_set(original_set, max_subset_size - 1)
    assert generated_power_set == expected_power_set, "Test case 3 failed"


if __name__ == '__main__':
    test_get_limited_power_set()
    print("All test cases passed.")
