from models.constellation import Constellation
from enum import Enum


class CONSTELLATION_NAME(Enum):
    STARLINK_550 = 1
    LEO_36_11_550 = 2
    LEO_48_11_550 = 3
    LEO_72_33_550 = 5
    LEO_72_44_550 = 6
    LEO_72_66_550 = 7
    LEO_84_66_550 = 8
    IRIDIUM_6_11_780 = 9
    TELESAT_6_12_1000 = 10
    ONEWEB_18_40_1200 = 11
    KUIPER_28_28_590 = 12


# OneWeb and Telesat params reference: https://www.sciencedirect.com/science/article/pii/S0094576518320368
# Iridium Next params reference: https://www.eoportal.org/satellite-missions/iridium-next
# Kuiper params reference: https://fcc.report/IBFS/SAT-LOA-20211104-00145/13337525

CONSTELLATION_PARAMS = {
    CONSTELLATION_NAME.IRIDIUM_6_11_780: {
        'NAME': 'IRIDIUM-6-11-780',
        'LEO_NUM_ORBITS': 6,
        'LEO_SAT_PER_ORBIT': 11,
        'LEO_INCL_ANGLE_DEG': 86.4,
        'LEO_ALTITUDE_M': 780000,
    },

    CONSTELLATION_NAME.TELESAT_6_12_1000: {
        'NAME': 'TELESAT-6-12-1000',
        'LEO_NUM_ORBITS': 6,
        'LEO_SAT_PER_ORBIT': 12,
        'LEO_INCL_ANGLE_DEG': 99.5,
        'LEO_ALTITUDE_M': 1000000,
    },

    CONSTELLATION_NAME.LEO_36_11_550: {
        'NAME': 'LEO-36-11-550',
        'LEO_NUM_ORBITS': 36,
        'LEO_SAT_PER_ORBIT': 11,
        'LEO_INCL_ANGLE_DEG': 53,
        'LEO_ALTITUDE_M': 550000,
    },

    CONSTELLATION_NAME.LEO_48_11_550: {
        'NAME': 'LEO-48-11-550',
        'LEO_NUM_ORBITS': 48,
        'LEO_SAT_PER_ORBIT': 11,
        'LEO_INCL_ANGLE_DEG': 53,
        'LEO_ALTITUDE_M': 550000,
    },

    CONSTELLATION_NAME.KUIPER_28_28_590: {
        'NAME': 'KUIPER-28-28-590',
        'LEO_NUM_ORBITS': 28,
        'LEO_SAT_PER_ORBIT': 28,
        'LEO_INCL_ANGLE_DEG': 33,
        'LEO_ALTITUDE_M': 590000,
    },

    CONSTELLATION_NAME.ONEWEB_18_40_1200: {
        'NAME': 'ONEWEB-18-40-1200',
        'LEO_NUM_ORBITS': 18,
        'LEO_SAT_PER_ORBIT': 40,
        'LEO_INCL_ANGLE_DEG': 87.9,
        'LEO_ALTITUDE_M': 1200000,
    },

    CONSTELLATION_NAME.STARLINK_550: {
        'NAME': 'Starlink-550',
        'LEO_NUM_ORBITS': 72,
        'LEO_SAT_PER_ORBIT': 22,
        'LEO_INCL_ANGLE_DEG': 53,
        'LEO_ALTITUDE_M': 550000,
    },

    CONSTELLATION_NAME.LEO_72_33_550: {
        'NAME': 'LEO-72-33-550',
        'LEO_NUM_ORBITS': 72,
        'LEO_SAT_PER_ORBIT': 33,
        'LEO_INCL_ANGLE_DEG': 53,
        'LEO_ALTITUDE_M': 550000,
    },

    CONSTELLATION_NAME.LEO_72_44_550: {
        'NAME': 'LEO-72-44-550',
        'LEO_NUM_ORBITS': 72,
        'LEO_SAT_PER_ORBIT': 44,
        'LEO_INCL_ANGLE_DEG': 53,
        'LEO_ALTITUDE_M': 550000,
    },

    CONSTELLATION_NAME.LEO_72_66_550: {
        'NAME': 'LEO-72-66-550',
        'LEO_NUM_ORBITS': 72,
        'LEO_SAT_PER_ORBIT': 66,
        'LEO_INCL_ANGLE_DEG': 53,
        'LEO_ALTITUDE_M': 550000,
    },

    CONSTELLATION_NAME.LEO_84_66_550: {
        'NAME': 'LEO-84-66-550',
        'LEO_NUM_ORBITS': 84,
        'LEO_SAT_PER_ORBIT': 66,
        'LEO_INCL_ANGLE_DEG': 53,
        'LEO_ALTITUDE_M': 550000,
    },
}


def get_constellation(cons_name, tf):
    if cons_name not in CONSTELLATION_PARAMS:
        raise ValueError(f'Unknown constellation name: {cons_name}')
    return _get_constellation(CONSTELLATION_PARAMS[cons_name], tf)


def _get_constellation(params, tf):
    constellation = Constellation(
        params['LEO_NUM_ORBITS'], 
        params['LEO_SAT_PER_ORBIT'], 
        params['LEO_ALTITUDE_M'],
        params['LEO_INCL_ANGLE_DEG'], 
        params['NAME'],
        tf=tf,
    )
    return constellation
