from constellation_factory import get_constellation, CONSTELLATION_NAME
from simulation import Simulation, TimeStep
from datetime import timedelta
from helpers.users_scale import TRAFFIC_GRID
from models.traffic import TrafficGenerator
from models.energy import Energy
from models.routing import Routing
from models.data_manager import DataManager
from models.delay_manager import DelayManager
from models.dish import DishManager
from models.task import TaskGenerator
from models.enum import EVENT_ID, Algorithms
from models.algorithm import Algorithm
from models.global_var import SKIP_DEFAULT, MAX_BUDGETS, AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION
import ephem
import numpy as np
import random
import itertools
from timezonefinder import TimezoneFinder
import multiprocessing
from enum import Enum
import time
import csv
import warnings


warnings.filterwarnings("error")


DEBUG = False
seed = 1234
MAX_STEPS = 100

START_DATE_STR = '2000/1/2 12:00:00'
INTERVAL = timedelta(seconds=60)

IS_VERBOSE = True


class EXP_NAME(Enum):
    DEBUG = 0
    FIXED_BUDGET = 1
    VARIABLE_BUDGET = 2
    NETWORK_SIZES = 3


def start(constellation_name, max_budget, avg_failure_rate, bad_dish_prob, failure_rate_fluctuation, algo, tf, experiment_name):
    if SKIP_DEFAULT and algo == Algorithms.DEFAULT:
        return
    if IS_VERBOSE:
        print(f'Running for constellation {constellation_name}')
        print(f'Running for avg failure rate {avg_failure_rate}.')
        print(f'Running for algorithm {algo.name}.')
    START_EPHEM_DATE = ephem.Date(START_DATE_STR)
    TIME_STEP = TimeStep(start_time=START_EPHEM_DATE, interval=INTERVAL)
    np.random.seed(seed)
    random.seed(seed)
    data_manager = DataManager()
    sim = Simulation(max_steps=MAX_STEPS, time_step=TIME_STEP, is_verbose=IS_VERBOSE)
    constellation = get_constellation(constellation_name, tf=tf)
    traffic_generator = TrafficGenerator(constellation=constellation, tf=tf)
    energy = Energy(constellation=constellation)
    delay_manager = DelayManager(constellation=constellation, time_step=TIME_STEP, tf=tf)
    routing = Routing(constellation, data_manager, delay_manager, algo)
    dish_generator = DishManager(TRAFFIC_GRID, avg_failure_rate, bad_dish_prob, failure_rate_fluctuation)
    task_generator = TaskGenerator(constellation=constellation, delay_manager=delay_manager)
    algorithm = Algorithm(max_budget, dish_generator, delay_manager, constellation, data_manager, IS_VERBOSE)
    
    sim.register(id=EVENT_ID.UPDATE_SATELLITES, event_callback=constellation.update_satellites, interval=1, args=[TIME_STEP], message='Updated satellites')
    sim.register(id=EVENT_ID.GENERATE_TRAFFIC, event_callback=traffic_generator.generate_traffic, interval=1, args=[TIME_STEP], message='Generated traffic')
    sim.register(id=EVENT_ID.GENERATE_TASKS, event_callback=task_generator.create_tasks, interval=1, input_event_id=EVENT_ID.GENERATE_TRAFFIC, message='Created tasks')
    sim.register(id=EVENT_ID.CHARGE_SATELLITES, event_callback=energy.charge_satellites, interval=1, message='Charged satellites')
    sim.register(id=EVENT_ID.RANDOMIZE_DOD, event_callback=constellation.randomize_satellite_dod, interval=1, args=[TIME_STEP], message='Randomized DoD to simulate background traffic')
    sim.register(id=EVENT_ID.START_ALGORITHM, event_callback=algorithm.start, interval=1, args=[algo], input_event_id=EVENT_ID.GENERATE_TASKS, message='Started algorithm')
    sim.register(id=EVENT_ID.ROUTE_TRAFFIC, event_callback=routing.route_traffic, interval=1, input_event_id=EVENT_ID.START_ALGORITHM, message='Routed traffic and consumed energy')
    
    sim.start()
    
    data_manager.write_to_csv(constellation_name, max_budget, algo, avg_failure_rate, bad_dish_prob, failure_rate_fluctuation, experiment_name)


def start_process(params, semaphore):
    with semaphore:
        tf = TimezoneFinder()
        constellation_name, max_budget, avg_failure_rate, bad_dish_prob, failure_rate_fluctuation, algo, experiment_name = params
        start(constellation_name, max_budget, avg_failure_rate, bad_dish_prob, failure_rate_fluctuation, algo, tf, experiment_name)


def run_processes(param_combinations, max_processes=48):
    semaphore = multiprocessing.Semaphore(max_processes)
    processes = []

    for params in param_combinations:
        process = multiprocessing.Process(target=start_process, args=(params, semaphore))
        processes.append(process)
        process.start()

    for process in processes:
        process.join()


if __name__ == '__main__':
    
    start_time = time.time()
    if DEBUG:
        
        # Single thread for debugging
        semaphore = multiprocessing.Semaphore(1)
        start_process((CONSTELLATION_NAME.STARLINK_550, MAX_BUDGETS[0], AVG_FAILURE_RATES[0], BAD_DISH_PROBS[0], FAILURE_RATE_FLUCTUATION[0], Algorithms.REVERSE_AUCTION, EXP_NAME.DEBUG.name),  semaphore=semaphore)
    
    else:

        # First scenario: fixed max budget
        fixed_max_budget = [MAX_BUDGETS[0]]
        algorithms = [Algorithms.REVERSE_AUCTION, Algorithms.SERVICE, Algorithms.SUSTAINABILITY, Algorithms.FALCON]
        param_combinations = list(itertools.product([CONSTELLATION_NAME.STARLINK_550], fixed_max_budget, AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION, algorithms, [EXP_NAME.FIXED_BUDGET.name]))
        run_processes(param_combinations)
        
        # First scenario with another constellation
        fixed_max_budget = [MAX_BUDGETS[0]]
        algorithms = [Algorithms.REVERSE_AUCTION, Algorithms.SERVICE, Algorithms.SUSTAINABILITY, Algorithms.FALCON]
        param_combinations = list(itertools.product([CONSTELLATION_NAME.ONEWEB_18_40_1200], fixed_max_budget, AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION, algorithms, [EXP_NAME.FIXED_BUDGET.name]))
        run_processes(param_combinations)

        # Second scenario: fixed avg failure rate, bad dish probabilities, and failure rate fluctuation
        fixed_avg_failure_rate = [AVG_FAILURE_RATES[0]]
        fixed_bad_dish_probs = [BAD_DISH_PROBS[0]]
        fixed_failure_rate_fluctuation = [FAILURE_RATE_FLUCTUATION[0]]
        algorithms = [Algorithms.REVERSE_AUCTION, Algorithms.SERVICE, Algorithms.SUSTAINABILITY, Algorithms.FALCON]
        param_combinations = list(itertools.product([CONSTELLATION_NAME.STARLINK_550, CONSTELLATION_NAME.ONEWEB_18_40_1200], MAX_BUDGETS, fixed_avg_failure_rate, fixed_bad_dish_probs, fixed_failure_rate_fluctuation, algorithms, [EXP_NAME.VARIABLE_BUDGET.name]))
        run_processes(param_combinations)
        
        # Third scenario: fixed everything, use different constellations for our proposed algorithms
        param_combinations = list(itertools.product(list(CONSTELLATION_NAME), [MAX_BUDGETS[0]], [AVG_FAILURE_RATES[0]], [BAD_DISH_PROBS[0]], [FAILURE_RATE_FLUCTUATION[0]], [Algorithms.REVERSE_AUCTION, Algorithms.SERVICE, Algorithms.SUSTAINABILITY, Algorithms.FALCON], [EXP_NAME.NETWORK_SIZES.name]))
        run_processes(param_combinations)

    end_time = time.time()
    with open('../output/simulation_time_hours.csv', mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Simulation Time (hours)'])
        time_in_hours = (end_time - start_time) / 60 / 60
        writer.writerow([f'{time_in_hours:.2f}'])
