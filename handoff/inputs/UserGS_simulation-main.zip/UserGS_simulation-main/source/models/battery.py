import numpy as np


class Battery:
    def __init__(self, random_cycle_life: bool) -> None:
        self.theta_a = 0.8
        self.max_capacity_watt_min = 5000.0
        self.current_capacity_watt_min = self.max_capacity_watt_min
        self.max_cycle_life = 30000.0
        if random_cycle_life:
            self.current_cycle_life = self.max_cycle_life * np.random.uniform(0.5, 0.8)
        else:
            self.current_cycle_life = self.max_cycle_life
    
    def charge(self, watt_min) -> None:
        self.current_capacity_watt_min = min(
            self.max_capacity_watt_min, self.current_capacity_watt_min + watt_min
        )
        
    def estimate_life_consumption(self, watt_min):
        """
        Estimate life consumption without actually discharging the battery
        """
        prev_dod = self.get_dod()
        next_dod = 1.0 - (max(0, self.current_capacity_watt_min - watt_min) / self.max_capacity_watt_min)
        if prev_dod >= next_dod:
            return 0
        return self.get_life_consumption(prev_dod, next_dod)
    
    def discharge(self, watt_min) -> float:
        prev_dod = self.get_dod()
        self.current_capacity_watt_min = max(0, self.current_capacity_watt_min - watt_min)
        next_dod = self.get_dod()
        life_consumption = self.consume_life_cycle(prev_dod, next_dod)
        return life_consumption

    def consume_life_cycle(self, prev_dod, next_dod) -> float:
        life_consumption = self.get_life_consumption(prev_dod, next_dod)
        self.current_cycle_life = max(0, self.current_cycle_life - life_consumption)
        return life_consumption
    
    def get_dod(self) -> float:
        return 1.0 - self.current_capacity_watt_min / self.max_capacity_watt_min
    
    def get_life_consumption(self, prev_dod, next_dod) -> float:
        if next_dod <= prev_dod:
            return 0.0
        life_consumption = self.life_cons_integral(next_dod) - self.life_cons_integral(prev_dod)
        if life_consumption == 0:
            raise ValueError(f'Life consumption cannot be 0 if next dod ({next_dod}) > prev dod ({prev_dod})')
        return life_consumption

    def life_cons_integral(self, dod) -> float:
        return dod * 10 ** (self.theta_a * (dod - 1))     
