from models.global_var import OFFLOADING_SAT_INDEX
import math


class AuctionUtility:
    def __init__(self, delay_manager, constellation) -> None:
        self.weight1 = 0.3  # Weight for reduced energy
        self.weight2 = 0.4  # More weight to delay because we focus on QoS
        self.weight3 = 0.3  # Weight for extended service life
        self.energy_epsilon = 0.08
        self.delay_manager = delay_manager
        self.constellation = constellation
        
        # Set according to Satellite Edge Computing for Real-Time and Very-High Resolution Earth Observation
        # 2.16 Gbps downlink and 10 W downlink transmission power
        self.offloading_energy_epsilon_prime = 0.005
        self.offloading_satellite_index = OFFLOADING_SAT_INDEX  # Which satellite is the offloading satellite on the original path

    def utility_of(self, task, group):
        energy_utility = self.energy_utility_of(task, group)
        delay_utility = self.delay_utility_of(task, group)
        extended_life_utility = self.extended_life_utility_of(task, group)
        utility = self.weight1 * energy_utility + self.weight2 * delay_utility + self.weight3 * extended_life_utility
        success_rate = 1
        for bid in group:
            success_rate *= (1 - bid.bidder.empirical_failure_rate)
        return utility * success_rate
    
    def energy_utility_of(self, task, group):
        energy_consumption_without_offloading = \
            len(task.path_without_offloading) * self.energy_epsilon * task.traffic_amount_mb_requirement

        energy_consumption_with_offloading = 0
        for bid in group:
            energy_consumption_with_offloading += (len(task.path_without_offloading[:self.offloading_satellite_index + 1 + bid.offloading_sat_offset]) * self.energy_epsilon \
                + self.offloading_energy_epsilon_prime ) * (task.traffic_amount_mb_requirement / len(group))

        return (energy_consumption_without_offloading - energy_consumption_with_offloading) / energy_consumption_without_offloading
    
    def delay_utility_of(self, task, group):
        delay_ms_without_offloading = \
            self.delay_manager.delay_ms(task.path_without_offloading, task.traffic_amount_mb_requirement, None, is_offloaded=False)
        delay_ms_with_offloading = \
            self.delay_manager.delay_ms(
                task.path_without_offloading, 
                task.traffic_amount_mb_requirement, group, offloading_sat_index=self.offloading_satellite_index, is_offloaded=True)
        return (delay_ms_without_offloading - delay_ms_with_offloading) / delay_ms_without_offloading
    
    def extended_life_utility_of(self, task, group):
        service_life_cost_without_offloading = \
            self.get_service_life_cost_on_path(task.path_without_offloading, task.traffic_amount_mb_requirement)
        
        service_life_cost_with_offloading = 0
        for bid in group:
            service_life_cost_with_offloading += self.get_service_life_cost_on_path(
                    task.path_without_offloading[:self.offloading_satellite_index + 1 + bid.offloading_sat_offset], 
                    task.traffic_amount_mb_requirement / len(group)
                )

        return (service_life_cost_without_offloading - service_life_cost_with_offloading) / service_life_cost_without_offloading
    
    def get_service_life_cost_on_path(self, path, traffic_amount_mb):
        total_service_life_cost = 0
        for sat_id in path:
            sat = self.constellation.satellites[sat_id]
            energy_consumption_watt_min = sat.estimate_energy_consumption_watt_min(traffic_amount_mb)
            life_consumption = sat.battery.estimate_life_consumption(energy_consumption_watt_min)
            total_service_life_cost += life_consumption * \
                math.e ** ( 
                    (sat.battery.max_cycle_life - sat.battery.current_cycle_life) / \
                    sat.battery.current_cycle_life
                )
        return total_service_life_cost
