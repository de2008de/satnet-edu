# https://aws.amazon.com/ground-station/locations/
AWS_GS = {
    (21, 8): ['Dubbo'],
    (9, 7): ['Punta Arenas'],
    (4, 1): ['Hawaii'],
    (1, 1): ['Alaska'],
    (3, 3): ['Oregon'],
    (3, 6): ['Ohio'],
    (2, 11): ['Ireland'],
    (1, 12): ['Europe (Stockholm)'],
    (8, 13): ['Cape Town'],
    (4, 15): ['Bahrain'],
    (5, 18): ['Singapore'],
    (3, 20): ['Seoul'],
}


def get_num_aws_gs(row, col):
    if (row, col) not in AWS_GS:
        return 0
    return len(AWS_GS[(row, col)])
