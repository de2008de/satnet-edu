from models.auction import Bid
import networkx as nx
from models.global_var import AVG_PKT_SIZE_MBIT


class Task:
    def __init__(self, id, traffic_pair, traffic_amount_mb, delay_ms_requirement, bandwidth_mbps_requirement, path_without_offloading) -> None:
        self.id = id
        self.traffic_pair = traffic_pair
        self.traffic_amount_mb_requirement = traffic_amount_mb
        self.delay_ms_requirement = delay_ms_requirement
        self.bandwidth_mbps_requirement = bandwidth_mbps_requirement
        self.winner: Bid = None
        self.path_without_offloading = path_without_offloading  # For later use in non-auction routing
        self.path_with_offloading = None
        self.auction_utility = None
        self.cost = None
        self.payment = None


class TaskGenerator:
    def __init__(self, constellation, delay_manager) -> None:
        self.constellation = constellation
        self.delay_manager = delay_manager
        self.id_counter = 0
    
    def create_tasks(self, traffic_pairs):
        tasks = []
        for tp in traffic_pairs:
            source_sat, dest_sat, traffic_mb = tp
            if traffic_mb == 0:
                continue
            path = self.get_path_without_offloading(source_sat, dest_sat)
            delay_ms_req = self.get_delay_requirement(path, traffic_mb)
            bandwidth_mbps_req = self.get_bandwidth_requirement()
            task = Task(
                        id=self.get_and_increment_id(),
                        traffic_pair=tp,
                        traffic_amount_mb=traffic_mb, 
                        delay_ms_requirement=delay_ms_req,
                        bandwidth_mbps_requirement=bandwidth_mbps_req,
                        path_without_offloading=path,
                    )
            tasks.append(task)
        return tasks

    def get_path_without_offloading(self, source_sat, dest_sat):
        path = nx.shortest_path(
                self.constellation.topology.hop_count_graph, 
                source=source_sat.id, target=dest_sat.id, weight='weight')
        return path
    
    def get_delay_requirement(self, path, traffic_mb):
        delay_without_offloading_ms = self.delay_manager.delay_ms(path, traffic_mb, None, is_offloaded=False)
        margin_delay_percent = 0.1  # TODO: discuss how to set this margin
        return delay_without_offloading_ms * (1 + margin_delay_percent)

    def get_bandwidth_requirement(self):
        tolerated_transmission_delay_ms = 1
        tolerated_transmission_delay_s = tolerated_transmission_delay_ms / 1000.0
        bandwidth_req_mbps = AVG_PKT_SIZE_MBIT / tolerated_transmission_delay_s
        return bandwidth_req_mbps
    
    def get_and_increment_id(self):
        id = self.id_counter
        self.id_counter += 1
        return id
