import csv
import os


class DataManager:
    def __init__(self) -> None:
        self.data = {}
    
    def write_to_csv(self, constellation_name, max_budget, algo, failure_rate, bad_dish_prob, failure_rate_fluctuation, experiment_name):
        base_dir = '../output'
        exepriment_name_dir = os.path.join(base_dir, f'{experiment_name}')
        os.makedirs(exepriment_name_dir, exist_ok=True)
        constellation_dir = os.path.join(exepriment_name_dir, f'{constellation_name}')
        os.makedirs(constellation_dir, exist_ok=True)
        max_budget_dir = os.path.join(constellation_dir, f'max_budget_{str(max_budget)}')
        os.makedirs(max_budget_dir, exist_ok=True)
        fail_rate_dir = os.path.join(max_budget_dir, f'failure_rate_{str(failure_rate)}')
        bad_dish_prob_dir = os.path.join(fail_rate_dir, f'bad_dish_prob_{str(bad_dish_prob)}')
        os.makedirs(bad_dish_prob_dir, exist_ok=True)
        failure_rate_fluctuation_dir = os.path.join(bad_dish_prob_dir, f'failure_rate_fluctuation_{str(failure_rate_fluctuation)}')
        algo_dir = os.path.join(failure_rate_fluctuation_dir, algo.name)
        os.makedirs(algo_dir, exist_ok=True)
        for key, value in self.data.items():
            filename = f"{algo.name}_{key}.csv"
            filepath = os.path.join(algo_dir, filename)
            with open(filepath, 'w', newline='') as file:
                writer = csv.writer(file)
                for item in value:
                    if isinstance(item, list):
                        writer.writerow(item)
                    else:
                        writer.writerow([item])
