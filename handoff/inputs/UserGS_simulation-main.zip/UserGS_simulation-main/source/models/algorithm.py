from models.enum import Algorithms
from models.auction import ReverseAuction
from models.service_algorithm import ServiceAlgorithm
from models.sustainability_algorithm import SustainabilityAlgorithm
from models.falcon_algorithm import FalconAlgorithm


class Algorithm:
    def __init__(self, max_budget, dish_generator, delay_manager, constellation, data_manager, is_verbose) -> None:
        self.is_verbose = is_verbose
        self.reverse_auction = ReverseAuction(max_budget, dish_generator, delay_manager, constellation, data_manager)
        
        self.service_algorithm = ServiceAlgorithm(max_budget, dish_generator, delay_manager, constellation, data_manager, cost_margin=0)
        self.sustainability_algorithm = SustainabilityAlgorithm(max_budget, dish_generator, delay_manager, constellation, data_manager, cost_margin=0)
        self.falcon_algorithm = FalconAlgorithm(max_budget, dish_generator, delay_manager, constellation, data_manager, cost_margin=0)
        
        self.service_margin_5_algorithm = ServiceAlgorithm(max_budget, dish_generator, delay_manager, constellation, data_manager, cost_margin=0.05)
        self.sustainability_margin_5_algorithm = SustainabilityAlgorithm(max_budget, dish_generator, delay_manager, constellation, data_manager, cost_margin=0.05)
        self.falcon_margin_5_algorithm = FalconAlgorithm(max_budget, dish_generator, delay_manager, constellation, data_manager, cost_margin=0.05)
        

    def start(self, algo, tasks):
        if self.is_verbose:
            print('Running {}'.format(algo))
        if algo == Algorithms.DEFAULT:
            return tasks
        elif algo == Algorithms.REVERSE_AUCTION:
            return self.reverse_auction.start(tasks)
        elif algo == Algorithms.SERVICE:
            return self.service_algorithm.start(tasks)
        elif algo == Algorithms.SUSTAINABILITY:
            return self.sustainability_algorithm.start(tasks)
        elif algo == Algorithms.SERVICE_MARGIN_5:
            return self.service_margin_5_algorithm.start(tasks)
        elif algo == Algorithms.SUSTAINABILITY_MARGIN_5:
            return self.sustainability_margin_5_algorithm.start(tasks)
        elif algo == Algorithms.FALCON:
            return self.falcon_algorithm.start(tasks)
        elif algo == Algorithms.FALCON_MARGIN_5:
            return self.falcon_margin_5_algorithm.start(tasks)
        else:
            raise ValueError('Unknown algorithm.')
