import ephem
from models.satellite import Satellite
from models.topology import Topology
from helpers.users_scale import local_users_scaled_by_time
import math
import random


class Constellation:
    def __init__(self, num_orbits, satellites_per_orbit, altitude_m, inclination_angle_deg, name, tf):
        self.id = None
        self.name = name
        self.num_orbits = num_orbits
        self.tf = tf
        self.satellites_per_orbit = satellites_per_orbit
        self.altitude_m = altitude_m
        self.inclination_angle_deg = inclination_angle_deg
        self.universal_epoch = None
        self.satellite_id_counter = 0
        self.satellites = []
        self.generate_satellites()
        # self.export_tles()
        self.topology = Topology(self)

    def generate_satellites(self):
        for orbit_id in range(self.num_orbits):
            for satellite_pos in range(self.satellites_per_orbit):
                sat_id = self.get_sat_id_and_increment()
                sat = Satellite(
                    id=sat_id, name =self.name + '-sat-{}'.format(sat_id),
                    orbit_idx=orbit_id, sat_idx_on_orbit=satellite_pos, 
                    constellation=self, universal_epoch=self.universal_epoch
                )
                self.universal_epoch = sat.universal_epoch
                self.satellites.append(sat)
    
    def get_sat_id_and_increment(self):
        id = self.satellite_id_counter
        self.satellite_id_counter += 1
        return id

    def export_tles(self):
        with open(f"../output/{self.name}_tles.txt", "w") as f:
            f.write("{} {}\n".format(self.num_orbits, self.satellites_per_orbit))
            for sat in self.satellites:
                f.write("LEO-{} {}\n".format(sat.id, sat.id))
                f.write("{}\n".format(sat.tle[0]))
                f.write("{}\n".format(sat.tle[1]))

    def update_satellites(self, time_step):
        observer = ephem.Observer()
        observer.date = time_step.current_time
        for satellite in self.satellites:
            satellite.ephem.compute(observer)
            
    def randomize_satellite_dod(self, time_step):
        for sat in self.satellites:
            lat_deg = math.degrees(sat.ephem.sublat)
            lon_deg = math.degrees(sat.ephem.sublong)
            scaled_num_users = local_users_scaled_by_time(lat_deg, lon_deg, time_step.current_time, self.tf)
            if scaled_num_users == 0:
                continue
            max_random_dod = 0.1
            if scaled_num_users > 10:
                max_random_dod = 0.2
            elif scaled_num_users > 30:
                max_random_dod = 0.3
            random_capacity = sat.battery.max_capacity_watt_min * (1 - random.uniform(0.1, max_random_dod))
            sat.battery.current_capacity_watt_min = min(random_capacity, sat.battery.current_capacity_watt_min)
