from helpers.generate_tle import generate_tle_for_sat
from helpers.read_tles import tle_to_ephem
from models.battery import Battery
from helpers.energy_conversion import convert_joule_to_watt_min
import ephem
import math


class Satellite:
    def __init__(
            self, id, name, 
            ephem=None, orbit_idx=None, 
            sat_idx_on_orbit=None, constellation=None, universal_epoch=None) -> None:
        self.id = id
        self.name = name
        # bandwidth is set according to
        # Laser Intersatellite Links in a Starlink Constellation: A Classification and Analysis -> 2.5 Gbps
        # Satellite Edge Computing for Real-Time and Very-High Resolution Earth Observation -> 10 Gbps
        self.bandwidth_mbps = 2500.0
        self.ephem = ephem
        self.battery = Battery(random_cycle_life=True)
        self.universal_epoch = universal_epoch
        self.tle = None
        self.orbit_idx = orbit_idx
        self.sat_idx_on_orbit = sat_idx_on_orbit
        self.constellation = constellation
        self.create_ephem()
        self.table_lookup_watt_per_mbps = 0.01
        self.processor_watt_per_mbps = 0.01
        self.sending_watt_per_mbps = 0.05
        self.receiving_watt_per_mbps = 0.01
        self.constant_power_watt = 50
    
    def create_ephem(self):
        if self.constellation is None or self.orbit_idx is None or self.sat_idx_on_orbit is None:
            raise Exception('Cannot create ephem object.')
        tle_line1, tle_line2 = generate_tle_for_sat(
            satellite_id=self.id,
            orbit_index=self.orbit_idx,
            sat_index=self.sat_idx_on_orbit,
            num_orbits=self.constellation.num_orbits,
            num_sats_per_orbit=self.constellation.satellites_per_orbit,
            inclination_deg=self.constellation.inclination_angle_deg,
            altitude_m=self.constellation.altitude_m,
        )
        self.tle = (tle_line1, tle_line2)
        self.ephem, self.universal_epoch = tle_to_ephem(self.tle, self.universal_epoch)
        
    def route_traffic(self, traffic_mb):
        life_consumption, energy_consumption = self.consume_energy(traffic_mb)
        return life_consumption, energy_consumption
    
    def estimate_energy_consumption_watt_min(self, traffic_amount_mb):
        total_joule = 0
        total_joule += self.get_sending_energy_consumption_joule(traffic_amount_mb)
        total_joule += self.get_receiving_energy_consumption_joule(traffic_amount_mb)
        total_joule += self.get_table_look_up_energy_consumption_joule(traffic_amount_mb)
        total_joule += self.get_processor_energy_consumption_joule((traffic_amount_mb))
        return convert_joule_to_watt_min(total_joule)
    
    def consume_energy(self, traffic_amount_mb):
        total_life_consumption = 0
        total_energy_consumption = 0
        
        life_consumption, energy_consumption = self.consume_energy_sending(traffic_amount_mb)
        total_life_consumption += life_consumption
        total_energy_consumption += energy_consumption
        
        life_consumption, energy_consumption = self.consume_energy_for_receiving(traffic_amount_mb)
        total_life_consumption += life_consumption
        total_energy_consumption += energy_consumption
        
        life_consumption, energy_consumption = self.consume_energy_for_table_lookup(traffic_amount_mb)
        total_life_consumption += life_consumption
        total_energy_consumption += energy_consumption
        
        life_consumption, energy_consumption = self.consume_energy_for_processor(traffic_amount_mb)
        total_life_consumption += life_consumption
        total_energy_consumption += energy_consumption
        
        return total_life_consumption, total_energy_consumption
    
    def consume_energy_sending(self, traffic_amount_mb):
        energy_joule = self.get_sending_energy_consumption_joule(traffic_amount_mb)
        energy_watt_min = convert_joule_to_watt_min(energy_joule)
        life_consumption = self.battery.discharge(watt_min=energy_watt_min)
        return life_consumption, energy_watt_min
    
    def consume_energy_for_receiving(self, traffic_amount_mb):
        energy_joule = self.get_receiving_energy_consumption_joule(traffic_amount_mb)
        energy_watt_min = convert_joule_to_watt_min(energy_joule)
        life_consumption = self.battery.discharge(watt_min=energy_watt_min)
        return life_consumption, energy_watt_min
    
    def consume_energy_for_table_lookup(self, traffic_amount_mb):
        energy_joule = self.get_table_look_up_energy_consumption_joule(traffic_amount_mb)
        energy_watt_min = convert_joule_to_watt_min(energy_joule)
        life_consumption = self.battery.discharge(watt_min=energy_watt_min)
        return life_consumption, energy_watt_min
        
    def consume_energy_for_processor(self, traffic_amount_mb):
        energy_joule = self.get_processor_energy_consumption_joule(traffic_amount_mb)
        energy_watt_min = convert_joule_to_watt_min(energy_joule)
        life_consumption = self.battery.discharge(watt_min=energy_watt_min)
        return life_consumption, energy_watt_min
    
    def get_sending_energy_consumption_joule(self, traffic_amount_mb):
        return traffic_amount_mb * self.sending_watt_per_mbps
    
    def get_receiving_energy_consumption_joule(self, traffic_amount_mb):
        return traffic_amount_mb * self.receiving_watt_per_mbps
    
    def get_table_look_up_energy_consumption_joule(self, traffic_amount_mb):
        return traffic_amount_mb * self.table_lookup_watt_per_mbps
    
    def get_processor_energy_consumption_joule(self, traffic_amount_mb):
        return traffic_amount_mb * self.processor_watt_per_mbps
    
    def distance_from(self, satellite, time_step):
        """
        This code is borrowed from Hypatia distance_tool.py
        """
        # Use a third point observer for computing distance
        observer = ephem.Observer()
        observer.epoch = time_step.current_time
        observer.date = time_step.current_time
        observer.lat = 0
        observer.lon = 0
        observer.elevation = 0

        self.ephem.compute(observer)
        satellite.ephem.compute(observer)

        # Angle between observer and satellites
        angle_radians = float(repr(ephem.separation(self.ephem,  satellite.ephem)))

        # Triangle
        return math.sqrt(self.ephem.range ** 2 +  satellite.ephem.range ** 2 - (2 * self.ephem.range *  satellite.ephem.range * math.cos(angle_radians)))
