from enum import Enum


class EVENT_ID(Enum):
    UPDATE_SATELLITES = 1
    GENERATE_TRAFFIC = 2
    CHARGE_SATELLITES = 3
    ROUTE_TRAFFIC = 4
    GENERATE_TASKS = 5
    RANDOMIZE_DOD = 6
    START_ALGORITHM = 7


class Algorithms(Enum):
    DEFAULT = 0  # Just take shortest path on hop count
    REVERSE_AUCTION = 1
    SERVICE = 2  # SERvICE: A Software Defined Framework for Integrated Space-Terrestrial Satellite Communication
    SUSTAINABILITY = 3  # Towards Sustainable Multi-Tier Space Networking for LEO Satellite Constellations
    SERVICE_MARGIN_5 = 4  # Add 5% margin to cost
    SUSTAINABILITY_MARGIN_5 = 5  # Add 5% margin to cost
    FALCON = 6  # Falcon: Towards Fast and Scalable Data Delivery for Emerging Earth Observation Constellations
    FALCON_MARGIN_5 = 7  # Add 5% margin to cost


class GS_TYPES(Enum):
    AWS_GS = 0
    BASE_STATION = 1