from helpers.users_scale import map_lat_long_to_grid
from models.global_var import OFFLOADING_SAT_INDEX, AUCTION_COST_MARGIN
import math
import time
from itertools import combinations
from models.auction_utility import AuctionUtility
from helpers.log_message import log_message_to_csv


class ReverseAuction:
    def __init__(self, max_budget, dish_generator, delay_manager, constellation, data_manager) -> None:
        self.dish_generator = dish_generator
        self.delay_manager = delay_manager
        self.constellation = constellation
        self.data_manager = data_manager
        self.data_manager.data['remaining_budget'] = []
        self.data_manager.data['budget_after_each_task'] = []
        self.data_manager.data['collaborator_group_set_construction_runtime_second_per_task'] = []
        self.data_manager.data['collaborator_selection_and_truthful_payment_runtime_second_per_task'] = []
        self.group_num_times_selected_table = {}
        self.max_budget = max_budget
        self.current_budget = self.max_budget
        self.offloading_satellite_index = OFFLOADING_SAT_INDEX
        self.auction_utility = AuctionUtility(delay_manager, constellation)
        
        # Add overview tables for debugging
        self.utility_table = {}
        self.utility_cost_ratio_table = {}
    
    def start(self, tasks):
        self.current_budget = self.max_budget  # Reset budget for each interval
        self.data_manager.data['budget_after_each_task'].append([])
        for task in tasks:
            self.data_manager.data['budget_after_each_task'][-1].append(self.current_budget)
            bids = self.collect_bids(task)
            
            start_time = time.time()
            collaborator_group_set = self.collaborator_group_set_construction(task, bids, N=2, top_m=10)
            end_time = time.time()
            self.data_manager.data['collaborator_group_set_construction_runtime_second_per_task'].append(end_time - start_time)
            
            if len(collaborator_group_set) == 0:  # No eligible bidders, so no winner
                continue
            
            start_time = time.time()
            collaborator_group, collaborator_utility = self.collaborator_selection_and_truthful_payment(task, collaborator_group_set)
            end_time = time.time()
            self.data_manager.data['collaborator_selection_and_truthful_payment_runtime_second_per_task'].append(end_time - start_time)
            
            if collaborator_group is None:  # Algorithm 2 may also filter out all bidders
                continue
            task.winner = collaborator_group
            task.auction_utility = self.auction_utility.utility_of(task, task.winner)
            task.cost = self.total_cost(task.winner)
            task.path_with_offloading = self.get_path_with_offloading(task)
            if self.total_traffic_amount(task.winner) < task.traffic_amount_mb_requirement:
                raise Exception('Traffic amount not satisfied.')
        self.data_manager.data['remaining_budget'].append(self.current_budget)
        return tasks
    
    def get_path_with_offloading(self, task):
        return task.path_without_offloading[:self.offloading_satellite_index + 1 + task.winner[0].offloading_sat_offset]

    def collect_bids(self, task):
        # Collect bids based on location
        source_sat = task.traffic_pair[0]
        source_lat_deg = math.degrees(source_sat.ephem.sublat)
        source_long_deg = math.degrees(source_sat.ephem.sublong)
        
        dest_sat = task.traffic_pair[1]
        dest_lat_deg = math.degrees(dest_sat.ephem.sublat)
        dest_long_deg = math.degrees(dest_sat.ephem.sublong)
        
        row, col = map_lat_long_to_grid(source_lat_deg, source_long_deg)
        dishes = self.dish_generator.dish_grid[row, col]
        bids = []
        for dish in dishes:
            bids.append(dish.propose_bid(dest_lat_deg, dest_long_deg, cost_margin=AUCTION_COST_MARGIN))        
        return bids
   
    def collaborator_group_set_construction(self, task, bids, N, top_m):
        """
        Algorithm 1: Collaborator group set construction
        https://www.notion.so/davidchou/Work-Note-Auction-Does-Not-Perform-Well-797d007d3848477ab4c2a91332e9bd3f
        """
        collaborator_group_set = {}
        candidate_bids = []
        for bid in bids:
            task_delay_ms = self.delay_manager.delay_ms(
                task.path_without_offloading, 
                task.traffic_amount_mb_requirement, [bid], offloading_sat_index=self.offloading_satellite_index, is_offloaded=True)
            if task_delay_ms <= task.delay_ms_requirement:
                candidate_bids.append([bid])

        # Construct layer-1 groups
        G_bar_power_set_candidate_bids = []
        G_bar_power_set_candidate_bids += self.k_subsets(candidate_bids, k=1)
        top_m_groups = self.get_top_m_groups(G_bar_power_set_candidate_bids, m=top_m)
        
        # Construct layer-n groups, where n = 2, ..., N
        for layer in range(2, N + 1):
            new_subset = self.k_subsets(top_m_groups, k=2)  # Merge two groups
            G_bar_power_set_candidate_bids += new_subset
            top_m_groups = self.get_top_m_groups(new_subset, m=top_m)
        
        # Remove candidate bid set if does not satisfy traffic requirement or bandwidth requirement
        for g in G_bar_power_set_candidate_bids.copy():
            if self.total_traffic_amount(g) < task.traffic_amount_mb_requirement or \
                self.total_bandwidth_mbps(g) < task.bandwidth_mbps_requirement:
                G_bar_power_set_candidate_bids.remove(g)

        # Check if budget can cover the cost for each collaborator_group_set
        for g in G_bar_power_set_candidate_bids:
            if self.total_cost(g) <= self.current_budget:
                collaborator_group_set[self.get_group_bidder_ids(g)] = g
        
        return collaborator_group_set
    
    def get_top_m_groups(self, groups, m):
        sorted_groups = sorted(groups, key=lambda group: self.total_cost(group))
        if len(sorted_groups) < m:
            return sorted_groups[:len(sorted_groups)]
        else:
            return sorted_groups[:m]
    
    def k_subsets(self, list_of_lists, k):
        # Generate all possible k-sized combinations from the list of lists
        k_combinations = combinations(list_of_lists, k)
        
        # Flatten and concatenate the lists for each combination
        flattened_combinations = [sum(combo, []) for combo in k_combinations]
        
        return flattened_combinations

    def archived_collaborator_group_set_construction(self, task, bids, N):
        """
        Algorithm 1: Collaborator group set construction
        N: the number of collaborators is upper bounded by N
        """
        collaborator_group_set = {}
        candidate_bids = []
        for bid in bids:
            if bid.pop_delay_ms <= task.delay_ms_requirement:
                candidate_bids.append(bid)
        # Sort candiadate bid set by traffic amount in non-decreasing order
        candidate_bids = sorted(candidate_bids, key=lambda bid: bid.traffic_amount_mb, reverse=True)
        
        # Get power set from candidate bids first N - 1 items
        G_bar_power_set_candidate_bids = self.get_limited_power_set(candidate_bids, N - 1)
        
        # Remove candidate bid set if does not satisfy traffic requirement or bandwidth requirement
        for g in G_bar_power_set_candidate_bids.copy():
            if self.total_traffic_amount(g) < task.traffic_amount_mb_requirement or \
                self.total_bandwidth_mbps(g) < task.bandwidth_mbps_requirement:
                G_bar_power_set_candidate_bids.remove(g)
        
        # Try adding one more bid to N-1 set and check requirements
        X = N
        while X < len(candidate_bids):
            g_bar_set_of_first_N_mius_1_items = candidate_bids[:N-1]
            if self.total_traffic_amount(g_bar_set_of_first_N_mius_1_items) + candidate_bids[X].traffic_amount_mb \
                >= task.traffic_amount_mb_requirement and \
                self.total_bandwidth_mbps(g_bar_set_of_first_N_mius_1_items) + candidate_bids[X].bandwidth_mbps \
                >= task.bandwidth_mbps_requirement:
                    
                g_bar_set_of_first_N_mius_1_items.append(candidate_bids[X])
                G_bar_power_set_candidate_bids.append(g_bar_set_of_first_N_mius_1_items.copy())
                
            X += 1

        # Check if budget can cover the cost for each collaborator_group_set
        for g in G_bar_power_set_candidate_bids:
            if self.total_cost(g) <= self.current_budget:
                collaborator_group_set[self.get_group_bidder_ids(g)] = g
        
        return collaborator_group_set
    
    def collaborator_selection_and_truthful_payment(self, task, collaborator_group_set):
        """
        Algorithm 2: Collaborator selection and truthful payment
        """
        g_kappa = None
        g_kappa_utility = None
        while g_kappa is None and len(collaborator_group_set) > 0:
            group_with_max_ratio_g_kappa_bar, U_ij_to_kappa_bar, U_ij_to_kappa_bar_uc_ratio = self.arg_max_utility_ratio(task, collaborator_group_set)
            if U_ij_to_kappa_bar_uc_ratio == 0:
                # If the best bid has zero utility, simply skip to next bid.
                collaborator_group_set.pop(group_with_max_ratio_g_kappa_bar, None)
                continue
            n_sum = self.get_n_sum(collaborator_group_set)
            g_kappa_bar = collaborator_group_set.pop(group_with_max_ratio_g_kappa_bar, None)
            if len(collaborator_group_set) == 0:  # If there is only one bidder
                mathcal_U_uc_ratio = U_ij_to_kappa_bar_uc_ratio
            else:  # More than one bidders
                _, _, mathcal_U_uc_ratio = self.arg_max_utility_ratio(task, collaborator_group_set)
            n_k = self.check_group_num_times_selected(g_kappa_bar)
            if mathcal_U_uc_ratio == 0:
                # If the second best bid has zero utility, simply use the cost as the payment for the best bid
                payment_ij_to_kappa_bar = self.total_cost(g_kappa_bar)
            else:
                if mathcal_U_uc_ratio == 0:
                    log_message_to_csv('../output/logs.csv', 'mathcal_U_uc_ratio cannot be zero.')
                    raise Exception(f'mathcal_U_uc_ratio cannot be zero.')
                payment_ij_to_kappa_bar = \
                    (U_ij_to_kappa_bar + self.total_cost(g_kappa_bar) * math.sqrt(2*n_sum/n_k)) / mathcal_U_uc_ratio
            if round(payment_ij_to_kappa_bar, 10) < round(self.total_cost(g_kappa_bar), 10):
                raise AssertionError('Payment is smaller than cost.')
            if payment_ij_to_kappa_bar <= self.current_budget:
                self.current_budget -= payment_ij_to_kappa_bar
                task.payment = payment_ij_to_kappa_bar
                g_kappa = g_kappa_bar
                g_kappa_utility = U_ij_to_kappa_bar
                self.increment_group_num_times_selected(g_kappa)
        return g_kappa, g_kappa_utility
    
    def get_limited_power_set(self, original_set, max_subset_size):
        power_set = [[]]
        limited_set = original_set[:max_subset_size]
        for element in limited_set:
            power_set += [subset + [element] for subset in power_set]
        return power_set
    
    def total_traffic_amount(self, group):
        total = 0
        for b in group:
            total += b.traffic_amount_mb
        return total
    
    def total_bandwidth_mbps(self, group):
        total = 0
        for b in group:
            total += b.bandwidth_mbps
        return total
    
    def total_cost(self, group):
        total = 0
        for b in group:
            total += b.cost
        return total
    
    def total_group_set_num_times_selected(self, collaborator_group_set):
        total = 0
        for g in collaborator_group_set.values():
            total += self.check_group_num_times_selected(g)
        return total
    
    def check_group_num_times_selected(self, group):
        bidder_ids = self.get_group_bidder_ids(group)
        if bidder_ids not in self.group_num_times_selected_table:
            self.group_num_times_selected_table[bidder_ids] = 1  # TODO: should this be defaulted to 1?
        return self.group_num_times_selected_table[bidder_ids]
    
    def increment_group_num_times_selected(self, group):
        bidder_ids = self.get_group_bidder_ids(group)
        self.group_num_times_selected_table[bidder_ids] += 1

    def get_group_bidder_ids(self, group):
        """
        This returns a consistent id tupple for the group to check on the dictionary.
        """
        bidder_ids = []
        for bid in group:
            bidder_ids.append(bid.bidder.id)
        bidder_ids.sort()
        bidder_ids = tuple(bidder_ids)
        return bidder_ids
    
    def arg_max_utility_ratio(self, task, collaborator_group_set):
        """
        Return the utility-cost ratio, utility and the group key that has the maximum 
        utility-cost ratio.
        Return group_key, utility, uc_ratio
        """
        self.utility_table = {}
        self.utility_cost_ratio_table = {}
        
        max_uc_ratio_group_key = None
        max_uc_ratio_utility = float('-inf')
        max_uc_ratio = float('-inf')
        for group_key, g in collaborator_group_set.items():
            uc_ratio, utility = self.utility_cost_ratio_of(task, g, collaborator_group_set)
            self.utility_table[group_key] = utility
            self.utility_cost_ratio_table[group_key] = uc_ratio
            if uc_ratio > max_uc_ratio:
                max_uc_ratio_group_key = group_key
                max_uc_ratio_utility = utility
                max_uc_ratio = uc_ratio
        if max_uc_ratio == float('-inf'):
            raise ValueError(f'max_uc_ratio has an invalid value of {max_uc_ratio}')
        return max_uc_ratio_group_key, max_uc_ratio_utility, max_uc_ratio
    
    def utility_cost_ratio_of(self, task, group, collaborator_group_set):
        # Note: after removing the best group, n_sum changes to n_prime_sum
        # so the second best group uc ratio will be slightly different
        # than the previous check
        n_sum = self.get_n_sum(collaborator_group_set)
        n_k = self.check_group_num_times_selected(group)
        utility = self.auction_utility.utility_of(task, group)
        uc_ratio = utility / self.total_cost(group) + math.sqrt(2 * n_sum / n_k)
        return uc_ratio, utility
    
    def get_n_sum(self, collaborator_group_set):
        return math.log(self.total_group_set_num_times_selected(collaborator_group_set))


class Bid:
    def __init__(self, cost, traffic_amount_mb, pop_delay_ms, bandwidth_mbps, offloading_sat_offset, bidder) -> None:
        self.cost = cost
        self.traffic_amount_mb = traffic_amount_mb
        self.pop_delay_ms = pop_delay_ms
        self.bandwidth_mbps = bandwidth_mbps
        self.offloading_sat_offset = offloading_sat_offset
        self.bidder = bidder


class CollaboratorGroup:
    def __init__(self) -> None:
        pass
