from geopy.distance import geodesic
from scipy.constants import c
import numpy as np
from models.auction import Bid
from helpers.users_scale import map_grid_to_lat_long, local_users
from models.aws_ground_station import get_num_aws_gs
from models.enum import GS_TYPES
import random


class Dish:
    def __init__(self, id, lat_deg, long_deg, bandwidth_mbps, row, col, type, avg_failure_rate) -> None:
        self.id = id
        self.lat_deg = lat_deg
        self.long_deg = long_deg
        self.bandwidth_mbps = bandwidth_mbps
        self.avg_failure_rate = avg_failure_rate
        self.empirical_failure_rate = avg_failure_rate
        self.number_of_times_won_bids = 0
        self.row = row
        self.col = col
        self.type: GS_TYPES = type
        
        # Network Characteristics of LEO Satellite Constellations: A Starlink-Based Measurement from End Users
        # Conversion from INFOCOM measurement paper
        # 56.3 Watt, 80Mb/s throughput => 0.704 Watt/ Mbps
        self.epsilon_d = 0.704
        
        # https://aws.amazon.com/ec2/pricing/on-demand/
        # First 10 TB / Month: $0.09 per GB
        self.alpha = 0.09 / 8000.0  # price per Mb
        
        # https://azure.microsoft.com/en-ca/pricing/details/orbital/
        # $10 per min -> 0.17 per second
        self.beta = 0.17
    
    def propose_bid(self, dest_lat_deg, dest_long_deg, cost_margin=0) -> Bid:
        traffic_amount_mb = np.random.choice([50, 100, 200, 400])
        bandwidth_mbps = self.bandwidth_mbps * np.random.uniform(0.8, 1)
        bid = Bid(
            cost=self.get_dish_cost(traffic_amount_mb, bandwidth_mbps, cost_margin),
            traffic_amount_mb=traffic_amount_mb,
            pop_delay_ms=self.delay_ms_between(dest_lat_deg, dest_long_deg),
            bandwidth_mbps=bandwidth_mbps,
            offloading_sat_offset=random.randint(0, 2),
            bidder=self
        )
        return bid
    
    def get_dish_cost(self, traffic_amount_mb, bandwidth_mbps, cost_margin):
        cost = self.alpha * traffic_amount_mb + self.beta * (traffic_amount_mb / bandwidth_mbps)
        return cost * (1 + cost_margin)
    
    def delay_ms_between(self, lat_deg, long_deg):
        dist_m = geodesic((self.lat_deg, self.long_deg), (lat_deg, long_deg)).meters
        prop_delay_ms = dist_m / (c * 2 / 3) * 1000.0
        delay_ms = prop_delay_ms + np.random.uniform(0, 10)
        return delay_ms
    
    def update_empirical_failure_rate_and_num_wins(self, has_failed: bool):
        if has_failed:
            sigma = 1
        else:
            sigma = 0
        self.empirical_failure_rate = (self.empirical_failure_rate * self.number_of_times_won_bids + sigma) \
            / (self.number_of_times_won_bids + 1)
        self.number_of_times_won_bids += 1


class DishManager:
    def __init__(self, user_grid, avg_failure_rate, bad_dish_prob, failure_rate_fluctuation) -> None:
        self.user_grid = np.array(user_grid)
        self.dishes = []
        self.dish_grid = self.init_dish_grid()
        self.id_counter = 0
        self.avg_failure_rate = avg_failure_rate
        self.bad_dish_prob = bad_dish_prob
        self.failure_rate_fluctuation = failure_rate_fluctuation
        self.generate_dishes()
    
    def generate_dishes(self):
        # https://aws.amazon.com/ground-station/faqs/
        # Q. What transmit and receive operational frequencies does AWS Ground Station support?
        # https://www.notion.so/davidchou/Dish-bandwidth-setting-43a6eb309191463c8ca8ac64ac5eb3cf
        aws_gs_bandwidth_mbps = 4327
        
        # Ultra-Dense LEO Satellite Offloading for Terrestrial Networks: How Much to Pay the Satellite Operator?
        # https://www.notion.so/davidchou/Dish-bandwidth-setting-43a6eb309191463c8ca8ac64ac5eb3cf
        base_stations_4g_5g_bandwidth_mbps = 1600
        
        for row in range(self.user_grid.shape[0]):
            for col in range(self.user_grid.shape[1]):
                lat_deg, long_deg = map_grid_to_lat_long(row, col)
                num_user = local_users(lat_deg=lat_deg, lon_deg=long_deg)
                # TODO: if re-define dish such that dish includes AWS, can distribute dish based on AWS datacenter locations
                for i in range(num_user):
                    dish = Dish(id=self.get_id_and_increment(), lat_deg=lat_deg, 
                                long_deg=long_deg, bandwidth_mbps=base_stations_4g_5g_bandwidth_mbps * np.random.uniform(0.8, 1), 
                                row=row, col=col, type=GS_TYPES.BASE_STATION, avg_failure_rate=self.fluctuate_failure_rate(self.bad_dish_prob))
                    self.dish_grid[row, col].append(dish)
                    self.dishes.append(dish)
                    
                # Check if there is a AWS ground station
                num_aws_gs = get_num_aws_gs(row, col)
                if num_aws_gs != 0:
                    aws_dish = Dish(id=self.get_id_and_increment(), lat_deg=lat_deg, 
                            long_deg=long_deg, bandwidth_mbps=aws_gs_bandwidth_mbps * np.random.uniform(0.8, 1), 
                            row=row, col=col, type=GS_TYPES.AWS_GS, avg_failure_rate=self.fluctuate_failure_rate(self.bad_dish_prob))
                    self.dishes.append(aws_dish)

    def get_id_and_increment(self):
        id = self.id_counter
        self.id_counter += 1
        return id
    
    def init_dish_grid(self):
        dish_grid = np.empty(self.user_grid.shape, dtype=object)
        for i in range(self.user_grid.shape[0]):
            for j in range(self.user_grid.shape[1]):
                dish_grid[i, j] = []
        return dish_grid
    
    def fluctuate_failure_rate(self, bad_dish_prob):
        # Some dishes may have high failure rate
        fluctuation = None
        if random.random() < bad_dish_prob:
            fluctuation = self.failure_rate_fluctuation
        else:
            fluctuation = 1
        rate = self.avg_failure_rate * fluctuation
        if rate > 1 or rate < 0:
            raise Exception(f'Invalid failure rate: {rate}')
        return rate
