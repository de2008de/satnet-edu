import networkx as nx


class Topology:
    def __init__(self, constellation) -> None:
        self.constellation = constellation
        self.hop_count_graph = nx.Graph()
        self.build_hop_count_graph()
        
    def build_hop_count_graph(self):
        for sat in self.constellation.satellites:
            self.hop_count_graph.add_node(sat.id)
        for sat in self.constellation.satellites:
            t_neighbor_id, b_neighbor_id = self.intra_orbit_neighbor_ids(sat)
            l_neighbor_id, r_neighbor_id = self.inter_orbit_neighbor_ids(sat)
            self.hop_count_graph.add_edge(sat.id, t_neighbor_id, weight=1)
            self.hop_count_graph.add_edge(sat.id, b_neighbor_id, weight=1)
            self.hop_count_graph.add_edge(sat.id, l_neighbor_id, weight=1)
            self.hop_count_graph.add_edge(sat.id, r_neighbor_id, weight=1)
    
    def intra_orbit_neighbor_ids(self, sat):
        sats_per_orbit = self.constellation.satellites_per_orbit
        orbit_id = sat.orbit_idx
        sat_index = sat.id - (orbit_id * sats_per_orbit)
        top_neighbor_id = ((sat_index + 1) % sats_per_orbit) + (orbit_id * sats_per_orbit)
        bottom_neighbor_id = ((sat_index + sats_per_orbit - 1) % sats_per_orbit) + (orbit_id * sats_per_orbit)
        return top_neighbor_id, bottom_neighbor_id
    
    def inter_orbit_neighbor_ids(self, sat):
        num_orbits = self.constellation.num_orbits
        sats_per_orbit = self.constellation.satellites_per_orbit
        orbit_id = sat.orbit_idx
        sat_index = sat.id - (orbit_id * sats_per_orbit)
        left_orbit_id = (orbit_id + num_orbits - 1) % num_orbits
        right_orbit_id = (orbit_id + 1) % num_orbits
        # Assume no orbital seams
        left_neighbor_id = left_orbit_id * sats_per_orbit + sat_index
        right_neighbor_id = right_orbit_id * sats_per_orbit + sat_index
        return left_neighbor_id, right_neighbor_id    
