import random
from models.enum import Algorithms
from models.global_var import OFFLOADING_SAT_INDEX


class Routing:
    def __init__(self, constellation, data_manager, delay_manager, algo) -> None:
        self.constellation = constellation
        self.data_manager = data_manager
        self.data_manager.data['total_life_consumption'] = []
        self.data_manager.data['total_energy_consumption'] = []
        self.data_manager.data['total_delay_ms'] = []
        self.data_manager.data['per_task_delay_ms'] = []
        self.data_manager.data['is_task_offloaded'] = []
        self.data_manager.data['per_offloaded_task_cost'] = []
        self.data_manager.data['per_offloaded_task_payment'] = []
        self.data_manager.data['per_offloaded_task_uc_ratio'] = []
        self.data_manager.data['group_size_each_task'] = []
        self.data_manager.data['per_offloaded_task_traffic_requirement_mb'] = []
        self.data_manager.data['per_offloaded_task_bandwidth_requirement_mbps'] = []
        self.data_manager.data['per_offloaded_task_delay_requirement_ms'] = []
        self.data_manager.data['per_offloaded_task_winner_traffic_mb'] = []
        self.data_manager.data['per_offloaded_task_winner_bandwidth_mbps'] = []
        self.data_manager.data['per_offloaded_task_winner_delay_ms'] = []
        self.data_manager.data['per_offloaded_task_is_failed'] = []
        self.data_manager.data['per_offloaded_task_conserved_life_consumption'] = []
        self.data_manager.data['per_offloaded_task_conserved_energy_consumption'] = []
        self.data_manager.data['per_offloaded_task_reduced_end_to_end_delay'] = []
        self.delay_manager = delay_manager
        self.algo = algo  
    
    def route_traffic(self, tasks):
        total_life_consumption = 0
        total_energy_consumption = 0
        total_delay_ms = 0
        self.data_manager.data['per_task_delay_ms'].append([])
        self.data_manager.data['is_task_offloaded'].append([])
        self.data_manager.data['per_offloaded_task_cost'].append([])
        self.data_manager.data['per_offloaded_task_payment'].append([])
        self.data_manager.data['per_offloaded_task_uc_ratio'].append([])
        self.data_manager.data['group_size_each_task'].append([])
        self.data_manager.data['per_offloaded_task_traffic_requirement_mb'].append([])
        self.data_manager.data['per_offloaded_task_bandwidth_requirement_mbps'].append([])
        self.data_manager.data['per_offloaded_task_delay_requirement_ms'].append([])
        self.data_manager.data['per_offloaded_task_winner_traffic_mb'].append([])
        self.data_manager.data['per_offloaded_task_winner_bandwidth_mbps'].append([])
        self.data_manager.data['per_offloaded_task_winner_delay_ms'].append([])
        self.data_manager.data['per_offloaded_task_is_failed'].append([])
        self.data_manager.data['per_offloaded_task_conserved_life_consumption'].append([])
        self.data_manager.data['per_offloaded_task_conserved_energy_consumption'].append([])
        self.data_manager.data['per_offloaded_task_reduced_end_to_end_delay'].append([])
        for task in tasks:
            source_sat, dest_sat, traffic_mb = task.traffic_pair
            if traffic_mb == 0:
                continue
            is_failed = False
            is_offloaded = False
            if self.has_winner(task):
                is_offloaded = True
                if self.has_failed(task):
                    is_failed = True
                    is_offloaded = False
                    path = task.path_without_offloading
                    self.update_dish_empirical_failure_rate_and_num_wins(task, has_failed=True)
                    self.data_manager.data['per_offloaded_task_is_failed'][-1].append(True)
                else:
                    path = task.path_with_offloading
                    self.update_dish_empirical_failure_rate_and_num_wins(task, has_failed=False)
                    self.data_manager.data['per_offloaded_task_is_failed'][-1].append(False)
            else:
                path = task.path_without_offloading

            per_task_actual_life_consumption = 0
            per_task_actual_energy_consumption = 0  
            for sat_id in path:
                life_consumption, energy_consumption = self.constellation.satellites[sat_id].route_traffic(traffic_mb)
                
                total_life_consumption += life_consumption
                total_energy_consumption += energy_consumption
                
                per_task_actual_life_consumption += life_consumption
                per_task_actual_energy_consumption += energy_consumption
            
            # GSL energy consumption is already included
            # because the last satellite hop contains sending energy
            # We do not need to consider dish receiving energy because it is in the dish cost
            task_delay_ms = self.delay_manager.delay_ms(task.path_without_offloading, traffic_mb, task.winner, offloading_sat_index=OFFLOADING_SAT_INDEX, is_offloaded=is_offloaded)
            if task_delay_ms > task.delay_ms_requirement:
                raise Exception('Task delay exceeds the delay requirement.')
            
            # If offloading fails, add delay penalty
            if is_failed:
                task_delay_ms += self.get_offloading_failed_delay_penalty(task)
            
            total_delay_ms += task_delay_ms
            self.data_manager.data['per_task_delay_ms'][-1].append(task_delay_ms)
            if is_offloaded:
                self.data_manager.data['is_task_offloaded'][-1].append(True)
                self.data_manager.data['per_offloaded_task_uc_ratio'][-1].append(task.auction_utility / task.cost)
                self.data_manager.data['group_size_each_task'][-1].append(len(task.winner))
                
                self.data_manager.data['per_offloaded_task_cost'][-1].append(self.get_task_cost(task))
                self.data_manager.data['per_offloaded_task_payment'][-1].append(task.payment)
                
                self.data_manager.data['per_offloaded_task_traffic_requirement_mb'][-1].append(task.traffic_amount_mb_requirement)
                self.data_manager.data['per_offloaded_task_bandwidth_requirement_mbps'][-1].append(task.bandwidth_mbps_requirement)
                self.data_manager.data['per_offloaded_task_delay_requirement_ms'][-1].append(task.delay_ms_requirement)
                
                self.data_manager.data['per_offloaded_task_winner_traffic_mb'][-1].append(self.winner_total_traffic_mb(task))
                self.data_manager.data['per_offloaded_task_winner_bandwidth_mbps'][-1].append(self.winner_total_bandwidth_mbps(task))
                self.data_manager.data['per_offloaded_task_winner_delay_ms'][-1].append(task_delay_ms)
                
                # Calculate conserved amount
                non_off_life_consumption, non_off_energy_consumption = self.compute_non_offloading_life_energy_consumption(task, traffic_mb)
                conserved_life_consumption = non_off_life_consumption - per_task_actual_life_consumption
                conserved_energy_consumption = non_off_energy_consumption - per_task_actual_energy_consumption
                non_off_end_to_end_delay_ms = self.compute_non_off_end_to_end_delay_ms(task, traffic_mb)
                reduced_end_to_end_delay_ms = non_off_end_to_end_delay_ms - task_delay_ms
                if conserved_life_consumption < 0 or conserved_energy_consumption < 0:
                    raise Exception('Invalid conservation values.')
                self.data_manager.data['per_offloaded_task_conserved_life_consumption'][-1].append(conserved_life_consumption)
                self.data_manager.data['per_offloaded_task_conserved_energy_consumption'][-1].append(conserved_energy_consumption)
                self.data_manager.data['per_offloaded_task_reduced_end_to_end_delay'][-1].append(reduced_end_to_end_delay_ms)
                
            else:
                self.data_manager.data['is_task_offloaded'][-1].append(False)
        
        self.data_manager.data['total_life_consumption'].append(total_life_consumption)
        self.data_manager.data['total_energy_consumption'].append(total_energy_consumption)
        self.data_manager.data['total_delay_ms'].append(total_delay_ms)
    
    def get_offloading_failed_delay_penalty(self, task):
        return self.delay_manager.offloading_gsl_delay_ms(task)
    
    def compute_non_off_end_to_end_delay_ms(self, task, traffic_mb):
        return self.delay_manager.delay_ms(task.path_without_offloading, traffic_mb, task.winner, is_offloaded=False)
    
    def compute_non_offloading_life_energy_consumption(self, task, traffic_mb):
        total_life_consumption = 0
        total_energy_consumption = 0
        for sat_id in task.path_without_offloading:
            sat = self.constellation.satellites[sat_id]
            energy_consumption = sat.estimate_energy_consumption_watt_min(traffic_mb)
            life_consumption = sat.battery.estimate_life_consumption(energy_consumption)
            
            total_life_consumption += life_consumption
            total_energy_consumption += energy_consumption
            
        return total_life_consumption, total_energy_consumption
    
    def has_winner(self, task) -> bool:
        if task.winner is not None and task.path_with_offloading is not None:
            return True
        return False
    
    def has_failed(self, task):
        for bid in task.winner:
            if random.random() < bid.bidder.avg_failure_rate:
                return True
        return False
    
    def update_dish_empirical_failure_rate_and_num_wins(self, task, has_failed: bool):
        if self.algo is not Algorithms.REVERSE_AUCTION:
            return
        for bid in task.winner:
            dish = bid.bidder
            dish.update_empirical_failure_rate_and_num_wins(has_failed)

    def get_task_cost(self, task):
        if task.winner is None:
            return 0
        total_cost = 0
        for bid in task.winner:
            total_cost += bid.cost
        return total_cost
    
    def winner_total_traffic_mb(self, task):
        total_traffic = 0
        for bid in task.winner:
            total_traffic += bid.traffic_amount_mb
        return total_traffic
    
    def winner_total_bandwidth_mbps(self, task):
        total_bandwidth = 0
        for bid in task.winner:
            total_bandwidth += bid.bandwidth_mbps
        return total_bandwidth
