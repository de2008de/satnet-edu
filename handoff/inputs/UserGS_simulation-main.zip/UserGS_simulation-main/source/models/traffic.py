import math
import numpy as np
import networkx as nx
import random
from helpers.users_scale import local_users_scaled_by_time, local_users_time


class TrafficGenerator:
    def __init__(self, constellation, tf) -> None:
        self.constellation = constellation
        self.SECONDS_PER_MIN = 60
        self.PER_USER_TRAFFIC_KBPS = 1024 * 300
        self.tf = tf
    
    def generate_traffic(self, time_step):
        traffic_pairs = []
        for sat in self.constellation.satellites:
            traffic_mb = self.generate_traffic_from_sat_mb(sat, time_step)
            dest = self.choose_dest(sat, list(range(20, 25)))
            traffic_pairs.append((sat, dest, traffic_mb))
        return traffic_pairs
    
    def generate_traffic_from_sat_mb(self, sat, time_step):
        lat_deg = math.degrees(sat.ephem.sublat)
        lon_deg = math.degrees(sat.ephem.sublong)
        num_users, local_time = local_users_time(lat_deg, lon_deg, time_step.current_time, self.tf)
        scaled_num_users = local_users_scaled_by_time(lat_deg, lon_deg, time_step.current_time, self.tf)
        if num_users == 0:
            return 0
        users_per_min = self.poisson_distribution(num_users, 1)
        # per_user_traffic_kbps_list = self.normal_distribution(self.PER_USER_TRAFFIC_KBPS, sum(users_per_min), self.PER_USER_TRAFFIC_KBPS)
        # total_traffic_kpbs = sum(per_user_traffic_kbps_list)
        traffic_amount_mb = self.PER_USER_TRAFFIC_KBPS / 1024.0
        traffic_amount_mb = traffic_amount_mb * scaled_num_users / num_users
        return traffic_amount_mb
    
    def poisson_distribution(self, rate, n):
        return np.random.poisson(rate, n)
    
    def normal_distribution(self, rate, n, std):
        values = np.random.normal(loc=rate, scale=std, size=n)
        values = np.maximum(values, 0)
        return values

    def choose_dest(self, source_sat, distance_range):
        """
        Assume there is CDN or edge servers to satistfy requests.
        Therefore, the diestination is within a specified distance.
        """
        shortest_path_lengths = nx.single_source_shortest_path_length(
            self.constellation.topology.hop_count_graph, source_sat.id
        )
        destinations = []
        while len(destinations) == 0:
            for node, dist in shortest_path_lengths.items():
                if dist in distance_range and node != source_sat.id:
                    destinations.append(node)
            if len(destinations) == 0:
                # possibly the constellation size is too small for large distances
                distance_range = [int(_d / 2) for _d in distance_range]
                
        dest_id = random.choice(destinations)
        return self.constellation.satellites[dest_id]
