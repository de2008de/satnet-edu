class Energy:
    def __init__(self, constellation) -> None:
        self.constellation = constellation
        # Towards Energy-Efficient Routing in Satellite Networks
        # Max solar output is set as 500 Watt from the reference
        # Since our interval is 60 seconds (1 min), so here we set 500 Watt * 1 min = 500 Watt min
        self.energy_source_watt_min = 500

    def charge_satellites(self):
        for sat in self.constellation.satellites:
            if sat.ephem.eclipsed:
                continue
            sat.battery.charge(self.energy_source_watt_min)
