from scipy.constants import c
from helpers.users_scale import local_users_scaled_by_time, local_users
import math
from models.global_var import AVG_PKT_SIZE_MBIT


class DelayManager:
    def __init__(self, constellation, time_step, tf) -> None:
        self.constellation = constellation
        self.time_step = time_step
        # Queueing delay set according to 
        # TLR: A Traffic-Light-Based Intelligent Routing Strategy for NGEO Satellite IP Networks
        self.avg_queueing_delay_ms = 8.0 * 2  # times 2 to simulate congested satellite networks
        self.tf = tf
    
    def delay_ms(self, path_without_offloading, traffic_mb, group, offloading_sat_index=0, is_offloaded=False):
        total_delay_ms = 0
        if not is_offloaded:
            total_delay_ms += self.propagation_delay_ms(path_without_offloading)
            total_delay_ms += self.queueing_delay_ms(path_without_offloading)
            total_delay_ms += self.transmission_delay_ms(path_without_offloading)
        else:
            # If offloaded, count the GSL propagation delay and pop delay
            total_delay_ms += 550000 / c * 1000.0  # 550 km altitude LEO satellites
            max_split_delay_ms = float('-inf')
            for bid in group:
                bid_offloading_path = path_without_offloading[:offloading_sat_index + 1 + bid.offloading_sat_offset]
                bid_delay_ms = 0
                bid_delay_ms += self.propagation_delay_ms(bid_offloading_path)
                bid_delay_ms += self.queueing_delay_ms(bid_offloading_path)
                bid_delay_ms += self.transmission_delay_ms(bid_offloading_path)
                bid_delay_ms += bid.pop_delay_ms
                if bid_delay_ms > max_split_delay_ms:
                    max_split_delay_ms = bid_delay_ms
            total_delay_ms += max_split_delay_ms

        return total_delay_ms
    
    def max_pop_delay_ms(self, group):
        pop_delay_ms_list = []
        for g in group:
            pop_delay_ms_list.append(g.pop_delay_ms)
        return max(pop_delay_ms_list)
    
    def propagation_delay_ms(self, path):
        total_prop_delay_ms = 0
        for i in range(len(path) - 1):
            sat1 = self.constellation.satellites[path[i]]
            sat2 = self.constellation.satellites[path[i + 1]]
            total_prop_delay_ms += self.propagation_delay_ms_between_sats(sat1, sat2, self.time_step)
        return total_prop_delay_ms

    def propagation_delay_ms_between_sats(self, sat1, sat2, time_step):
        distance_m = sat1.distance_from(sat2, time_step)
        return distance_m / c * 1000.0
    
    def queueing_delay_ms(self, path):
        total_queueing_delay_ms = 0
        for i in range(len(path)):
            sat = self.constellation.satellites[path[i]]
            total_queueing_delay_ms += self.queueing_delay_ms_on_sat(sat)
        return total_queueing_delay_ms

    def queueing_delay_ms_on_sat(self, sat):
        lat_deg = math.degrees(sat.ephem.sublat)
        lon_deg = math.degrees(sat.ephem.sublong)
        scaled_num_users = local_users_scaled_by_time(lat_deg, lon_deg, self.time_step.current_time, self.tf)
        original_num_users = local_users(lat_deg, lon_deg)
        if original_num_users == 0:
            return 0
        return self.avg_queueing_delay_ms * scaled_num_users / original_num_users

    def transmission_delay_ms(self, path):
        total_transmission_delay_ms = 0
        for i in range(len(path)):
            sat = self.constellation.satellites[path[i]]
            total_transmission_delay_ms += self.transmission_delay_ms_on_sat(sat, AVG_PKT_SIZE_MBIT)
        return total_transmission_delay_ms
    
    def transmission_delay_ms_on_sat(self, sat, traffic_mb):
        return traffic_mb / sat.bandwidth_mbps * 1000.0

    def offloading_gsl_delay_ms(self, task):
        max_offloading_gsl_delay_ms = float('-inf')
        for bid in task.winner:
            bid_offloading_gsl_delay_ms = 0
            offloading_sat = task.path_without_offloading[bid.offloading_sat_offset]
            bid_offloading_gsl_delay_ms += self.queueing_delay_ms([offloading_sat])
            bid_offloading_gsl_delay_ms += self.transmission_delay_ms([offloading_sat])
            bid_offloading_gsl_delay_ms += 550000 / c * 1000.0  # GSL propagation delay
            if bid_offloading_gsl_delay_ms > max_offloading_gsl_delay_ms:
                max_offloading_gsl_delay_ms = bid_offloading_gsl_delay_ms
        return max_offloading_gsl_delay_ms
