from models.global_var import OFFLOADING_SAT_INDEX
from helpers.users_scale import map_lat_long_to_grid
from models.auction_utility import AuctionUtility
import math


class FalconAlgorithm:
    """
    Falcon: Towards Fast and Scalable Data Delivery for Emerging Earth Observation Constellations
    """
    def __init__(self, max_budget, dish_generator, delay_manager, constellation, data_manager, cost_margin) -> None:
        self.dish_generator = dish_generator
        self.delay_manager = delay_manager
        self.constellation = constellation
        self.data_manager = data_manager
        self.data_manager.data['remaining_budget'] = []
        self.data_manager.data['budget_after_each_task'] = []
        self.max_budget = max_budget
        self.current_budget = self.max_budget
        self.offloading_satellite_index = OFFLOADING_SAT_INDEX  # Which satellite is the offloading satellite on the original path
        self.auction_utility = AuctionUtility(delay_manager, constellation)
        self.cost_margin = cost_margin

    def start(self, tasks):
        self.current_budget = self.max_budget
        self.data_manager.data['budget_after_each_task'].append([])
        for task in tasks:
            self.data_manager.data['budget_after_each_task'][-1].append(self.current_budget)
            bids = self.collect_bids(task)
            winner = self.falcon_algorithm(task, bids)
            if winner is None:
                continue
            task.winner = [winner]
            task.auction_utility = self.auction_utility.utility_of(task, task.winner)
            task.cost = winner.cost
            task.path_with_offloading = self.get_path_with_offloading(task)
            self.current_budget -= winner.cost
        self.data_manager.data['remaining_budget'].append(self.current_budget)
        return tasks

    def get_path_with_offloading(self, task):
        return task.path_without_offloading[:self.offloading_satellite_index + 1 + task.winner[0].offloading_sat_offset]

    def collect_bids(self, task):
        # Collect bids based on location
        source_sat = task.traffic_pair[0]
        source_lat_deg = math.degrees(source_sat.ephem.sublat)
        source_long_deg = math.degrees(source_sat.ephem.sublong)
        
        dest_sat = task.traffic_pair[1]
        dest_lat_deg = math.degrees(dest_sat.ephem.sublat)
        dest_long_deg = math.degrees(dest_sat.ephem.sublong)
        
        row, col = map_lat_long_to_grid(source_lat_deg, source_long_deg)
        dishes = self.dish_generator.dish_grid[row, col]
        bids = []
        for dish in dishes:
            bids.append(dish.propose_bid(dest_lat_deg, dest_long_deg, cost_margin=self.cost_margin))        
        return bids
    
    def falcon_algorithm(self, task, bids):
        # FALCON focuses on minimizing flow completion time
        # so here we only focus on minimizing delay utility
        if len(bids) == 0:
            return None
        
        max_utility = float('-inf')
        max_utility_bid = None
        
        max_delay_bid = max(bids, key=lambda bid: self.delay_manager.delay_ms(task.path_without_offloading, task.traffic_amount_mb_requirement, [bid], offloading_sat_index=self.offloading_satellite_index, is_offloaded=True))
        min_delay_bid = min(bids, key=lambda bid: self.delay_manager.delay_ms(task.path_without_offloading, task.traffic_amount_mb_requirement, [bid], offloading_sat_index=self.offloading_satellite_index, is_offloaded=True))
        
        max_delay_ms = self.delay_manager.delay_ms(task.path_without_offloading, task.traffic_amount_mb_requirement, [max_delay_bid], offloading_sat_index=self.offloading_satellite_index, is_offloaded=True)
        min_delay_ms = self.delay_manager.delay_ms(task.path_without_offloading, task.traffic_amount_mb_requirement, [min_delay_bid], offloading_sat_index=self.offloading_satellite_index, is_offloaded=True)
        
        for bid in bids:
            bid_delay_ms = self.delay_manager.delay_ms(task.path_without_offloading, task.traffic_amount_mb_requirement, [bid], offloading_sat_index=self.offloading_satellite_index, is_offloaded=True)
            
            normalized_delay = self.normalized_value(
                bid_delay_ms, max_delay_ms, min_delay_ms
            )
            
            utility = normalized_delay
            
            if utility > max_utility:
                # Check QoS and budget
                task_delay_ms = bid_delay_ms
                if bid.bandwidth_mbps >= task.bandwidth_mbps_requirement and \
                    task_delay_ms <= task.delay_ms_requirement and \
                    bid.traffic_amount_mb >= task.traffic_amount_mb_requirement and \
                    bid.cost <= self.current_budget:
                        
                    max_utility = utility
                    max_utility_bid = bid
                    
        return max_utility_bid
    
    def normalized_value(self, value, max, min):
        if max == min:
            return 0.5
        return (value - min) / (max - min)

