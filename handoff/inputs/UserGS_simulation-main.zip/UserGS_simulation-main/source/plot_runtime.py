from models.global_var import AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION, MAX_BUDGETS
import matplotlib.pyplot as plt
import os, csv
from plot import constellation_mapping, PATTERNS
import numpy as np


CONSTELLATION_TO_PLOT = [
    'CONSTELLATION_NAME.IRIDIUM_6_11_780',
    'CONSTELLATION_NAME.KUIPER_28_28_590',
    'CONSTELLATION_NAME.STARLINK_550',
    'CONSTELLATION_NAME.ONEWEB_18_40_1200',
    'CONSTELLATION_NAME.TELESAT_6_12_1000',
    'CONSTELLATION_NAME.LEO_72_44_550',
]


def plot_total_runtime_on_different_constellation_sizes(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y_cgsc = []
    y_cstp = []
    
    folders = os.listdir(base_dir)
    for folder in folders:
        if folder in constellation_mapping and folder in CONSTELLATION_TO_PLOT:
            x.append(constellation_mapping[folder]['num_orbits'] * constellation_mapping[folder]['sats_per_orbit'])
            csv_path = os.path.join(base_dir, folder, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}', f'REVERSE_AUCTION')
            group_construction_avg_runtime_second, selection_payment_avg_runtime_second = get_avg_runtime_from_csv(csv_path)
            y_cgsc.append(group_construction_avg_runtime_second)
            y_cstp.append(selection_payment_avg_runtime_second)

    combined_data = list(zip(x, y_cgsc, y_cstp))
    sorted_data = sorted(combined_data)

    x_sorted, y_cgsc_sorted, y_cstp_sorted = zip(*sorted_data)

    # Convert x values to strings for discrete categories
    x_sorted_str = [str(i) for i in x_sorted]

    label_fontsize = 32
    legend_fontsize = 22
    tick_fontsize = 22
    name_fontsize = 22

    plt.figure(figsize=(8, 5.7))
    plt.tick_params(axis='both', which='major', labelsize=tick_fontsize)
    
    # Stacked bar chart
    bar_width = 0.35
    bars1 = plt.bar(x_sorted_str, y_cgsc_sorted, label='Algorithm 1: CGSC', width=bar_width, edgecolor='#ff5733', color='white')
    for bar in bars1:
        bar.set_hatch(PATTERNS[0])
    
    bars2 = plt.bar(x_sorted_str, y_cstp_sorted, bottom=y_cgsc_sorted, label='Algorithm 2: CSTP', width=bar_width, edgecolor='#1477c1', color='white')
    for bar in bars2:
        bar.set_hatch(PATTERNS[1])
    
    plt.xlabel('Number of satellites', fontsize=label_fontsize)
    plt.ylabel('Average runtime (s)', fontsize=label_fontsize)

    plt.legend(loc='upper left', fontsize=legend_fontsize)
    
    # Add text on top of specific bars
    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}  # Example dictionary mapping categories to text labels
    
    max_y_value = max([y1 + y2 for y1, y2 in zip(y_cgsc_sorted, y_cstp_sorted)])
    plt.ylim(0, max_y_value * 1.3)  # Increase the limit by 30%

    for i, val in enumerate(x_sorted_str):
        if val in text_labels:
            plt.text(i, y_cgsc_sorted[i] + y_cstp_sorted[i] + 0.005, text_labels[val], ha='center', fontsize=name_fontsize, color='black')

    # Adjust the padding to increase whitespace on the left and right sides
    plt.subplots_adjust(left=0.1, right=0.95)  # Adjust these values as needed

    plt.savefig(os.path.join(output_dir, 'logo_cgsc_cstp_avg_runtime_vs_network_sizes.pdf'), bbox_inches='tight')


def plot_total_runtime_on_different_constellation_sizes_compact_fig_size(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y_cgsc = []
    y_cstp = []
    
    folders = os.listdir(base_dir)
    for folder in folders:
        if folder in constellation_mapping and folder in CONSTELLATION_TO_PLOT:
            x.append(constellation_mapping[folder]['num_orbits'] * constellation_mapping[folder]['sats_per_orbit'])
            csv_path = os.path.join(base_dir, folder, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}', f'REVERSE_AUCTION')
            group_construction_avg_runtime_second, selection_payment_avg_runtime_second = get_avg_runtime_from_csv(csv_path)
            y_cgsc.append(group_construction_avg_runtime_second)
            y_cstp.append(selection_payment_avg_runtime_second)

    combined_data = list(zip(x, y_cgsc, y_cstp))
    sorted_data = sorted(combined_data)

    x_sorted, y_cgsc_sorted, y_cstp_sorted = zip(*sorted_data)

    # Convert x values to strings for discrete categories
    x_sorted_str = [str(i) for i in x_sorted]

    label_fontsize = 24
    legend_fontsize = 20
    tick_fontsize = 20
    name_fontsize = 20

    plt.figure(figsize=(12, 3))
    plt.tick_params(axis='both', which='major', labelsize=tick_fontsize)
    
    # Stacked bar chart
    bar_width = 0.75
    bars1 = plt.bar(x_sorted_str, y_cgsc_sorted, label='Algorithm 1: CGSC', width=bar_width, edgecolor='#ff5733', color='white')
    for bar in bars1:
        bar.set_hatch(PATTERNS[0])
    
    bars2 = plt.bar(x_sorted_str, y_cstp_sorted, bottom=y_cgsc_sorted, label='Algorithm 2: CSTP', width=bar_width, edgecolor='#1477c1', color='white')
    for bar in bars2:
        bar.set_hatch(PATTERNS[1])
    
    plt.xlabel('Number of satellites', fontsize=label_fontsize)
    plt.ylabel('Avg. runtime (s)', fontsize=label_fontsize)

    plt.legend(loc='upper left', fontsize=legend_fontsize)
    
    # Add text on top of specific bars
    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2xStarlink'}  # Example dictionary mapping categories to text labels
    
    max_y_value = max([y1 + y2 for y1, y2 in zip(y_cgsc_sorted, y_cstp_sorted)])
    plt.ylim(0, max_y_value * 1.3)  # Increase the limit by 30%

    for i, val in enumerate(x_sorted_str):
        if val in text_labels:
            plt.text(i, y_cgsc_sorted[i] + y_cstp_sorted[i] + 0.005, text_labels[val], ha='center', fontsize=name_fontsize, color='black')

    # Adjust the padding to increase whitespace on the left and right sides
    plt.subplots_adjust(left=0.1, right=0.95)  # Adjust these values as needed

    plt.savefig(os.path.join(output_dir, 'compact_fig_size_logo_cgsc_cstp_avg_runtime_vs_network_sizes.pdf'), bbox_inches='tight')


def get_avg_runtime_from_csv(csv_path):
    group_construction_runtime_csv = os.path.join(csv_path, 'REVERSE_AUCTION_collaborator_group_set_construction_runtime_second_per_task.csv')
    selection_payment_runtime_csv = os.path.join(csv_path, 'REVERSE_AUCTION_collaborator_selection_and_truthful_payment_runtime_second_per_task.csv')
    
    group_construction_runtime_second_tasks = []
    group_construction_avg_runtime_second = None
    with open(group_construction_runtime_csv, mode='r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            group_construction_runtime_second_tasks.append(float(row[0]))
    group_construction_avg_runtime_second = np.mean(group_construction_runtime_second_tasks)
    
    selection_payment_runtime_second_tasks = []
    selection_payment_avg_runtime_second = None
    with open(selection_payment_runtime_csv, mode='r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            selection_payment_runtime_second_tasks.append(float(row[0]))
    selection_payment_avg_runtime_second = np.mean(selection_payment_runtime_second_tasks)
    
    return group_construction_avg_runtime_second, selection_payment_avg_runtime_second


def table_total_runtime_on_different_constellation_sizes(base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y_cgsc = []
    y_cstp = []
    
    folders = os.listdir(base_dir)
    for folder in folders:
        if folder in constellation_mapping and folder in CONSTELLATION_TO_PLOT:
            x.append(constellation_mapping[folder]['num_orbits'] * constellation_mapping[folder]['sats_per_orbit'])
            csv_path = os.path.join(base_dir, folder, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{failure_rate_fluctuation}', f'REVERSE_AUCTION')
            group_construction_avg_runtime_second, selection_payment_avg_runtime_second = get_avg_runtime_from_csv(csv_path)
            y_cgsc.append(group_construction_avg_runtime_second)
            y_cstp.append(selection_payment_avg_runtime_second)

    combined_data = list(zip(x, y_cgsc, y_cstp))
    sorted_data = sorted(combined_data)

    x_sorted, y_cgsc_sorted, y_cstp_sorted = zip(*sorted_data)

    # Convert x values to strings for discrete categories
    x_sorted_str = [str(i) for i in x_sorted]

    text_labels = {'72': 'Telesat', '784': 'Kuiper', '1584': 'Starlink', '3168': '2xStarlink'}

    # Filter the data to only keep OneWeb, Kuiper, and Starlink
    filtered_indices = [i for i, val in enumerate(x_sorted_str) if val in text_labels]
    x_filtered = [x_sorted_str[i] for i in filtered_indices]
    y_cgsc_filtered = [y_cgsc_sorted[i] for i in filtered_indices]
    y_cstp_filtered = [y_cstp_sorted[i] for i in filtered_indices]

    # Convert runtimes from seconds to milliseconds
    y_cgsc_filtered_ms = [runtime * 1000 for runtime in y_cgsc_filtered]
    y_cstp_filtered_ms = [runtime * 1000 for runtime in y_cstp_filtered]
    total_runtime_ms = [y1 + y2 for y1, y2 in zip(y_cgsc_filtered_ms, y_cstp_filtered_ms)]

    table_data = [['\\diagbox[width=2.5cm, height=1cm]{Algo.\\\\Runtime (ms)}{Constellation}'] + [text_labels.get(size, size) for size in x_filtered]]
    table_data.append(['CGSC Runtime'] + list(y_cgsc_filtered_ms))
    table_data.append(['CSTP Runtime'] + list(y_cstp_filtered_ms))
    table_data.append(['Total Runtime'] + total_runtime_ms)

    table_csv_path = os.path.join(output_dir, 'runtime_table.csv')
    with open(table_csv_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(table_data)

    # Write the table into a txt file in LaTeX table format
    table_txt_path = os.path.join(output_dir, 'runtime_table.tex')
    with open(table_txt_path, mode='w') as file:
        file.write('\\begin{table}[ht]\n')
        file.write('\\centering\n')
        file.write('\\begin{tabular}{|' + 'c|' * len(table_data[0]) + '}\n')
        file.write('\\hline\n')
        
        for row in table_data:
            file.write(' & '.join(map(lambda x: f'{x:.2f}' if isinstance(x, float) else str(x), row)) + ' \\\\\n')
            file.write('\\hline\n')
        
        file.write('\\end{tabular}\n')
        file.write('\\caption{Runtime comparison of CGSC and CSTP algorithms across different network sizes.}\n')
        file.write('\\label{tab:runtime_comparison}\n')
        file.write('\\end{table}\n')


if __name__ == '__main__':
    max_budget = MAX_BUDGETS[0]
    failure_rate = AVG_FAILURE_RATES[0]
    bad_dish_prob = BAD_DISH_PROBS[0]
    failure_rate_fluctuation = FAILURE_RATE_FLUCTUATION[0]
    
    NETWORK_SIZES_BASE_DIR = 'output/NETWORK_SIZES'
    
    plot_total_runtime_on_different_constellation_sizes(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
    
    plot_total_runtime_on_different_constellation_sizes_compact_fig_size(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
    
    table_total_runtime_on_different_constellation_sizes(base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
