from ephem import Date as ephemDate
from datetime import timedelta
import ephem


class Simulation:
    def __init__(self, max_steps, time_step, is_verbose=False) -> None:
        self.event_callbacks = []
        self.event_intervals = []
        self.event_starts = []
        self.event_ends = []
        self.event_args = []
        self.event_output = {}
        self.event_input_ids = {}
        self.event_messages = {}
        self.event_ids = []
        self.max_steps = max_steps
        self.is_verbose = is_verbose
        self.time_step = time_step
    
    def start(self):
        for step in range(self.max_steps):
            if self.is_verbose:
                print('======= Step {} ======='.format(step))
            for i in range(len(self.event_callbacks)):
                if step > self.event_ends[i] or step < self.event_starts[i]:
                    continue
                if (step - self.event_starts[i]) % (self.event_intervals[i]) != 0:
                    continue
                args = self.event_args[i].copy()
                if self.event_input_ids[self.event_ids[i]] is not None:
                    args.append(self.event_output[self.event_input_ids[self.event_ids[i]]])             
                output = self.event_callbacks[i](*args)
                self.event_output[self.event_ids[i]] = output
                if self.is_verbose:
                    if self.event_messages[self.event_ids[i]] is not None:
                        print(self.event_messages[self.event_ids[i]])
            self.time_step.next()
    
    def register(self, id, event_callback, interval, args=[], start=0, end=float('inf'), input_event_id=None, message=None):
        if start < 0 or end < start:
            raise ValueError('Invalid start and end values.')
        self.event_callbacks.append(event_callback)
        self.event_intervals.append(interval)
        self.event_starts.append(start)
        self.event_ends.append(end)
        self.event_args.append(args)
        self.event_ids.append(id)
        self.event_input_ids[id] = input_event_id
        self.event_output[id] = None
        self.event_messages[id] = message


class TimeStep:
    def __init__(self, start_time: ephemDate, interval: timedelta) -> None:
        self.start_time: ephemDate = start_time
        self.current_time: ephemDate = self.start_time
        self.interval = interval.total_seconds() / (24 * 60 * 60)
        self.time_step_counter = 0
        
    def next(self):
        self.current_time = ephem.Date(self.current_time + self.interval)
        self.time_step_counter += 1
    
    def display_start_time(self):
        py_datetime = ephem.localtime(self.start_time)
        formatted_date = py_datetime.strftime('%Y-%m-%d %H:%M:%S')
        return formatted_date
    
    def display_current_time(self):
        py_datetime = ephem.localtime(self.current_time)
        formatted_date = py_datetime.strftime('%Y-%m-%d %H:%M:%S')
        return formatted_date
