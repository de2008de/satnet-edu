# Put those unused plot functions here
from models.enum import Algorithms
from matplotlib import rcParams
import os, csv
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import interp1d
from statsmodels.distributions.empirical_distribution import ECDF
from plot import ALGO_INFO, PATTERNS, SCATTER_PATTERNS


rcParams['font.family'] = 'serif'
rcParams['font.serif'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42


def plot_group_size_scatter(base_dir='output'):
    task_indices = []  # Store task indices
    group_sizes = []  # Store group sizes
    algo_labels = []  # Store labels for algorithms
    row_idx = 0

    for algo in Algorithms:
        if algo == Algorithms.DEFAULT:
            continue
        csv_file_path = os.path.join(base_dir, f"{algo.name}/{algo.name}_group_size_each_task.csv")

        # Ensure the file exists
        if not os.path.isfile(csv_file_path):
            print(f"File not found: {csv_file_path}")
            continue

        with open(csv_file_path, 'r') as file:
            for i, line in enumerate(file):
                if i == row_idx:
                    values = line.strip().split(',')
                    task_indices.extend(list(range(len(values))))
                    group_sizes.extend([float(val) for val in values if val])
                    algo_labels.extend([algo.name] * len(values))
                    break
    
    plt.figure(figsize=(10, 6))
    for i, algo in enumerate(set(algo_labels)):
        # Extract data for this algorithm
        indices = [task_indices[j] for j in range(len(task_indices)) if algo_labels[j] == algo]
        sizes = [group_sizes[j] for j in range(len(group_sizes)) if algo_labels[j] == algo]
        plt.scatter(indices, sizes, label=ALGO_INFO[algo][0], color=ALGO_INFO[algo][1], marker=SCATTER_PATTERNS[i % len(SCATTER_PATTERNS)], alpha=0.7)

    plt.xlabel('Task Index')
    plt.ylabel('Group Size')
    plt.title(f'Comparison of Group Sizes for Algorithms at Interval {row_idx}')
    plt.legend(title='Algorithms')
    plt.grid(True)

    # Save the figure as a PDF
    plt.savefig(os.path.join(base_dir, 'group_size_comparison.pdf'), format='pdf')
    plt.close()


def plot_group_size_histogram(base_dir='output', row_idx=0):
    group_sizes = {algo.name: [] for algo in Algorithms if algo != Algorithms.DEFAULT}
    
    for algo in Algorithms:
        if algo == Algorithms.DEFAULT:
            continue
        csv_file_path = os.path.join(base_dir, f"{algo.name}/{algo.name}_group_size_each_task.csv")

        # Ensure the file exists
        if not os.path.isfile(csv_file_path):
            print(f"File not found: {csv_file_path}")
            continue

        with open(csv_file_path, 'r') as file:
            for i, line in enumerate(file):
                if i == row_idx:
                    values = [float(val) for val in line.strip().split(',') if val]
                    group_sizes[algo.name].extend(values)
                    break
    
    plt.figure(figsize=(10, 6))
    for algo, sizes in group_sizes.items():
        plt.hist(sizes, bins=np.arange(0.5, max(sizes)+1.5, 1), alpha=0.7, label=ALGO_INFO[algo][0])

    plt.xlabel('Group Size')
    plt.ylabel('Frequency')
    plt.title('Histogram of Group Sizes per Algorithm')
    plt.legend(title='Algorithms')
    plt.grid(True)
    
    plt.savefig(os.path.join(base_dir, 'group_size_histogram.pdf'), format='pdf')
    plt.close()


def plot_group_size_cdf(base_dir='output', row_idx=0):
    group_sizes = {algo.name: [] for algo in Algorithms if algo != Algorithms.DEFAULT}
    
    for algo in Algorithms:
        if algo == Algorithms.DEFAULT:
            continue
        csv_file_path = os.path.join(base_dir, f"{algo.name}/{algo.name}_group_size_each_task.csv")

        # Ensure the file exists
        if not os.path.isfile(csv_file_path):
            print(f"File not found: {csv_file_path}")
            continue

        with open(csv_file_path, 'r') as file:
            for i, line in enumerate(file):
                if i == row_idx:
                    values = [float(val) for val in line.strip().split(',') if val]
                    group_sizes[algo.name].extend(values)
                    break

    plt.figure(figsize=(10, 6))
    for algo, sizes in group_sizes.items():
        sorted_sizes = np.sort(sizes)
        cdf = np.arange(1, len(sorted_sizes)+1) / len(sorted_sizes)
        plt.step(sorted_sizes, cdf, where='post', label=ALGO_INFO[algo][0], color=ALGO_INFO[algo][1])

    plt.xlabel('Group Size')
    plt.ylabel('CDF')
    plt.title('CDF of Group Sizes per Algorithm')
    plt.legend(title='Algorithms')
    plt.grid(True)
    
    plt.savefig(os.path.join(base_dir, 'group_size_cdf.pdf'), format='pdf')
    plt.close()


def plot_percentage_of_group_size_2(base_dir='output', row_idx=0):
    percentages = {}
    
    for algo in Algorithms:
        if algo == Algorithms.DEFAULT:
            continue

        csv_file_path = os.path.join(base_dir, f"{algo.name}/{algo.name}_group_size_each_task.csv")

        # Ensure the file exists
        if not os.path.isfile(csv_file_path):
            print(f"File not found: {csv_file_path}")
            continue

        group_size_2_count = 0
        total_tasks = 0

        with open(csv_file_path, 'r') as file:
            for i, line in enumerate(file):
                if i == row_idx:
                    values = [float(val) for val in line.strip().split(',') if val]
                    total_tasks += len(values)  # Count all offloaded tasks
                    group_size_2_count += values.count(2)  # Count occurrences of group size 2
                    break
        
        # Calculate the percentage of group size 2 tasks
        if total_tasks > 0:
            percentages[algo.name] = (group_size_2_count / total_tasks) * 100
        else:
            percentages[algo.name] = 0

    # Now, create the bar chart
    plt.figure(figsize=(10, 6))
    bar_positions = range(len(percentages))
    plt.bar(bar_positions, percentages.values(), align='center', color=[ALGO_INFO[algo][1] for algo in percentages])

    plt.xlabel('Algorithm')
    plt.ylabel('Percentage of Group Size 2 Tasks (%)')
    plt.title('Percentage of Group Size 2 Tasks Per Algorithm')
    plt.xticks(bar_positions, [ALGO_INFO[algo][0] for algo in percentages])
    plt.ylim(0, 100)  # Set y-axis to show percentages from 0 to 100
    plt.legend([ALGO_INFO[algo][0] for algo in percentages], title='Algorithms')
    plt.grid(True)
    
    plt.savefig(os.path.join(base_dir, 'group_size_2_percentage.pdf'), format='pdf')
    plt.close()


def plot_delay_line_chart(base_dir='output', interp_kind='linear'):
    delay_requirements = {}
    winner_delays = {}

    for algo in Algorithms:
        if algo == Algorithms.DEFAULT:
            continue

        delay_req_file = os.path.join(base_dir, f"{algo.name}/{algo.name}_per_offloaded_task_delay_requirement_ms.csv")
        winner_delay_file = os.path.join(base_dir, f"{algo.name}/{algo.name}_per_offloaded_task_winner_delay_ms.csv")

        if not os.path.isfile(delay_req_file) or not os.path.isfile(winner_delay_file):
            print(f"Files not found: {delay_req_file} or {winner_delay_file}")
            continue

        all_delay_req = []
        all_winner_delay = []

        with open(delay_req_file, 'r') as req_file, open(winner_delay_file, 'r') as win_file:
            for req_line, win_line in zip(req_file, win_file):
                req_values = [float(val) for val in req_line.strip().split(',') if val]
                win_values = [float(val) for val in win_line.strip().split(',') if val]
                all_delay_req.extend(req_values)
                all_winner_delay.extend(win_values)

        delay_requirements[algo.name] = np.array(all_delay_req)
        winner_delays[algo.name] = np.array(all_winner_delay)

    plt.figure(figsize=(12, 7))
    for algo in Algorithms:
        if algo == Algorithms.DEFAULT or algo.name not in delay_requirements:
            continue
        x = delay_requirements[algo.name]
        y = winner_delays[algo.name]
        if len(x) > 1:
            f = interp1d(x, y, kind=interp_kind)
            xnew = np.linspace(min(x), max(x), num=200, endpoint=True)
            plt.plot(xnew, f(xnew), label=ALGO_INFO[algo.name][0])
        else:
            plt.plot(x, y, label=ALGO_INFO[algo.name][0])  # Plot without interpolation if only one point

    plt.xlabel('Delay Requirement (ms)')
    plt.ylabel('Winner Delay (ms)')
    plt.title('Winner Delay for Offloaded Tasks')
    plt.legend()
    plt.grid(True)

    plt.savefig(os.path.join(base_dir, 'winner_delay_line_chart_all_intervals_aggregated.pdf'), format='pdf')
    plt.close()


def plot_bandwidth_line_chart(base_dir='output', interp_kind='linear'):
    bandwidth_requirements = {}
    winner_bandwidths = {}

    for algo in Algorithms:
        if algo == Algorithms.DEFAULT:
            continue

        bandwidth_req_file = os.path.join(base_dir, f"{algo.name}/{algo.name}_per_offloaded_task_bandwidth_requirement_mbps.csv")
        winner_bandwidth_file = os.path.join(base_dir, f"{algo.name}/{algo.name}_per_offloaded_task_winner_bandwidth_mbps.csv")

        if not os.path.isfile(bandwidth_req_file) or not os.path.isfile(winner_bandwidth_file):
            print(f"Files not found: {bandwidth_req_file} or {winner_bandwidth_file}")
            continue

        all_bandwidth_req = []
        all_winner_bandwidth = []

        with open(bandwidth_req_file, 'r') as req_file, open(winner_bandwidth_file, 'r') as win_file:
            for req_line, win_line in zip(req_file, win_file):
                req_values = [float(val) for val in req_line.strip().split(',') if val]
                win_values = [float(val) for val in win_line.strip().split(',') if val]
                all_bandwidth_req.extend(req_values)
                all_winner_bandwidth.extend(win_values)

        bandwidth_requirements[algo.name] = np.array(all_bandwidth_req)
        winner_bandwidths[algo.name] = np.array(all_winner_bandwidth)

    plt.figure(figsize=(12, 7))
    for algo in Algorithms:
        if algo == Algorithms.DEFAULT or algo.name not in bandwidth_requirements:
            continue
        x = bandwidth_requirements[algo.name]
        y = winner_bandwidths[algo.name]
        if len(x) > 1:
            f = interp1d(x, y, kind=interp_kind)
            xnew = np.linspace(min(x), max(x), num=200, endpoint=True)
            plt.plot(xnew, f(xnew), label=ALGO_INFO[algo.name][0])
        else:
            plt.plot(x, y, label=ALGO_INFO[algo.name][0])  # Plot without interpolation if only one point

    plt.xlabel('Bandwidth Requirement (Mbps)')
    plt.ylabel('Winner Bandwidth (Mbps)')
    plt.title('Winner Bandwidth for Offloaded Tasks')
    plt.legend()
    plt.grid(True)

    plt.savefig(os.path.join(base_dir, 'winner_bandwidth_line_chart_all_intervals_aggregated.pdf'), format='pdf')
    plt.close()


def plot_winner_traffic_line_chart(base_dir='output', show_points=False):
    traffic_requirements = {}
    winner_traffics = {}

    for algo in Algorithms:
        if algo == Algorithms.DEFAULT:
            continue

        traffic_req_file = os.path.join(base_dir, f"{algo.name}/{algo.name}_per_offloaded_task_traffic_requirement_mb.csv")
        winner_traffic_file = os.path.join(base_dir, f"{algo.name}/{algo.name}_per_offloaded_task_winner_traffic_mb.csv")

        if not os.path.isfile(traffic_req_file) or not os.path.isfile(winner_traffic_file):
            print(f"Files not found: {traffic_req_file} or {winner_traffic_file}")
            continue

        all_traffic_req = []
        all_winner_traffic = []

        with open(traffic_req_file, 'r') as req_file, open(winner_traffic_file, 'r') as win_file:
            for req_line, win_line in zip(req_file, win_file):
                req_values = [float(val) for val in req_line.strip().split(',') if val]
                win_values = [float(val) for val in win_line.strip().split(',') if val]
                all_traffic_req.extend(req_values)
                all_winner_traffic.extend(win_values)

        traffic_requirements[algo.name] = np.array(all_traffic_req)
        winner_traffics[algo.name] = np.array(all_winner_traffic)

    plt.figure(figsize=(12, 7))
    for algo in Algorithms:
        if algo == Algorithms.DEFAULT or algo.name not in traffic_requirements:
            continue
        x = traffic_requirements[algo.name]
        y = winner_traffics[algo.name]
        if len(x) > 1:
            f = interp1d(x, y, kind='linear')
            xnew = np.linspace(min(x), max(x), num=200, endpoint=True)
            plt.plot(xnew, f(xnew), label=ALGO_INFO[algo.name][0])
            if show_points:
                plt.plot(x, y, 'o')  # Plot the data points
        else:
            plt.plot(x, y, label=ALGO_INFO[algo.name][0])  # Plot without interpolation if only one point

    plt.xlabel('Traffic Requirement (MB)')
    plt.ylabel('Winner Traffic (MB)')
    plt.title('Winner Traffic Amount for Offloaded Tasks')
    plt.legend()
    plt.grid(True)

    plt.savefig(os.path.join(base_dir, 'winner_traffic_line_chart_all_intervals_aggregated.pdf'), format='pdf')
    plt.close()


if __name__ == '__main__':
    plot_group_size_scatter()
    plot_group_size_histogram()
    plot_group_size_cdf()
    plot_percentage_of_group_size_2()
    plot_delay_line_chart()
    plot_bandwidth_line_chart()
    plot_winner_traffic_line_chart()
