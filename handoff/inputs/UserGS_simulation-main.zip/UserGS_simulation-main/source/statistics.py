from models.global_var import AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION, MAX_BUDGETS
from plot import ALGO_INFO
import os
import numpy as np
import csv
from constellation_factory import CONSTELLATION_NAME


def main():
    max_budget = MAX_BUDGETS[0]
    failure_rate = AVG_FAILURE_RATES[0]
    bad_dish_prob = BAD_DISH_PROBS[0]
    failure_rate_fluctuation = FAILURE_RATE_FLUCTUATION[0]
    base_dir = 'output/FIXED_BUDGET/'
    
    constellation_name = str(CONSTELLATION_NAME.STARLINK_550)
    compare_conserved_life_consumption(max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, constellation_name=constellation_name, base_dir=base_dir)
    compare_conserved_energy_consumption(max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, constellation_name=constellation_name, base_dir=base_dir)
    compare_reduced_end_to_end_delay(max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, constellation_name=constellation_name, base_dir=base_dir)
    
    
    constellation_name = str(CONSTELLATION_NAME.ONEWEB_18_40_1200)
    compare_conserved_life_consumption(max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, constellation_name=constellation_name, base_dir=base_dir)
    compare_conserved_energy_consumption(max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, constellation_name=constellation_name, base_dir=base_dir)
    compare_reduced_end_to_end_delay(max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, failure_rate_fluctuation=failure_rate_fluctuation, constellation_name=constellation_name, base_dir=base_dir)


def compare_conserved_life_consumption(max_budget, failure_rate, bad_dish_prob, failure_rate_fluctuation, constellation_name, base_dir='output'):
    avg_table = {}
    reverse_better_table = {}
    for algo_key, (algo_name, color) in ALGO_INFO.items():
        file_path = os.path.join(
            base_dir,
            constellation_name,
            f'max_budget_{max_budget}',
            f'failure_rate_{failure_rate}',
            f'bad_dish_prob_{bad_dish_prob}',
            f'failure_rate_fluctuation_{failure_rate_fluctuation}',
            algo_key,
            f"{algo_key}_per_offloaded_task_conserved_life_consumption.csv"
        )

        if os.path.isfile(file_path):
            with open(file_path, 'r') as csvfile:
                csvreader = csv.reader(csvfile)
                all_values = []
                for row in csvreader:
                    _row = [float(val) for val in row if val]
                    all_values.append(np.sum(_row))  # Convert to float and ignore empty strings

            # Calculate the average if there are values
            if all_values:
                avg_table[algo_name] = np.mean(all_values)

    REVERSE_AUCTION_NAME = ALGO_INFO['REVERSE_AUCTION'][0]
    for algo_name, avg in avg_table.items():
        reverse_better_table[algo_name] = (avg_table[REVERSE_AUCTION_NAME] - avg_table[algo_name]) / avg_table[algo_name]

    file_path = os.path.join(
        'output',
        f"{constellation_name}_conserved_life_consumption_per_interval_reverse_auction_better_than_others_pecentage_max_budget_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_failure_rate_fluctuation_{failure_rate_fluctuation}.csv"
    )
    
    with open(file_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        # Write the header
        writer.writerow(['Algorithm Name', 'Better Percentage'])
        
        # Write each row
        for algo_name, better_percentage in reverse_better_table.items():
            writer.writerow([algo_name, better_percentage])


def compare_conserved_energy_consumption(max_budget, failure_rate, bad_dish_prob, failure_rate_fluctuation, constellation_name, base_dir='output'):
    avg_table = {}
    reverse_better_table = {}
    for algo_key, (algo_name, color) in ALGO_INFO.items():
        file_path = os.path.join(
            base_dir,
            constellation_name,
            f'max_budget_{max_budget}',
            f'failure_rate_{failure_rate}',
            f'bad_dish_prob_{bad_dish_prob}',
            f'failure_rate_fluctuation_{failure_rate_fluctuation}',
            algo_key,
            f"{algo_key}_per_offloaded_task_conserved_energy_consumption.csv"
        )

        if os.path.isfile(file_path):
            with open(file_path, 'r') as csvfile:
                csvreader = csv.reader(csvfile)
                all_values = []
                for row in csvreader:
                    _row = [float(val) for val in row if val]
                    all_values.append(np.sum(_row))  # Convert to float and ignore empty strings

            # Calculate the average if there are values
            if all_values:
                avg_table[algo_name] = np.mean(all_values)

    REVERSE_AUCTION_NAME = ALGO_INFO['REVERSE_AUCTION'][0]
    for algo_name, avg in avg_table.items():
        reverse_better_table[algo_name] = (avg_table[REVERSE_AUCTION_NAME] - avg_table[algo_name]) / avg_table[algo_name]

    file_path = os.path.join(
        'output',
        f"{constellation_name}_conserved_energy_consumption_per_interval_reverse_auction_better_than_others_pecentage_max_budget_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_failure_rate_fluctuation_{failure_rate_fluctuation}.csv"
    )
    
    with open(file_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        # Write the header
        writer.writerow(['Algorithm Name', 'Better Percentage'])
        
        # Write each row
        for algo_name, better_percentage in reverse_better_table.items():
            writer.writerow([algo_name, better_percentage])


def compare_reduced_end_to_end_delay(max_budget, failure_rate, bad_dish_prob, failure_rate_fluctuation, constellation_name, base_dir='output'):
    avg_table = {}
    reverse_better_table = {}
    for algo_key, (algo_name, color) in ALGO_INFO.items():
        file_path = os.path.join(
            base_dir,
            constellation_name,
            f'max_budget_{max_budget}',
            f'failure_rate_{failure_rate}',
            f'bad_dish_prob_{bad_dish_prob}',
            f'failure_rate_fluctuation_{failure_rate_fluctuation}',
            algo_key,
            f"{algo_key}_per_offloaded_task_reduced_end_to_end_delay.csv"
        )

        if os.path.isfile(file_path):
            with open(file_path, 'r') as csvfile:
                csvreader = csv.reader(csvfile)
                all_values = []
                for row in csvreader:
                    _row = [float(val) for val in row if val]
                    all_values.append(np.sum(_row))  # Convert to float and ignore empty strings

            # Calculate the average if there are values
            if all_values:
                avg_table[algo_name] = np.mean(all_values)

    REVERSE_AUCTION_NAME = ALGO_INFO['REVERSE_AUCTION'][0]
    for algo_name, avg in avg_table.items():
        reverse_better_table[algo_name] = (avg_table[REVERSE_AUCTION_NAME] - avg_table[algo_name]) / avg_table[algo_name]

    file_path = os.path.join(
        'output',
        f"{constellation_name}_reduced_end_to_end_delay_per_interval_reverse_auction_better_than_others_pecentage_max_budget_{max_budget}_failure_rate_{failure_rate}_bad_dish_prob_{bad_dish_prob}_failure_rate_fluctuation_{failure_rate_fluctuation}.csv"
    )
    
    with open(file_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        # Write the header
        writer.writerow(['Algorithm Name', 'Better Percentage'])
        
        # Write each row
        for algo_name, better_percentage in reverse_better_table.items():
            writer.writerow([algo_name, better_percentage])


if __name__ == '__main__':
    main()
