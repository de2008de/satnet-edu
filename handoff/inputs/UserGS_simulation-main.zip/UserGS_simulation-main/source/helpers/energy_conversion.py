def convert_joule_to_watt_min(joule):
    return joule / 60.0
