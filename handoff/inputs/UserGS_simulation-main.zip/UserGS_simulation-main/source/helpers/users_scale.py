import datetime
import pytz
from typing import Tuple
from datetime import datetime


TRAFFIC_GRID = [
    #0
    [0, 0, 0, 0, 2, 2, 2, 2, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0],

    #1
    [5, 17, 19, 2, 2, 2, 2, 2, 1, 1, 1, 1, 4, 9, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],

    #2
    [1, 17, 0, 19, 19, 19, 19, 19, 2, 0, 0, 46, 178, 76, 16, 6, 6, 6, 5, 6, 72, 5, 5, 1],

    #3
    [1, 0, 0, 17, 32, 17, 17, 17, 0, 0, 1, 51, 52, 75, 71, 27, 41, 70, 67, 134, 151, 38, 0, 0],

    #4
    [0, 17, 0, 0, 15, 33, 38, 24, 0, 0, 1, 13, 3, 15, 22, 37, 115, 116, 118, 156, 149, 0, 0, 0],

    #5
    [0, 1, 0, 1, 0, 1, 26, 24, 15, 0, 0, 13, 99, 5, 27, 1, 1, 94, 40, 39, 34, 1, 1, 1],

    #6
    [1, 0, 1, 0, 0, 0, 10, 31, 14, 14, 0, 1, 2, 5, 31, 1, 0, 0, 10, 10, 13, 13, 1, 1],

    #7
    [1, 0, 1, 0, 0, 0, 0, 18, 21, 14, 0, 1, 1, 15, 14, 1, 0, 0, 0, 2, 2, 2, 2, 1],

    #8
    [1, 0, 0, 0, 0, 0, 0, 10, 22, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 2, 2, 2, 2, 4],

    #9
    [0, 0, 0, 0, 0, 0, 0, 10, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],

    #10
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],

    #11
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
]


def map_lat_long_to_grid(lat_deg, lon_deg):
        mid_rows = 5.5
        mid_columns = 11.5

        row = mid_rows - (lat_deg / 90) * 6
        col = mid_columns + (lon_deg / 180) * 12

        # Round row and col and make sure they stay in range
        row = round(row)
        col = round(col)
        row = max(row, 0)
        row = min(row, len(TRAFFIC_GRID))
        col = max(col, 0)
        col = min(col, len(TRAFFIC_GRID[0]))

        return row, col


def map_grid_to_lat_long(row, col):
    mid_rows = 5.5
    mid_columns = 11.5

    # Calculate the relative position from the middle of the grid
    relative_row = mid_rows - row
    relative_col = col - mid_columns

    # Convert relative grid position back to latitude and longitude
    lat_deg = (relative_row / 6) * 90
    lon_deg = (relative_col / 12) * 180

    return lat_deg, lon_deg


def local_users(lat_deg, lon_deg):
    row, col = map_lat_long_to_grid(lat_deg, lon_deg)
    num_users = TRAFFIC_GRID[row][col]
    return num_users


def local_time(lat_deg, lon_deg, curr_date, tf) -> datetime:
    utc_time = datetime.strptime(str(curr_date), '%Y/%m/%d %H:%M:%S')
    utc_time = pytz.utc.localize(utc_time)
    timezone_str = tf.timezone_at(lat=lat_deg, lng=lon_deg)
    timezone  = pytz.timezone(timezone_str)  # type: ignore
    local_time = utc_time.astimezone(timezone)
    return local_time


def local_users_time(lat_deg, lon_deg, curr_date, tf) -> Tuple[int, datetime]:
    num_users = local_users(lat_deg, lon_deg)
    _local_time = local_time(lat_deg, lon_deg, curr_date, tf)
    return num_users, _local_time


def local_users_scaled_by_time(lat_deg, lon_deg, curr_date, tf) -> int:
    num_users, local_time = local_users_time(lat_deg, lon_deg, curr_date, tf)
    hour = local_time.hour
    scale = None
    if hour >= 0 and hour < 8:
        scale = 0
    elif hour >= 8 and hour < 17:
        scale = 1
    elif hour >= 17 and hour <= 23:
        scale = 0.5
    else:
        raise Exception("Unhandled hour")
    return int(num_users * scale)


def test_conversion(lat_deg, lon_deg):
    print("Original Latitude and Longitude:", lat_deg, lon_deg)

    # First conversion: Latitude and Longitude to Grid
    row, col = map_lat_long_to_grid(lat_deg, lon_deg)
    print("Converted to Grid - Row:", row, "Col:", col)

    # Second conversion: Grid to Latitude and Longitude
    new_lat_deg, new_lon_deg = map_grid_to_lat_long(row, col)
    print("Converted back to Latitude and Longitude:", new_lat_deg, new_lon_deg)

    # Third conversion: Latitude and Longitude to Grid again
    new_row, new_col = map_lat_long_to_grid(new_lat_deg, new_lon_deg)
    print("Converted back to Grid - Row:", new_row, "Col:", new_col)

    # Check if the initial and final grid coordinates match
    assert row == new_row and col == new_col, "Test failed: Coordinates do not match"
    print("Test passed: Initial and final coordinates match")


if __name__ == '__main__':
    test_cases = [
        (0, 0),
        (85, 10),
        (-85, -10),
        (10, 179),
        (10, -179),
        (40.7128, -74.0060),
        (35.6895, 139.6917),
        (-33.8688, 151.2093),
        (-33.9249, 18.4241),
        (0, 45),
        (0, -45),
        (45, 0)
    ]
    for lat, lon in test_cases:
        test_conversion(lat, lon)
