import ephem
import math
from tles.generate_tle import LEO_ALTITUDE_M, FAST_LEO_TELESAT_ONE_ALTITUDE_M, FAST_LEO_TELESAT_TWO_ALTITUDE_M, FAST_MEO_ALTITUDE_M, FAST_GEO_ALTITUDE_M


def distance_to_coverage(high_alt_m, low_alt_m, low_elev_angle_deg):
    """
    @INPROCEEDINGS{9322362,
    author={Deng, Ruoqi and Di, Boya and Zhang, Hongliang and Song, Lingyang},
    booktitle={GLOBECOM 2020 - 2020 IEEE Global Communications Conference}, 
    title={Ultra-Dense LEO Satellite Constellation Design for Global Coverage in Terrestrial-Satellite Networks}, 
    year={2020},
    volume={},
    number={},
    pages={1-6},
    doi={10.1109/GLOBECOM42002.2020.9322362}}
    Equation 7

    Compute the distance to the low_sat, where fast_sat covers low_sat.

    high_alt_m: The altitude of the higher orbit in meters.
    low_alt_m: The altitude of the lower orbit in meters.
    low_elev_angle_deg: The elevation angle of the low_sat in degrees. 
                        Use the minimum value for the maximum distance.
    Return distance in meters.
    """
    low_elev_angle_rad = math.radians(low_elev_angle_deg)
    distance = -(ephem.earth_radius + low_alt_m) * math.sin(low_elev_angle_rad) + math.sqrt(
        ((ephem.earth_radius + low_alt_m) * math.sin(low_elev_angle_rad))**2 + high_alt_m**2 + 2*high_alt_m*(ephem.earth_radius + low_alt_m)
    )
    return distance


def coverage_within(fast_sats, low_sats, LOW_SAT_MIN_ELEV_ANGLE_DEG, curr_date):
    coverages = {}
    
    FAST_LEO_TELESAT_ONE_distance_m = distance_to_coverage(FAST_LEO_TELESAT_ONE_ALTITUDE_M, LEO_ALTITUDE_M, LOW_SAT_MIN_ELEV_ANGLE_DEG)
    FAST_LEO_TELESAT_TWO_distance_m = distance_to_coverage(FAST_LEO_TELESAT_TWO_ALTITUDE_M, LEO_ALTITUDE_M, LOW_SAT_MIN_ELEV_ANGLE_DEG)
    FAST_MEO_distance_m = distance_to_coverage(FAST_MEO_ALTITUDE_M, LEO_ALTITUDE_M, LOW_SAT_MIN_ELEV_ANGLE_DEG)
    FAST_GEO_distance_m = distance_to_coverage(FAST_GEO_ALTITUDE_M, LEO_ALTITUDE_M, LOW_SAT_MIN_ELEV_ANGLE_DEG)

    for fast_sat in fast_sats:
        covered_low_sats = {}
        # need to determine the fast type, use the corresponding altitude

        distance_m = 0
        if 'FAST-LEO-TELESAT-ONE' in fast_sat.name:
            distance_m = FAST_LEO_TELESAT_ONE_distance_m
        elif 'FAST-LEO-TELESAT-TWO' in fast_sat.name:
            distance_m = FAST_LEO_TELESAT_TWO_distance_m
        elif 'FAST-MEO' in fast_sat.name:
            distance_m = FAST_MEO_distance_m
        elif 'FAST-GEO' in fast_sat.name:
            distance_m = FAST_MEO_distance_m
        else:
            raise Exception('Unknown satellite type.')

        for low_sat in low_sats:
            _distance = fast_sat.distance_from(low_sat, curr_date)
            if _distance <= distance_m:
                covered_low_sats[low_sat.id] = (low_sat, _distance)
        coverages[fast_sat.id] = (fast_sat, covered_low_sats)
    return coverages
