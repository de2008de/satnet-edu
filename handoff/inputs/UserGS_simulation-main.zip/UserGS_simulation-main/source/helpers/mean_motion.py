SECONDS_ONE_DAY = 86400.0


def mm_rev_per_day(period_s):
    """
    Return the mean motion in the unit cycle per day.
    """
    return SECONDS_ONE_DAY / period_s


def mm_radian_per_minute(period_s):
    """
    Conversion information can be found here:
    https://www.translatorscafe.com/unit-converter/en-US/velocity-angular/1-9/radian/second-revolution/day/
    """
    mean_motion_per_day = mm_rev_per_day(period_s)
    return mean_motion_per_day * 60 / 13750.9870831397
