import csv

def log_message_to_csv(file_path, message):
    with open(file_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Message"])
        writer.writerow([message])
