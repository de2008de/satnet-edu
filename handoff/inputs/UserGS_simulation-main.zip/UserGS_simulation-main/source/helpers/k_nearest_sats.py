import heapq


def k_nearest_sats(k, source_sat, target_sats, curr_date):
    pq = []
    for sat in target_sats:
        distance = source_sat.distance_from(sat, curr_date)
        heapq.heappush(pq, (distance, sat))
    k_nearest = []
    for i in range(k):
        distance, sat = heapq.heappop(pq)
        k_nearest.append((distance, sat))
    return k_nearest
