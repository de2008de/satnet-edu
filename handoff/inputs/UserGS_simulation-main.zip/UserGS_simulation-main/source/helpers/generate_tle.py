# TLE format document: https://www.celestrak.com/NORAD/documentation/tle-fmt.php
# https://pypi.org/project/sgp4/

import sys
import os
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(parent_dir)

from sgp4.api import Satrec, WGS72, jday
from sgp4.exporter import export_tle

from helpers.mean_motion import mm_radian_per_minute
from helpers.orbital_period import get_orbit_period
import math


# TODO: Allow users to specify these parameters
GRAVITY_MODEL = WGS72
jd, fr = jday(2000, 1, 1, 0, 0, 0)
EPOCH = (jd + fr) - 2433281.5
DRAG_COEFFICIENT = 0.0  # Ignore it
ECCENTRICITY = 0.0000001  # Circular orbit
ARG_PERIGEE_RAD = math.radians(0.0)
PHASE_DIFF = True


def write_tles_to_file(tles, output_path, sat_id_start=0):
    sat_id = sat_id_start
    with open("{}/tles.txt".format(output_path), "w") as f:
        f.write("{} {}\n".format(LEO_NUM_ORBITS, LEO_SAT_PER_ORBIT))
        for t in tles:
            f.write("LEO-{} {}\n".format(sat_id, sat_id))
            f.write("{}\n".format(t[0]))
            f.write("{}\n".format(t[1]))
            sat_id += 1


def generate_tles(
        num_orbits,
        num_sats_per_orbit,
        inclination_deg,
        altitude_m,
        satellite_id=0
):
    tles = []
    for orbit_index in range(0, num_orbits):
        for sat_index in range(0, num_sats_per_orbit):
            tle_line1, tle_line2 = generate_tle_for_sat(
                satellite_id,
                orbit_index,
                sat_index,
                num_orbits,
                num_sats_per_orbit,
                inclination_deg,
                altitude_m,
            )
            tles.append((tle_line1, tle_line2))
            satellite_id += 1

    return tles


def generate_tle_for_sat(
        satellite_id,
        orbit_index,
        sat_index,
        num_orbits,
        num_sats_per_orbit,
        inclination_deg,
        altitude_m,
):
    sat = Satrec()

    orbit_phasing_shift = orbit_phasing(orbit_index, num_sats_per_orbit)
    mean_anomaly_deg = mean_anomaly_degree(orbit_phasing_shift, sat_index, num_sats_per_orbit)

    period_s = get_orbit_period(altitude_m)
    mean_motion_radian_per_minute = mm_radian_per_minute(period_s)
    _raan_deg = raan_deg(orbit_index, num_orbits)

    sat.sgp4init(
        GRAVITY_MODEL,        # gravity model
        'i',                  # 'a' = old AFSPC mode, 'i' = improved mode
        satellite_id,         # satnum: Satellite number
        EPOCH,       # epoch: days since 1949 December 31 00:00 UT
        DRAG_COEFFICIENT,     # bstar: drag coefficient (1/earth radii)
        0.0,                  # ndot: ballistic coefficient (revs/day)
        0.0,                  # nddot: mean motion 2nd derivative (revs/day^3)
        ECCENTRICITY,         # ecco: eccentricity
        ARG_PERIGEE_RAD,      # argpo: argument of perigee (radians)
        math.radians(inclination_deg),    # inclo: inclination (radians)
        math.radians(mean_anomaly_deg),   # mo: mean anomaly (radians)
        mean_motion_radian_per_minute,    # no_kozai: mean motion (radians/minute)
        math.radians(_raan_deg),          # nodeo: R.A. of ascending node (radians)
    )

    tle_line1, tle_line2 = export_tle(sat)
    tle_line1 = update_tle_international_designator(tle_line1)

    return tle_line1, tle_line2


def orbit_phasing(orbit_index, num_sats_per_orbit):
    """
    Return orbit phasing shift.
    """
    if orbit_index % 2 != 1 or not PHASE_DIFF:
        return 0
    return 360.0 / (num_sats_per_orbit * 2.0)


def mean_anomaly_degree(orbit_phasing_shift, sat_index, num_sats_per_orbit):
    """
    This is the angular position of the satellite in its orbit.
    """
    return orbit_phasing_shift + (sat_index / num_sats_per_orbit * 360.0)


def raan_deg(orbit_index, num_orbits):
    """
    Right ascension of the ascending node.
    """
    return orbit_index * 360.0 / num_orbits


def update_tle_international_designator(tle_line1):
    """
    We adopt Hypatia's approach to change the international designator to 00000ABC in TLE line 1
    https://github.com/snkas/hypatia/blob/master/satgenpy/satgen/tles/generate_tles_from_scratch.py
    """
    tle_line1 = tle_line1[:7] + "U 00000ABC 00001.00000000 " + tle_line1[33:]
    tle_prefix_68_chars = tle_line1[:68]
    # Compute TLE checksum
    s = 0
    for i in range(len(tle_prefix_68_chars)):
        if tle_prefix_68_chars[i].isnumeric():
            s += int(tle_prefix_68_chars[i])
        if tle_prefix_68_chars[i] == "-":
            s += 1
    checksum = s % 10
    return tle_line1[:68] + str(checksum)


# Starlink, primary LEO
LEO_NUM_ORBITS = 72
LEO_SAT_PER_ORBIT = 22
LEO_INCL_ANGLE_DEG = 53
LEO_ALTITUDE_M = 550000


if __name__ == "__main__":
    leo_tles = generate_tles(LEO_NUM_ORBITS, LEO_SAT_PER_ORBIT, LEO_INCL_ANGLE_DEG, LEO_ALTITUDE_M)

    output_path = parent_dir = os.path.dirname(os.path.abspath(__file__))
    sat_id = 0
    with open("{}/leo_tles.txt".format(output_path), "w") as f:
        f.write("{} {}\n".format(LEO_NUM_ORBITS, LEO_SAT_PER_ORBIT))
        for t in leo_tles:
            f.write("LEO-{} {}\n".format(sat_id, sat_id))
            f.write("{}\n".format(t[0]))
            f.write("{}\n".format(t[1]))
            sat_id += 1
