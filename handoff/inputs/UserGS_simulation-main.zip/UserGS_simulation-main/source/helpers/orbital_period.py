import math
from astropy.constants import G, M_earth, R_earth

# Reference:
# @book{maral2020satellite,
#   title={Satellite communications systems: systems, techniques and technology},
#   author={Maral, Gerard and Bousquet, Michel and Sun, Zhili},
#   year={2020},
#   publisher={John Wiley \& Sons}
# }

mu = G.value * M_earth.value


def get_orbit_period(altitude_m):
    """
    altitude: the altitude of the satellite in meters
    Return the period of orbit in seconds.
    """
    # a is the length of the major axis in meters
    a = R_earth.value + altitude_m
    return 2 * math.pi * math.sqrt(a ** 3 / mu)


def get_altitude_by_period(period):
    """
    period: the period of the satellite in seconds
    Return the altitude in meters
    """
    return (((period / (2 * math.pi)) ** 2) * mu) ** (1./3.) - R_earth.value


if __name__ == "__main__":
    _altitude = 550000  # in meter
    _period = get_orbit_period(_altitude)
    print('Given altitude: {} km, we got period of orbit: {} seconds'.format(_altitude/1000, _period))

    __period = _period
    __altitude = get_altitude_by_period(__period)
    print('Given period of orbit: {} seconds, we got altitude: {} km'.format(__period, __altitude/1000))
