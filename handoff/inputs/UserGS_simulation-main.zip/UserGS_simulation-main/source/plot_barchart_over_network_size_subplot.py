from matplotlib import rcParams
import matplotlib.pyplot as plt
import os
from models.global_var import AVG_FAILURE_RATES, BAD_DISH_PROBS, FAILURE_RATE_FLUCTUATION, MAX_BUDGETS
from models.enum import Algorithms
from plot import ALGO_TO_PLOT, ALGO_INFO, LINE_STYLES, MARKER_SIZE
from statsmodels.distributions.empirical_distribution import ECDF
import numpy as np
import csv
from matplotlib.ticker import ScalarFormatter


PATTERNS = ('//', 'X', '\\', '-', '++')
label_fontsize = 20
tick_fontsize = 16
legend_fontsize = 20
subtitle_fontsize = 22


constellation_mapping = {
    'CONSTELLATION_NAME.IRIDIUM_6_11_780': {'num_orbits': 6, 'sats_per_orbit': 11},
    'CONSTELLATION_NAME.LEO_36_11_550': {'num_orbits': 36, 'sats_per_orbit': 11},
    'CONSTELLATION_NAME.LEO_48_11_550': {'num_orbits': 48, 'sats_per_orbit': 11},
    'CONSTELLATION_NAME.KUIPER_28_28_590': {'num_orbits': 28, 'sats_per_orbit': 28},
    'CONSTELLATION_NAME.LEO_72_33_550': {'num_orbits': 72, 'sats_per_orbit': 33},
    'CONSTELLATION_NAME.LEO_72_44_550': {'num_orbits': 72, 'sats_per_orbit': 44},
    'CONSTELLATION_NAME.LEO_72_66_550': {'num_orbits': 72, 'sats_per_orbit': 66},
    'CONSTELLATION_NAME.LEO_84_66_550': {'num_orbits': 84, 'sats_per_orbit': 66},
    'CONSTELLATION_NAME.STARLINK_550': {'num_orbits': 72, 'sats_per_orbit': 22},
    'CONSTELLATION_NAME.ONEWEB_18_40_1200': {'num_orbits': 18, 'sats_per_orbit': 40},
    'CONSTELLATION_NAME.TELESAT_6_12_1000': {'num_orbits': 6, 'sats_per_orbit': 12},
}


def plot_avg_uc_ratio_bar_chart_over_network_sizes(ax, base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y = []

    selected_constellations = [
        'CONSTELLATION_NAME.ONEWEB_18_40_1200',
        'CONSTELLATION_NAME.KUIPER_28_28_590',
        'CONSTELLATION_NAME.STARLINK_550'
    ]

    # Dictionary to store the aggregated UC ratios for each algorithm
    aggregated_uc_ratios = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_uc_ratios[algo.name] = {}
            for constellation_name in selected_constellations:
                aggregated_uc_ratios[algo.name][constellation_name] = []

    for constellation_name in selected_constellations:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_uc_ratio.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                raise FileNotFoundError

            # Read the entire CSV file line by line and aggregate UC ratios
            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_uc_ratios[algo.name][constellation_name].extend(values)

    # Compute the average UC ratio for each algorithm
    average_uc_ratios = {}
    for algo, uc_ratios in aggregated_uc_ratios.items():
        average_uc_ratios[algo] = {}
        for constellation_name, uc_ratio_values in uc_ratios.items():
            if uc_ratio_values:
                average_uc_ratios[algo][constellation_name] = np.mean(uc_ratio_values)
            else:
                average_uc_ratios[algo][constellation_name] = 0

    # Number of bars per group
    n_bars_per_group = len(ALGO_TO_PLOT)

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(selected_constellations))
    
    max_avg_uc_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_uc_values = []
        for constellation_name in selected_constellations:
            avg_uc_values.append(average_uc_ratios[algo.name][constellation_name])
            if average_uc_ratios[algo.name][constellation_name] > max_avg_uc_value:
                max_avg_uc_value = average_uc_ratios[algo.name][constellation_name]
        
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_uc_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}

    ax.set_xlabel('Constellation', fontsize=label_fontsize)
    ax.set_ylabel('Avg.\nutility-to-cost ratio', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([text_labels[str(constellation_mapping[name]['num_orbits'] * constellation_mapping[name]['sats_per_orbit'])] for name in selected_constellations])
    ax.tick_params(axis='both', labelsize=tick_fontsize)
    y_max = max_avg_uc_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')


def plot_reduced_life_consumption_over_network_sizes(ax, base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y = []

    selected_constellations = [
        'CONSTELLATION_NAME.ONEWEB_18_40_1200',
        'CONSTELLATION_NAME.KUIPER_28_28_590',
        'CONSTELLATION_NAME.STARLINK_550'
    ]

    aggregated_reduced_life_consumption = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_reduced_life_consumption[algo.name] = {}
            for constellation_name in selected_constellations:
                aggregated_reduced_life_consumption[algo.name][constellation_name] = []

    for constellation_name in selected_constellations:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_conserved_life_consumption.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                raise FileNotFoundError

            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_reduced_life_consumption[algo.name][constellation_name].extend([np.sum(values)])

    average_reduced_life_consumption = {}
    for algo, reduced_life_consumption in aggregated_reduced_life_consumption.items():
        average_reduced_life_consumption[algo] = {}
        for constellation_name, reduced_life_consumption_values in reduced_life_consumption.items():
            if reduced_life_consumption_values:
                average_reduced_life_consumption[algo][constellation_name] = np.mean(reduced_life_consumption_values)
            else:
                average_reduced_life_consumption[algo][constellation_name] = 0

    # Number of bars per group
    n_bars_per_group = len(ALGO_TO_PLOT)

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(selected_constellations))
    
    max_avg_reduced_life_consumption_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_reduced_life_consumption_values = []
        for constellation_name in selected_constellations:
            avg_reduced_life_consumption_values.append(average_reduced_life_consumption[algo.name][constellation_name])
            if average_reduced_life_consumption[algo.name][constellation_name] > max_avg_reduced_life_consumption_value:
                max_avg_reduced_life_consumption_value = average_reduced_life_consumption[algo.name][constellation_name]
        
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_reduced_life_consumption_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}

    ax.set_xlabel('Constellation', fontsize=label_fontsize)
    ax.set_ylabel('Avg. reduced\nlife consumption', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([text_labels[str(constellation_mapping[name]['num_orbits'] * constellation_mapping[name]['sats_per_orbit'])] for name in selected_constellations])
    ax.tick_params(axis='both', labelsize=tick_fontsize)
    y_max = max_avg_reduced_life_consumption_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')


def plot_reduced_energy_consumption_over_network_sizes(ax, base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y = []

    selected_constellations = [
        'CONSTELLATION_NAME.ONEWEB_18_40_1200',
        'CONSTELLATION_NAME.KUIPER_28_28_590',
        'CONSTELLATION_NAME.STARLINK_550'
    ]

    aggregated_reduced_energy_consumption = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_reduced_energy_consumption[algo.name] = {}
            for constellation_name in selected_constellations:
                aggregated_reduced_energy_consumption[algo.name][constellation_name] = []

    for constellation_name in selected_constellations:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_conserved_energy_consumption.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                raise FileNotFoundError

            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_reduced_energy_consumption[algo.name][constellation_name].extend([np.sum(values)])

    average_reduced_energy_consumption = {}
    for algo, reduced_energy_consumption in aggregated_reduced_energy_consumption.items():
        average_reduced_energy_consumption[algo] = {}
        for constellation_name, reduced_energy_consumption_values in reduced_energy_consumption.items():
            if reduced_energy_consumption_values:
                average_reduced_energy_consumption[algo][constellation_name] = np.mean(reduced_energy_consumption_values)
            else:
                average_reduced_energy_consumption[algo][constellation_name] = 0

    # Number of bars per group
    n_bars_per_group = len(ALGO_TO_PLOT)

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(selected_constellations))
    
    max_avg_reduced_energy_consumption_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_reduced_energy_consumption_values = []
        for constellation_name in selected_constellations:
            avg_reduced_energy_consumption_values.append(average_reduced_energy_consumption[algo.name][constellation_name])
            if average_reduced_energy_consumption[algo.name][constellation_name] > max_avg_reduced_energy_consumption_value:
                max_avg_reduced_energy_consumption_value = average_reduced_energy_consumption[algo.name][constellation_name]
        
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_reduced_energy_consumption_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}

    # Enable scientific notation for y-axis
    formatter = ScalarFormatter(useMathText=True)
    formatter.set_scientific(True)
    formatter.set_powerlimits((-1, 1))
    ax.yaxis.set_major_formatter(formatter)
    
    # Adjust font size for the scientific notation exponent
    ax.yaxis.get_offset_text().set_fontsize(label_fontsize)

    ax.set_xlabel('Constellation', fontsize=label_fontsize)
    ax.set_ylabel('Avg. reduced\nenergy consumption', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([text_labels[str(constellation_mapping[name]['num_orbits'] * constellation_mapping[name]['sats_per_orbit'])] for name in selected_constellations])
    ax.tick_params(axis='both', labelsize=tick_fontsize)
    y_max = max_avg_reduced_energy_consumption_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')


def plot_reduced_total_latency_over_network_sizes(ax, base_dir='output', output_dir='output', max_budget='10.0', failure_rate='0.0001', bad_dish_prob='0.1', fluctuation='1000'):
    x = []
    y = []

    selected_constellations = [
        'CONSTELLATION_NAME.ONEWEB_18_40_1200',
        'CONSTELLATION_NAME.KUIPER_28_28_590',
        'CONSTELLATION_NAME.STARLINK_550'
    ]

    aggregated_reduced_total_latency = {}
    for algo in ALGO_TO_PLOT:
        if algo != Algorithms.DEFAULT:
            aggregated_reduced_total_latency[algo.name] = {}
            for constellation_name in selected_constellations:
                aggregated_reduced_total_latency[algo.name][constellation_name] = []

    for constellation_name in selected_constellations:
        for algo in ALGO_TO_PLOT:
            if algo == Algorithms.DEFAULT:
                continue
            csv_file_path = os.path.join(base_dir, constellation_name, f'max_budget_{max_budget}', f'failure_rate_{failure_rate}', f'bad_dish_prob_{bad_dish_prob}', f'failure_rate_fluctuation_{fluctuation}', f"{algo.name}/{algo.name}_per_offloaded_task_reduced_end_to_end_delay.csv")

            if not os.path.isfile(csv_file_path):
                print(f"File not found: {csv_file_path}")
                raise FileNotFoundError

            with open(csv_file_path, 'r') as file:
                for line in file:
                    values = [float(val) for val in line.strip().split(',')]
                    aggregated_reduced_total_latency[algo.name][constellation_name].extend([np.sum(values)])

    average_reduced_total_latency = {}
    for algo, reduced_total_latency in aggregated_reduced_total_latency.items():
        average_reduced_total_latency[algo] = {}
        for constellation_name, reduced_total_latency_values in reduced_total_latency.items():
            if reduced_total_latency_values:
                average_reduced_total_latency[algo][constellation_name] = np.mean(reduced_total_latency_values)
            else:
                average_reduced_total_latency[algo][constellation_name] = 0

    # Number of bars per group
    n_bars_per_group = len(ALGO_TO_PLOT)

    # Positions of groups on the x-axis
    bar_width = 0.2
    indices = np.arange(len(selected_constellations))
    
    max_avg_reduced_total_latency_value = 0
    for i, algo in enumerate(ALGO_TO_PLOT):
        if algo == Algorithms.DEFAULT:
            continue
        color = ALGO_INFO[algo.name][1]
        pattern = PATTERNS[i]
        avg_reduced_total_latency_values = []
        for constellation_name in selected_constellations:
            avg_reduced_total_latency_values.append(average_reduced_total_latency[algo.name][constellation_name])
            if average_reduced_total_latency[algo.name][constellation_name] > max_avg_reduced_total_latency_value:
                max_avg_reduced_total_latency_value = average_reduced_total_latency[algo.name][constellation_name]
        
        positions = indices + i * bar_width

        bars = ax.bar(positions, avg_reduced_total_latency_values, bar_width, label=ALGO_INFO[algo.name][0], edgecolor=color, color='white')

        # Apply hatching patterns
        for bar in bars:
            bar.set_hatch(pattern)

    text_labels = {'66': 'Iridium', '72': 'Telesat', '720': 'OneWeb', '784': 'Kuiper', '1584': 'Starlink', '3168': '2x\nStarlink'}

    # Enable scientific notation for y-axis
    formatter = ScalarFormatter(useMathText=True)
    formatter.set_scientific(True)
    formatter.set_powerlimits((-1, 1))
    ax.yaxis.set_major_formatter(formatter)
    
    # Adjust font size for the scientific notation exponent
    ax.yaxis.get_offset_text().set_fontsize(label_fontsize)

    ax.set_xlabel('Constellation', fontsize=label_fontsize)
    ax.set_ylabel('Avg. reduced\ntotal latency (ms)', fontsize=label_fontsize)
    ax.set_xticks(indices + bar_width * (n_bars_per_group - 1) / 2)
    ax.set_xticklabels([text_labels[str(constellation_mapping[name]['num_orbits'] * constellation_mapping[name]['sats_per_orbit'])] for name in selected_constellations])
    ax.tick_params(axis='both', labelsize=tick_fontsize)
    y_max = max_avg_reduced_total_latency_value * 1.4
    ax.set_ylim(0, y_max)
    
    ax.grid(axis='y', linestyle='--')
    

def main():
    max_budget = MAX_BUDGETS[0]
    failure_rate = AVG_FAILURE_RATES[0]
    bad_dish_prob = BAD_DISH_PROBS[0]
    failure_rate_fluctuation = FAILURE_RATE_FLUCTUATION[0]
    NETWORK_SIZES_BASE_DIR = 'output/NETWORK_SIZES'
    subtitle_fontsize = 23
    
    fig, axs = plt.subplots(1, 4, figsize=(22, 3))
    fig.subplots_adjust(wspace=0.30, hspace=0.6)

    metrics = ['per_offloaded_task_conserved_life_consumption', 'per_offloaded_task_conserved_energy_consumption', 'per_offloaded_task_reduced_end_to_end_delay', 'per_offloaded_task_uc_ratio']
    xlabels = ['Avg. reduced life consumption', 'Avg. Reduced energy consumption', 'Avg. reduced total latency (ms)', 'Avg. utility-to-cost ratio']
    subtitles = ['(a) Avg. reduced life\nconsumption v.s. constellation.', '(b) Avg. reduced energy\nconsumption v.s. constellation.', '(c) Avg. reduced total latency\n (ms) v.s. constellation.', '(d) Avg. utility-to-cost\n ratio v.s. constellation.']

    plot_functions = [
        plot_reduced_life_consumption_over_network_sizes,
        plot_reduced_energy_consumption_over_network_sizes,
        plot_reduced_total_latency_over_network_sizes,
        plot_avg_uc_ratio_bar_chart_over_network_sizes
    ]
    
    for col, metric in enumerate(metrics):
        plot_functions[col](axs[col], base_dir=NETWORK_SIZES_BASE_DIR, max_budget=max_budget, failure_rate=failure_rate, bad_dish_prob=bad_dish_prob, fluctuation=failure_rate_fluctuation)
        axs[col].text(0.5, -0.3, subtitles[col], ha='center', va='top', transform=axs[col].transAxes, fontsize=subtitle_fontsize)

    handles, labels = axs[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', ncol=4, fontsize=legend_fontsize, bbox_to_anchor=(0.5, 1.18), frameon=False)

    plt.savefig(os.path.join('output', 'barcharts_all_metrics.pdf'), format='pdf', bbox_inches='tight')
    plt.close()


if __name__ == '__main__':
    main()
