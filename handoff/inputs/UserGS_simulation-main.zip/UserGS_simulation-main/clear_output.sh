#!/bin/bash

# Define the directory
output_dir="output"

# Navigate to the directory
cd "$output_dir"

# Remove all files except .gitignore
find . -type f ! -name '.gitignore' -exec rm -f {} +

# Find and remove all directories except the current one (.)
find . -mindepth 1 -type d -exec rm -rf {} +

echo "Cleanup completed!"
